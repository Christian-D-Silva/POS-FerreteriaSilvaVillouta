<?php
// db_connection.php
ini_set('display_errors', 1); // ¡IMPORTANTE PARA DEBUGGING!
ini_set('display_startup_errors', 1); // ¡IMPORTANTE PARA DEBUGGING!
error_reporting(E_ALL); // ¡IMPORTANTE PARA DEBUGGING!

function get_db_connection() {
    $servername = "localhost"; // O la IP de tu servidor de base de datos
    $username = "root"; // Tu usuario de base de datos
    $password = "";     // Tu contraseña de base de datos
    $dbname = "ferretera_pos"; // El nombre de tu base de datos

    try {
        $dsn = "mysql:host=$servername;dbname=$dbname;charset=utf8mb4";
        $options = [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ];
        $pdo = new PDO($dsn, $username, $password, $options);
        return $pdo;
    } catch (PDOException $e) {
        error_log("Connection failed: " . $e->getMessage());
        die("Connection failed: " . $e->getMessage()); // Esto mostrará el error de conexión si lo hay
    }
}
?>