<?php
// api/auth.php

// Asegurarse de que la sesión se inicie al principio de todo el script.
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Incluir el archivo de conexión a la base de datos
// ¡IMPORTANTE: Asegúrate de que esta ruta es correcta!
// Si db_connection.php está en el mismo nivel que api/, entonces sería solo 'db_connection.php'
// Si api/ está dentro de la raíz y db_connection.php está en la raíz, entonces es '../db_connection.php'
require_once __DIR__ . '/../db_connection.php'; 

header('Content-Type: application/json');

// --- Configuración temporal para depuración (¡QUITAR EN PRODUCCIÓN!) ---
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
// ---------------------------------------------------------------------

// --- NUEVA LÍNEA DE DEPURACIÓN INICIAL ---
error_log("DEBUG: auth.php ha sido accedido. Método: " . $_SERVER['REQUEST_METHOD'] . ", Acción: " . ($_GET['action'] ?? 'N/A'));
// ------------------------------------------

$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? '';

try {
    $pdo = get_db_connection(); // Obtener la conexión PDO una sola vez al inicio del try-catch

    switch ($method) {
        case 'POST':
            if ($action === 'login') {
                // --- NUEVA LÍNEA DE DEPURACIÓN PARA LA ENTRADA JSON ---
                $raw_input = file_get_contents('php://input');
                error_log("DEBUG: Raw POST input: " . $raw_input);
                $input = json_decode($raw_input, true);
                // --------------------------------------------------

                if (json_last_error() !== JSON_ERROR_NONE) {
                    error_log("ERROR: JSON Decode error: " . json_last_error_msg());
                    http_response_code(400);
                    echo json_encode(['error' => 'Formato de solicitud JSON inválido.']);
                    exit();
                }

                $username = $input['username'] ?? '';
                $password = $input['password'] ?? ''; // Contraseña en texto plano del frontend

                // --- DEBUGGING: Valores recibidos del frontend ---
                error_log("DEBUG: Intento de login para usuario: '" . $username . "'");
                error_log("DEBUG: Contraseña recibida del frontend (texto plano): '" . $password . "'");

                if (empty($username) || empty($password)) {
                    error_log("DEBUG: Usuario o contraseña vacíos.");
                    http_response_code(400); // Bad Request
                    echo json_encode(['error' => 'Se requieren nombre de usuario y contraseña.']);
                    exit(); // Terminar la ejecución después de enviar la respuesta
                }

                $stmt = $pdo->prepare("
                    SELECT
                        u.id,
                        u.username,
                        u.password_hash,
                        u.full_name,
                        u.email,
                        u.role_id,
                        u.is_active,
                        ur.name AS role_name
                    FROM users u
                    JOIN users_roles ur ON u.role_id = ur.id
                    WHERE u.username = ?
                    LIMIT 1
                ");
                $stmt->execute([$username]);
                $user = $stmt->fetch(PDO::FETCH_ASSOC);

                if (!$user) {
                    // --- DEBUGGING: Usuario no encontrado ---
                    error_log("DEBUG: Usuario NO encontrado: '" . $username . "'");
                    http_response_code(401); // Unauthorized
                    echo json_encode(['error' => 'Credenciales incorrectas.']);
                    exit();
                }

                // --- DEBUGGING: Datos del usuario encontrado ---
                error_log("DEBUG: Usuario encontrado: '" . $user['username'] . "'");
                error_log("DEBUG: Hash de contraseña desde DB: '" . $user['password_hash'] . "'"); // <-- IMPORTANTE: con comillas
                error_log("DEBUG: Estado is_active: " . $user['is_active']);

                // Verificar si el usuario está activo
                if (!$user['is_active']) {
                    error_log("DEBUG: Usuario inactivo: '" . $user['username'] . "'");
                    http_response_code(401); // Unauthorized
                    echo json_encode(['error' => 'Tu cuenta está inactiva. Contacta al administrador.']);
                    exit();
                }

                // --- LÍNEA CLAVE: Verificación de la contraseña ---
                $password_verification_result = password_verify($password, $user['password_hash']);

                // --- DEBUGGING: Resultado de password_verify() ---
                error_log("DEBUG: Resultado de password_verify(): " . ($password_verification_result ? 'TRUE' : 'FALSE'));

                if ($password_verification_result) {
                    error_log("DEBUG: Login exitoso para: '" . $user['username'] . "'");
                    $_SESSION['user_id'] = $user['id'];
                    $_SESSION['username'] = $user['username'];
                    $_SESSION['role_id'] = $user['role_id'];
                    $_SESSION['role_name'] = $user['role_name'];

                    http_response_code(200); // OK
                    echo json_encode([
                        'message' => 'Login exitoso.',
                        'logged_in' => true,
                        'user' => [
                            'id' => $user['id'],
                            'username' => $user['username'],
                            'full_name' => $user['full_name'],
                            'email' => $user['email'],
                            'role_id' => $user['role_id'],
                            'role_name' => $user['role_name']
                        ]
                    ]);
                    exit();
                } else {
                    error_log("DEBUG: Fallo de verificación de contraseña para: '" . $user['username'] . "'");
                    http_response_code(401); // Unauthorized
                    echo json_encode(['error' => 'Credenciales incorrectas.']);
                    exit();
                }
            } elseif ($action === 'logout') {
                error_log("DEBUG: Acción logout solicitada.");
                session_destroy();
                http_response_code(200);
                echo json_encode(['message' => 'Sesión cerrada correctamente.']);
                exit();
            } else {
                error_log("DEBUG: Acción POST no válida: '" . $action . "'");
                http_response_code(400);
                echo json_encode(['error' => 'Acción POST no válida.']);
                exit();
            }
            break;

        case 'GET':
            if ($action === 'check' || $action === 'status') {
                error_log("DEBUG: Acción GET (check/status) solicitada.");
                if (isset($_SESSION['user_id'])) {
                    $stmt = $pdo->prepare("
                        SELECT
                            u.id,
                            u.username,
                            u.full_name,
                            u.email,
                            ur.name AS role_name
                        FROM users u
                        JOIN users_roles ur ON u.role_id = ur.id
                        WHERE u.id = ?
                        LIMIT 1
                    ");
                    $stmt->execute([$_SESSION['user_id']]);
                    $user_session = $stmt->fetch(PDO::FETCH_ASSOC);

                    if ($user_session) {
                        error_log("DEBUG: Usuario en sesión válido: '" . $user_session['username'] . "'");
                        http_response_code(200);
                        echo json_encode([
                            'logged_in' => true,
                            'user' => $user_session
                        ]);
                    } else {
                        session_destroy();
                        error_log("DEBUG: Sesión inválida, usuario no encontrado en DB. Sesión destruida.");
                        http_response_code(401);
                        echo json_encode(['logged_in' => false, 'error' => 'Sesión inválida o usuario no encontrado.']);
                    }
                } else {
                    error_log("DEBUG: No hay sesión activa.");
                    http_response_code(401);
                    echo json_encode(['logged_in' => false]);
                }
                exit();
            } else {
                error_log("DEBUG: Acción GET no válida: '" . $action . "'");
                http_response_code(400);
                echo json_encode(['error' => 'Acción GET no válida.']);
                exit();
            }
            break;

        default:
            error_log("DEBUG: Método HTTP no permitido: '" . $method . "'");
            http_response_code(405); // Method Not Allowed
            echo json_encode(['error' => 'Método no permitido.']);
            exit();
    }
} catch (PDOException $e) {
    error_log("ERROR CRÍTICO (PDO) en auth.php: " . $e->getMessage());
    http_response_code(500); // Internal Server Error
    echo json_encode(['error' => 'Error de base de datos. Por favor, inténtelo de nuevo más tarde.']);
    exit();
} catch (Exception $e) {
    error_log("ERROR CRÍTICO (GENERAL) en auth.php: " . $e->getMessage());
    http_response_code(500); // Internal Server Error
    echo json_encode(['error' => 'Ocurrió un error inesperado en el servidor.']);
    exit();
}
// ---------------------------------------------------------------------
// ¡IMPORTANTE! En producción, QUITAR las líneas ini_set y error_reporting
// O moverlas a un entorno de desarrollo.
// ---------------------------------------------------------------------
?>