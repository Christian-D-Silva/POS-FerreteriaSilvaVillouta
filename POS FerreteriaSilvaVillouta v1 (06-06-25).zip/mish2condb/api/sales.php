<?php
// api/sales.php
require_once __DIR__ . '/../db_connection.php';

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

header('Content-Type: application/json');

// --- AÑADE ESTAS LÍNEAS TEMPORALMENTE PARA DEBUGGING (QUITAR EN PRODUCCIÓN) ---
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
// ----------------------------------------------------

try {
    // Obtener la conexión PDO desde db_connection.php
    $pdo = get_db_connection();
} catch (PDOException $e) {
    // Capturar cualquier error de conexión y devolverlo como JSON
    http_response_code(500);
    echo json_encode(['error' => 'Error de conexión a la base de datos: ' . $e->getMessage()]);
    exit();
}


if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['error' => 'Acceso no autorizado.']);
    exit();
}

$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? '';

switch ($method) {
    case 'GET':
        if ($action === 'list') {
            try {
                // Obtener historial de ventas con detalles de usuario y cliente
                $stmt = $pdo->prepare("
                    SELECT
                        s.id,
                        s.sale_date,
                        s.total_amount,
                        s.discount_amount,
                        s.tax_amount,
                        s.subtotal_amount,
                        s.document_type,                  -- Nombre de columna correcto de la tabla sales
                        c.razon_social AS client_name,    -- Usar 'razon_social' de la tabla 'clientes' y alias como 'client_name'
                        u.full_name AS user_name
                    FROM sales s
                    LEFT JOIN clientes c ON s.client_id = c.id -- Unirse a la tabla 'clientes' (en plural)
                    LEFT JOIN users u ON s.user_id = u.id
                    ORDER BY s.sale_date DESC
                ");
                $stmt->execute();
                $sales = $stmt->fetchAll(PDO::FETCH_ASSOC);
                echo json_encode($sales);
            } catch (PDOException $e) {
                http_response_code(500);
                echo json_encode(['error' => 'Error de base de datos al listar ventas: ' . $e->getMessage()]);
            }
        } elseif ($action === 'get_details') {
            try {
                $saleId = $_GET['id'] ?? null;
                if (!$saleId) {
                    http_response_code(400);
                    echo json_encode(['error' => 'ID de venta no proporcionado.']);
                    exit();
                }

                // Obtener detalles de la venta principal
                $stmt_sale = $pdo->prepare("
                    SELECT
                        s.id,
                        s.sale_date,
                        s.total_amount,
                        s.discount_amount,
                        s.tax_amount,
                        s.subtotal_amount,
                        s.document_type,                  -- Nombre de columna correcto
                        c.razon_social AS client_name,    -- Usar 'razon_social'
                        u.full_name AS user_name,
                        u.username AS user_username
                    FROM sales s
                    LEFT JOIN clientes c ON s.client_id = c.id -- Unirse a la tabla 'clientes'
                    LEFT JOIN users u ON s.user_id = u.id
                    WHERE s.id = ?
                ");
                $stmt_sale->execute([$saleId]);
                $saleDetails = $stmt_sale->fetch(PDO::FETCH_ASSOC);

                if (!$saleDetails) {
                    http_response_code(404);
                    echo json_encode(['error' => 'Venta no encontrada.']);
                    exit();
                }

                // Obtener los ítems de la venta con detalles del producto
                $stmt_items = $pdo->prepare("
                    SELECT
                        si.product_id,
                        si.quantity,
                        si.price_at_sale,
                        p.name AS product_name,
                        p.sku AS sku
                    FROM sale_items si
                    JOIN products p ON si.product_id = p.id
                    WHERE si.sale_id = ?
                ");
                $stmt_items->execute([$saleId]);
                $saleDetails['items'] = $stmt_items->fetchAll(PDO::FETCH_ASSOC);

                echo json_encode($saleDetails);

            } catch (PDOException $e) {
                http_response_code(500);
                echo json_encode(['error' => 'Error de base de datos al obtener detalles de venta: ' . $e->getMessage()]);
            }
        } elseif ($action === 'dashboard_summary') {
            try {
                // Ventas de Hoy
                $stmt_daily_sales = $pdo->prepare("SELECT SUM(total_amount) AS total FROM sales WHERE DATE(sale_date) = CURDATE()");
                $stmt_daily_sales->execute();
                $dailySales = $stmt_daily_sales->fetch(PDO::FETCH_ASSOC)['total'] ?? 0;

                // Transacciones de Hoy
                $stmt_daily_transactions = $pdo->prepare("SELECT COUNT(id) AS count FROM sales WHERE DATE(sale_date) = CURDATE()");
                $stmt_daily_transactions->execute();
                $dailyTransactions = $stmt_daily_transactions->fetch(PDO::FETCH_ASSOC)['count'] ?? 0;

                // Valor Total del Inventario
                $stmt_total_inventory = $pdo->prepare("SELECT SUM(price * stock) AS total FROM products");
                $stmt_total_inventory->execute();
                $totalInventoryValue = $stmt_total_inventory->fetch(PDO::FETCH_ASSOC)['total'] ?? 0;

                // Productos con Bajo Stock (ej. stock < 10)
                $stmt_low_stock = $pdo->prepare("SELECT COUNT(id) AS count FROM products WHERE stock < 10");
                $stmt_low_stock->execute();
                $lowStockCount = $stmt_low_stock->fetch(PDO::FETCH_ASSOC)['count'] ?? 0;

                // Ventas de Hoy para gráfico (últimas 24 horas o por horas del día)
                $sales_chart_data = [];
                // Para simplificar, obtenemos las ventas de las últimas 24 horas agrupadas por hora
                $stmt_chart_data = $pdo->prepare("
                    SELECT
                        DATE_FORMAT(sale_date, '%Y-%m-%d %H:00:00') AS hour_label,
                        SUM(total_amount) AS hourly_sales
                    FROM sales
                    WHERE sale_date >= DATE_SUB(NOW(), INTERVAL 24 HOUR)
                    GROUP BY hour_label
                    ORDER BY hour_label ASC
                ");
                $stmt_chart_data->execute();
                $raw_chart_data = $stmt_chart_data->fetchAll(PDO::FETCH_ASSOC);

                // Generar etiquetas para las últimas 24 horas
                $labels = [];
                $sales_data = [];
                for ($i = 23; $i >= 0; $i--) {
                    $hour = date('H', strtotime("-$i hours"));
                    $date = date('Y-m-d H:00:00', strtotime("-$i hours"));
                    $labels[] = date('H:00', strtotime($date)); // Formato HH:00
                    $found_sales = false;
                    foreach ($raw_chart_data as $row) {
                        if ($row['hour_label'] === $date) {
                            $sales_data[] = $row['hourly_sales'];
                            $found_sales = true;
                            break;
                        }
                    }
                    if (!$found_sales) {
                        $sales_data[] = 0; // Si no hay ventas para esa hora, añadir 0
                    }
                }


                echo json_encode([
                    'daily_sales' => $dailySales,
                    'daily_transactions' => $dailyTransactions,
                    'total_inventory_value' => $totalInventoryValue,
                    'low_stock_count' => $lowStockCount,
                    'sales_chart' => [
                        'labels' => $labels,
                        'data' => $sales_data
                    ]
                ]);

            } catch (PDOException $e) {
                http_response_code(500);
                echo json_encode(['error' => 'Error de base de datos al obtener resumen del dashboard: ' . $e->getMessage()]);
            }
        } else {
            http_response_code(400);
            echo json_encode(['error' => 'Acción GET no válida.']);
        }
        break;

    case 'POST': // Registrar nueva venta
        if ($action === 'record_sale') {
            $data = json_decode(file_get_contents('php://input'), true);

            // Validaciones básicas
            if (!isset($data['cart']) || !is_array($data['cart']) || empty($data['cart'])) {
                http_response_code(400);
                echo json_encode(['error' => 'Carrito de venta vacío o inválido.']);
                exit();
            }
            if (!isset($data['total_amount'], $data['subtotal_amount'])) {
                http_response_code(400);
                echo json_encode(['error' => 'Montos de venta incompletos.']);
                exit();
            }

            // Datos opcionales
            $discountAmount = $data['discount_amount'] ?? 0;
            $taxAmount = $data['tax_amount'] ?? 0;
            $documentType = $data['document_type'] ?? 'Boleta'; // Usar document_type
            $clientId = $data['client_id'] ?? null;
            $userId = $_SESSION['user_id']; // ID del usuario loggeado

            try {
                $pdo->beginTransaction();

                // 1. Insertar la venta en la tabla 'sales'
                $stmt_sale = $pdo->prepare("
                    INSERT INTO sales (sale_date, total_amount, discount_amount, tax_amount, subtotal_amount, document_type, client_id, user_id)
                    VALUES (NOW(), ?, ?, ?, ?, ?, ?, ?)
                ");
                $stmt_sale->execute([
                    $data['total_amount'],
                    $discountAmount,
                    $taxAmount,
                    $data['subtotal_amount'],
                    $documentType,
                    $clientId,
                    $userId
                ]);
                $saleId = $pdo->lastInsertId();

                // 2. Preparar statements para ítems y actualización de stock
                $stmt_item = $pdo->prepare("
                    INSERT INTO sale_items (sale_id, product_id, quantity, price_at_sale)
                    VALUES (?, ?, ?, ?)
                ");
                $stmt_update_stock = $pdo->prepare("
                    UPDATE products
                    SET stock = stock - ?
                    WHERE id = ? AND stock >= ?
                "); // Asegura que el stock no baje de 0

                // 3. Insertar cada ítem del carrito y actualizar el stock
                foreach ($data['cart'] as $item) {
                    if (!isset($item['product_id'], $item['quantity'], $item['price_at_sale'])) {
                        $pdo->rollBack();
                        http_response_code(400);
                        echo json_encode(['error' => 'Datos de producto en el carrito incompletos para ID: ' . ($item['product_id'] ?? 'desconocido')]);
                        exit();
                    }

                    $stmt_item->execute([$saleId, $item['product_id'], $item['quantity'], $item['price_at_sale']]);

                    // Actualizar stock, asegurando que no baje de 0
                    $stmt_update_stock->execute([$item['quantity'], $item['product_id'], $item['quantity']]);
                    if ($stmt_update_stock->rowCount() === 0) {
                        $pdo->rollBack();
                        http_response_code(400);
                        echo json_encode(['error' => 'No se pudo actualizar el stock para el producto con ID: ' . $item['product_id'] . '. Stock insuficiente o ID de producto inválido.']);
                        exit();
                    }
                }

                $pdo->commit();
                http_response_code(200);
                echo json_encode(['message' => 'Venta registrada exitosamente!', 'saleId' => $saleId]);

            } catch (PDOException $e) {
                $pdo->rollBack();
                http_response_code(500);
                echo json_encode(['error' => 'Error al registrar la venta: ' . $e->getMessage()]);
            }
        } else {
            http_response_code(400);
            echo json_encode(['error' => 'Acción POST no válida.']);
        }
        break;

    default:
        http_response_code(405); // Method Not Allowed
        echo json_encode(['error' => 'Método no permitido.']);
        break;
}
?>