<?php
// api/auth.php
require_once __DIR__ . '/../db_connection.php';
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
header('Content-Type: application/json');

$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? '';

switch ($action) {
    case 'login':
        if ($method === 'POST') {
            $input = json_decode(file_get_contents('php://input'), true);
            $username = $input['username'] ?? '';
            $password = $input['password'] ?? '';

            if (empty($username) || empty($password)) {
                http_response_code(400);
                echo json_encode(['success' => false, 'error' => 'Usuario y contraseña son requeridos.']);
                exit();
            }

            $conn = get_db_connection();
            try {
                // Modificado para usar role_id y JOIN con users_roles
                $stmt = $conn->prepare("SELECT u.id, u.username, u.password_hash, u.full_name, ur.name as role FROM users u JOIN users_roles ur ON u.role_id = ur.id WHERE u.username = ? AND u.is_active = TRUE");
                $stmt->bind_param("s", $username);
                $stmt->execute();
                $result = $stmt->get_result();
                $user = $result->fetch_assoc();
                $stmt->close();

                if ($user && password_verify($password, $user['password_hash'])) {
                    $_SESSION['user_id'] = $user['id'];
                    $_SESSION['username'] = $user['username'];
                    $_SESSION['full_name'] = $user['full_name'];
                    $_SESSION['role'] = $user['role']; // Guardar el nombre del rol

                    echo json_encode([
                        'success' => true,
                        'message' => 'Inicio de sesión exitoso.',
                        'user' => [
                            'id' => $user['id'],
                            'username' => $user['username'],
                            'full_name' => $user['full_name'],
                            'role' => $user['role']
                        ]
                    ]);
                } else {
                    http_response_code(401);
                    echo json_encode(['success' => false, 'error' => 'Usuario o contraseña incorrectos.']);
                }
            } catch (Exception $e) {
                http_response_code(500);
                echo json_encode(['success' => false, 'error' => 'Error de servidor al iniciar sesión: ' . $e->getMessage()]);
            } finally {
                $conn->close();
            }
        } else {
            http_response_code(405);
            echo json_encode(['error' => 'Método no permitido.']);
        }
        break;

    case 'logout':
        if ($method === 'POST') {
            session_unset();
            session_destroy();
            echo json_encode(['success' => true, 'message' => 'Sesión cerrada exitosamente.']);
        } else {
            http_response_code(405);
            echo json_encode(['error' => 'Método no permitido.']);
        }
        break;

    case 'status':
        if ($method === 'GET') {
            if (isset($_SESSION['user_id'])) {
                echo json_encode([
                    'logged_in' => true,
                    'user' => [
                        'id' => $_SESSION['user_id'],
                        'username' => $_SESSION['username'],
                        'full_name' => $_SESSION['full_name'],
                        'role' => $_SESSION['role']
                    ]
                ]);
            } else {
                echo json_encode(['logged_in' => false]);
            }
        } else {
            http_response_code(405);
            echo json_encode(['error' => 'Método no permitido.']);
        }
        break;

    default:
        http_response_code(400);
        echo json_encode(['error' => 'Acción no válida.']);
        break;
}
?>