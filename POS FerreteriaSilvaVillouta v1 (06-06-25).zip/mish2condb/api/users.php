<?php
// api/users.php
ini_set('display_errors', 1); // Temporal para depuración
ini_set('display_startup_errors', 1); // Temporal para depuración
error_reporting(E_ALL); // Temporal para depuración

require_once __DIR__ . '/../db_connection.php'; // ASEGÚRATE DE QUE ESTA RUTA ES CORRECTA

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

header('Content-Type: application/json');

$pdo = get_db_connection(); // Obtener la conexión PDO

if (!isset($_SESSION['user_id'])) {
    http_response_code(401); // Unauthorized
    echo json_encode(['error' => 'Acceso no autorizado. Debe iniciar sesión.']);
    exit();
}

// Puedes descomentar este bloque si quieres aplicar la restricción de permisos para ver usuarios
/*
if (isset($_SESSION['role']) && $_SESSION['role'] !== '1' && $_SESSION['role'] !== 1) { // Asumiendo que 1 es el ID del rol 'admin'
    http_response_code(403); // Forbidden
    echo json_encode(['error' => 'No tiene permisos para ver esta información.']);
    exit();
}
*/

$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? '';

switch ($method) {
    case 'GET':
        if ($action === 'list') {
            try {
                $stmt = $pdo->prepare("SELECT u.id, u.username, u.full_name, ur.role_name AS role FROM users u JOIN users_roles ur ON u.role_id = ur.id ORDER BY u.full_name ASC");
                $stmt->execute();
                $users = $stmt->fetchAll(PDO::FETCH_ASSOC);

                echo json_encode($users);

            } catch (PDOException $e) {
                http_response_code(500);
                echo json_encode(['error' => 'Error de base de datos al listar usuarios: ' . $e->getMessage()]);
                error_log('Error PDO en users.php: ' . $e->getMessage());
            }
        } else {
            http_response_code(400); // Bad Request
            echo json_encode(['error' => 'Acción GET no válida.']);
        }
        break;

    default:
        http_response_code(405);
        echo json_encode(['error' => 'Método no permitido.']);
        break;
}
?>