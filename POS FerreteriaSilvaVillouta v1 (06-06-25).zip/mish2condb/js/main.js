// js/main.js

document.addEventListener('DOMContentLoaded', () => {
    // Inicialización de iconos Lucide al cargar el DOM
    if (window.lucide) {
        window.lucide.createIcons();
    }

    // --- DATOS GLOBALES (Ahora se cargarán desde la DB, pero se mantienen como "cache" local) ---
    // Inicializar como arrays vacíos
    window.categories = [];
    window.products = [];
    window.salesHistory = []; // Esto se cargará desde la DB
    window.clients = []; // Nuevo para clientes
    window.cart = []; // El carrito sigue siendo local al usuario
    window.currentUser = null; // Información del usuario loggeado
    window.users = []; // Para la gestión de usuarios
    window.roles = []; // Para los roles de usuario

    // Referencias a elementos DOM que podrían existir globalmente en index.html
    const loginPage = document.getElementById('login-page');
    const mainApp = document.getElementById('main-app');
    const loginForm = document.getElementById('login-form');
    const logoutBtn = document.getElementById('logout-btn');
    const mainContentArea = document.getElementById('main-content-area');
    const sidebarNav = document.getElementById('sidebar-nav');
    const currentUserSpan = document.getElementById('current-user-info'); // Para mostrar el usuario loggeado
    const loginErrorMessage = document.getElementById('login-error-message'); // Mensaje de error en el login

    // --- FUNCIONES GLOBALES PRINCIPALES ---

    // Función para formatear moneda (CLP sin decimales)
    window.formatCurrency = (amount) => {
        return new Intl.NumberFormat('es-CL', {
            style: 'currency',
            currency: 'CLP',
            minimumFractionDigits: 0,
            maximumFractionDigits: 0,
        }).format(amount);
    };

    // Función para mostrar un toast
    window.showToast = (message, isError = false) => {
        const toast = document.getElementById('toast');
        if (toast) {
            toast.textContent = message;
            toast.classList.remove('hidden', 'bg-green-500', 'bg-red-500');
            toast.classList.add(isError ? 'bg-red-500' : 'bg-green-500', 'flex', 'items-center', 'justify-center');
            setTimeout(() => {
                toast.classList.add('hidden');
            }, 3000);
        }
    };

    // Función para mostrar la página de login
    window.showLoginPage = () => {
        if (loginPage) {
            loginPage.classList.remove('hidden');
        }
        if (mainApp) {
            mainApp.classList.add('hidden');
        }
        window.currentUser = null; // Limpiar usuario actual
        // Limpiar campos del formulario de login
        if (loginForm) {
            loginForm.reset();
            if (loginErrorMessage) {
                loginErrorMessage.classList.add('hidden');
            }
        }
        // console.log("Mostrando página de login.");
    };

    // Función para mostrar la aplicación principal
    window.showMainApp = () => {
        if (loginPage) {
            loginPage.classList.add('hidden');
        }
        if (mainApp) {
            mainApp.classList.remove('hidden');
        }
        // console.log("Mostrando aplicación principal.");
    };

    // Función para cargar contenido de las páginas dinámicamente
    window.switchPage = async (pageName) => {
        console.log(`Cambiando a página: ${pageName}`);
        try {
            // Construye la URL completa asumiendo que las páginas HTML están en la carpeta 'pages/'
            const url = `pages/${pageName}.html`;
            const response = await fetch(url);

            if (!response.ok) {
                // Si la página HTML no se encuentra, pero es una ruta esperada, loguea un warning.
                // Si es un 404 para cualquier otra cosa, lanza un error.
                if (response.status === 404) {
                    console.warn(`Página no encontrada: ${url}. Verifique que el archivo exista.`);
                    window.showToast(`Error: Página ${pageName} no encontrada.`, true);
                    return;
                }
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            const htmlContent = await response.text();

            if (mainContentArea) {
                mainContentArea.innerHTML = htmlContent;
                console.log(`Contenido de ${url} cargado.`);

                // Reinicializar iconos Lucide para el nuevo contenido cargado
                if (window.lucide) {
                    window.lucide.createIcons();
                }

                // Espera un momento para que el DOM se renderice antes de inicializar el módulo
                setTimeout(() => {
                    // console.log(`Intentando inicializar módulo para: ${pageName}`);
                    const initializer = window.moduleInitializers[pageName];
                    if (initializer && typeof initializer === 'function') {
                        initializer();
                        // console.log(`Módulo ${pageName} inicializado.`);
                    } else {
                        // console.warn(`No se encontró función de inicialización para la página: ${pageName}`);
                    }
                }, 50); // Pequeño retardo para asegurar que el DOM está listo
            } else {
                console.error('Elemento main-content-area no encontrado.');
                window.showToast('Error interno: Área de contenido principal no encontrada.', true);
            }
        } catch (error) {
            console.error(`Error al cargar la página ${pageName}:`, error);
            window.showToast(`Error al cargar la página ${pageName}. Detalles en consola.`, true);
        }
    };

    // Función para cargar todos los datos de la API
    window.loadDataFromAPI = async () => {
        try {
            // Cargar productos
            const productsResponse = await fetch('api/products.php?action=list');
            if (!productsResponse.ok) throw new Error('Failed to load products');
            window.products = await productsResponse.json();
            // console.log('Productos cargados:', window.products.length);

            // Cargar categorías (si tu dashboard las necesita o si hay gestión de productos)
            const categoriesResponse = await fetch('api/products.php?action=list_categories'); // <--- AHORA LLAMA A PRODUCTS.PHP
            if (categoriesResponse.ok) {
                window.categories = await categoriesResponse.json();
                console.log('Categorías cargadas:', window.categories.length);
            }

            // Cargar historial de ventas
            const salesHistoryResponse = await fetch('api/sales.php?action=list');
            if (!salesHistoryResponse.ok) throw new Error('Failed to load sales history');
            window.salesHistory = await salesHistoryResponse.json();
            // console.log('Historial de ventas cargado:', window.salesHistory.length);

            // Cargar clientes
            const clientsResponse = await fetch('api/clients.php?action=list');
            if (!clientsResponse.ok) throw new Error('Failed to load clients');
            window.clients = await clientsResponse.json();
            // console.log('Clientes cargados:', window.clients.length);

            // Cargar usuarios (si el usuario actual es admin o tiene permisos)
            // Asegúrate de que el backend users.php maneje los permisos antes de devolver datos sensibles
            if (window.currentUser && (window.currentUser.role === '1' || window.currentUser.role === 1)) { // Asumiendo '1' es el ID de rol para admin
                 const usersResponse = await fetch('api/users.php?action=list');
                 if (!usersResponse.ok) {
                     // Solo lanza error si no es un 403 (Forbidden), ya que el 403 es un permiso denegado esperado.
                     if (usersResponse.status !== 403) {
                         throw new Error(`Failed to load users: ${usersResponse.statusText}`);
                     } else {
                         console.warn('Acceso denegado a usuarios. El usuario no tiene permisos de administrador.');
                         window.showToast('No tiene permisos para ver la lista de usuarios.', true);
                         window.users = []; // Asegúrate de que la lista de usuarios esté vacía si no hay permisos
                     }
                 } else {
                     window.users = await usersResponse.json();
                     // console.log('Usuarios cargados:', window.users.length);
                 }
            } else {
                window.users = []; // Si no es admin, no hay usuarios cargados
            }

            // Cargar roles (útil para la gestión de usuarios)
            const rolesResponse = await fetch('api/roles.php?action=list');
            if (!rolesResponse.ok) throw new Error('Failed to load roles');
            window.roles = await rolesResponse.json();
            // console.log('Roles cargados:', window.roles.length);

            // console.log('Todos los datos cargados exitosamente.');
        } catch (error) {
            console.error('Error al cargar datos de la API:', error);
            window.showToast(`Error al cargar datos: ${error.message}`, true);
        }
    };


    // --- MANEJO DE EVENTOS DE INTERFAZ ---

    // Manejo del formulario de login
    // Asegúrate de que loginForm esté disponible, ya que showLoginPage puede cargar el HTML del login dinámicamente.
    if (loginForm) {
        loginForm.addEventListener('submit', async (event) => {
            event.preventDefault(); // ¡CRÍTICO! Previene el envío por defecto del formulario

            if (loginErrorMessage) {
                loginErrorMessage.classList.add('hidden'); // Ocultar mensaje de error anterior
            }

            const username = loginForm.username.value;
            const password = loginForm.password.value;

            try {
                const response = await fetch('api/auth.php?action=login', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({ username, password }),
                });

                const data = await response.json();

                if (response.ok && data.success) {
                    window.currentUser = data.user;
                    if (currentUserSpan) currentUserSpan.textContent = `Bienvenido, ${window.currentUser.full_name || window.currentUser.username} (${window.currentUser.role_name || window.currentUser.role})`;
                    window.showMainApp(); // Mostrar la aplicación principal
                    await window.loadDataFromAPI(); // Cargar datos iniciales después del login
                    window.switchPage('dashboard'); // Cargar el dashboard (nombre de la página, sin 'pages/')
                    window.showToast('Sesión iniciada correctamente.');
                } else {
                    const errorMessage = data.error || 'Credenciales inválidas.';
                    if (loginErrorMessage) {
                        loginErrorMessage.textContent = errorMessage;
                        loginErrorMessage.classList.remove('hidden');
                    }
                    window.showToast(errorMessage, true);
                }
            } catch (error) {
                console.error('Error en el login:', error);
                if (loginErrorMessage) {
                    loginErrorMessage.textContent = 'Error de conexión o servidor.';
                    loginErrorMessage.classList.remove('hidden');
                }
                window.showToast('Error de conexión o servidor al iniciar sesión.', true);
            }
        });
    }

    // Manejo del botón de logout
    if (logoutBtn) {
        logoutBtn.addEventListener('click', async () => {
            if (confirm('¿Estás seguro de que quieres cerrar sesión?')) {
                try {
                    const response = await fetch('api/auth.php?action=logout');
                    const data = await response.json();
                    if (response.ok && data.success) {
                        window.showToast('Sesión cerrada correctamente.');
                        window.currentUser = null; // Limpiar el usuario actual
                        window.showLoginPage(); // Volver a la página de login
                    } else {
                        window.showToast(data.error || 'Error al cerrar sesión.', true);
                    }
                } catch (error) {
                    console.error('Error al cerrar sesión:', error);
                    window.showToast('Error de conexión al cerrar sesión.', true);
                }
            }
        });
    }

    // Navegación de la barra lateral
    if (sidebarNav) {
        sidebarNav.addEventListener('click', (event) => {
            const button = event.target.closest('button[data-page]');
            if (button) {
                const page = button.dataset.page;
                window.switchPage(page); // Llama a switchPage con el nombre de la página
            }
        });
    }


    // --- Inicializadores de módulos (funciones que se llamarán cuando se cargue una página específica) ---
    // Asegúrate de que las funciones initDashboard, initClientes, etc., estén definidas en sus respectivos archivos JS (ej. dashboard.js, clients.js)
    window.moduleInitializers = {
        dashboard: window.initDashboard,
        clients: window.initClientes,
        sales: window.initVentas, // Asegúrate que el archivo ventas.js exporta initVentas
        history: window.initHistorial, // Asegúrate que historial.js exporta initHistorial
        // Agrega aquí los inicializadores para otras páginas que tengas (productos, usuarios, etc.)
        // products: window.initProductos,
        // users: window.initUsuarios,
        // categories: window.initCategorias
    };


    // --- Verificación de estado de login al cargar la aplicación ---
    window.checkLoginStatus = async () => {
        try {
            const response = await fetch('api/auth.php?action=status');
            if (!response.ok) {
                 throw new Error(`HTTP error! status: ${response.status}`);
            }
            const data = await response.json();

            if (data.logged_in) {
                window.currentUser = data.user;
                // Usar role_name si viene del backend, si no, fallback a role
                if (currentUserSpan) currentUserSpan.textContent = `Bienvenido, ${window.currentUser.full_name || window.currentUser.username} (${window.currentUser.role_name || window.currentUser.role})`;
                window.showMainApp(); // Mostrar la app si ya está loggeado
                await window.loadDataFromAPI(); // Cargar datos iniciales
                window.switchPage('dashboard'); // Cargar dashboard por defecto
            } else {
                window.showLoginPage(); // Mostrar login si no está loggeado
            }
        } catch (error) {
            console.error('Error al verificar estado de login:', error);
            // Si el error es de red (no hay respuesta), la página de login es el fallback seguro.
            window.showToast('Error de conexión al verificar sesión. Detalles en consola.', true);
            window.showLoginPage(); // Por seguridad, mostrar login en caso de error
        }
    };

    // Ejecutar la verificación de login al cargar el DOM
    window.checkLoginStatus();
});