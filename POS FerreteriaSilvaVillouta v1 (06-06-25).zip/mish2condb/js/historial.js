// js/historial.js

// Función de inicialización principal para el módulo de Historial de Ventas
window.initHistorial = async () => {
    console.log('Inicializando Historial de Ventas...');

    // Usamos requestAnimationFrame para asegurar que el DOM esté completamente renderizado
    requestAnimationFrame(async () => {
        // 1. Obtener todas las referencias a los elementos DOM localmente dentro de initHistorial
        let historyTableBody = document.getElementById('history-table-body');
        let historyDateFilter = document.getElementById('history-date-filter');
        let clearHistoryFilterBtn = document.getElementById('clear-history-filter');
        let saleDetailsModal = document.getElementById('sale-details-modal');
        let saleDetailsContent = document.getElementById('sale-details-content');
        let closeSaleDetailsModalBtn = document.getElementById('close-sale-details-modal-btn');

        // Validación básica de elementos
        if (!historyTableBody || !historyDateFilter || !clearHistoryFilterBtn || !saleDetailsModal || !saleDetailsContent || !closeSaleDetailsModalBtn) {
            console.error("Error: Algunos elementos principales del DOM de historial de ventas no se encontraron. Asegúrate de que historial.html esté cargado correctamente.");
            return;
        }

        // --- FUNCIONES AUXILIARES INTERNAS DEL MÓDULO DE HISTORIAL ---

        async function loadSalesHistory() {
            try {
                // Asegurarse de que los datos globales (salesHistory, clients, products, users) estén cargados
                if (!window.salesHistory || window.salesHistory.length === 0 ||
                    !window.clients || window.clients.length === 0 ||
                    !window.products || window.products.length === 0 ||
                    !window.users || window.users.length === 0) {
                    await window.loadDataFromAPI();
                }
                renderSalesHistory();
            } catch (error) {
                console.error('Error al cargar historial de ventas:', error);
                window.showToast('Error al cargar el historial de ventas.', true);
            }
        }

        function renderSalesHistory() {
            historyTableBody.innerHTML = ''; // Limpiar tabla antes de renderizar

            let filteredSales = window.salesHistory;
            const filterDate = historyDateFilter.value;

            if (filterDate) {
                filteredSales = filteredSales.filter(sale => {
                    const saleDate = new Date(sale.sale_date).toISOString().split('T')[0];
                    return saleDate === filterDate;
                });
            }

            if (filteredSales.length === 0) {
                historyTableBody.innerHTML = '<tr><td colspan="8" class="py-4 text-center text-gray-500">No hay ventas registradas para la fecha seleccionada.</td></tr>';
                return;
            }

            filteredSales.forEach(sale => {
                const client = window.clients.find(c => c.id == sale.client_id);
                const userName = window.users.find(u => u.id == sale.user_id)?.full_name || 'Desconocido';
                const row = historyTableBody.insertRow();
                row.className = 'hover:bg-gray-50';
                row.innerHTML = `
                    <td class="p-3">${sale.id}</td>
                    <td class="p-3">${new Date(sale.sale_date).toLocaleDateString('es-CL')}</td>
                    <td class="p-3">${new Date(sale.sale_date).toLocaleTimeString('es-CL', { hour: '2-digit', minute: '2-digit' })}</td>
                    <td class="p-3">${sale.document_type}</td>
                    <td class="p-3">${client ? client.razon_social : 'Consumidor Final'}</td>
                    <td class="p-3">${userName}</td>
                    <td class="p-3">${window.formatCurrency(sale.total_amount)}</td>
                    <td class="p-3 text-center">
                        <button class="text-blue-500 hover:text-blue-700" title="Ver Detalles" onclick="window.viewSaleDetails(${sale.id})">
                            <span data-lucide="eye" class="lucide-icon w-5 h-5"></span>
                        </button>
                    </td>
                `;
            });
            // Re-renderizar iconos Lucide si se añaden dinámicamente
            if (window.lucide) {
                window.lucide.createIcons();
            }
        }

        async function viewSaleDetails(saleId) {
            try {
                // Buscar la venta en el historial ya cargado
                const saleDetails = window.salesHistory.find(s => s.id == saleId);

                if (!saleDetails) {
                    console.error('Detalles de venta no encontrados para ID:', saleId);
                    window.showToast('Detalles de venta no encontrados.', true);
                    return;
                }

                // Cargar ítems de la venta si no están ya en el objeto de venta
                // Esto es crucial si 'salesHistory' solo trae los datos principales de la venta y no los ítems
                if (!saleDetails.items) {
                    const response = await fetch(`api/sales.php?action=details&id=${saleId}`);
                    if (!response.ok) {
                        throw new Error(`Error al obtener detalles de venta: ${response.statusText}`);
                    }
                    const data = await response.json();
                    saleDetails.items = data.items; // Añadir los ítems a la venta cargada
                }

                const client = window.clients.find(c => c.id == saleDetails.client_id);
                const user = window.users.find(u => u.id == saleDetails.user_id);

                const dateStr = new Date(saleDetails.sale_date).toLocaleDateString('es-CL');
                const timeStr = new Date(saleDetails.sale_date).toLocaleTimeString('es-CL', { hour: '2-digit', minute: '2-digit' });

                const clientInfo = client ? `<p><strong>Cliente:</strong> ${client.razon_social} (RUT: ${client.rut})</p>` : `<p><strong>Cliente:</strong> Consumidor Final</p>`;
                const userInfo = user ? `<p><strong>Vendedor:</strong> ${user.full_name}</p>` : `<p><strong>Vendedor:</strong> Desconocido</p>`;

                // Calcular subtotal de ítems para mostrar en el modal (puede ser diferente al subtotal_amount si hay descuento fijo)
                const itemsSubtotal = saleDetails.items.reduce((sum, item) => sum + (item.quantity * item.price_at_sale), 0);


                saleDetailsContent.innerHTML = `
                    <p><strong>ID Venta:</strong> ${saleDetails.id}</p>
                    <p><strong>Fecha:</strong> ${dateStr} ${timeStr}</p>
                    <p><strong>Tipo Documento:</strong> ${saleDetails.document_type}</p>
                    ${clientInfo}
                    ${userInfo}
                    <h4 class="text-lg font-semibold mb-2">Productos:</h4>
                    <ul class="list-disc pl-5 mb-4">
                        ${saleDetails.items.map(item => {
                            const product = window.products.find(p => p.id == item.product_id);
                            const productName = product ? product.name : `Producto ID: ${item.product_id}`;
                            const productSku = product ? `(SKU: ${product.sku})` : '';
                            return `<li>${productName} ${productSku} - ${item.quantity} x ${window.formatCurrency(item.price_at_sale)} = ${window.formatCurrency(item.quantity * item.price_at_sale)}</li>`;
                        }).join('')}
                    </ul>
                    <p><strong>Subtotal de Ítems:</strong> ${window.formatCurrency(itemsSubtotal)}</p>
                    <p><strong>Descuento Aplicado:</strong> -${window.formatCurrency(saleDetails.discount_amount)}</p>
                    <p class="text-xl font-semibold mt-2">IVA (19%): ${window.formatCurrency(saleDetails.tax_amount)}</p>
                    <p class="text-2xl font-bold mt-2">Total Final: ${window.formatCurrency(saleDetails.total_amount)}</p>
                `;
                saleDetailsModal.classList.remove('hidden');

            } catch (error) {
                console.error('Error al mostrar detalles de venta:', error);
                window.showToast(`Error al cargar los detalles de la venta: ${error.message}`, true);
            }
        }

        // --- ASIGNACIONES DE FUNCIONES AL OBJETO WINDOW ---
        // Se hace para que puedan ser llamadas desde el HTML (onclick) o desde main.js
        window.renderSalesHistory = renderSalesHistory;
        window.viewSaleDetails = viewSaleDetails;

        // --- CONFIGURACIÓN DE EVENT LISTENERS ---
        historyDateFilter.addEventListener('change', () => window.renderSalesHistory());
        clearHistoryFilterBtn.addEventListener('click', () => {
            historyDateFilter.value = ''; // Limpiar el filtro de fecha
            window.renderSalesHistory(); // Re-renderizar sin filtro
        });
        closeSaleDetailsModalBtn.addEventListener('click', () => saleDetailsModal.classList.add('hidden'));


        // Cargar y renderizar historial al iniciar el módulo
        await loadSalesHistory();

        // Actualizar iconos Lucide para esta sección
        if (window.lucide) {
            window.lucide.createIcons();
        }
    });
};