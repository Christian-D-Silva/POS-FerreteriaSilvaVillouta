// js/productos.js (VERSIÓN FINAL CON REFERENCIAS DOM MOVIDAS)

// Las referencias a elementos DOM YA NO SE DECLARAN AQUÍ GLOBALMENTE AL PRINCIPIO.
// Se obtendrán dentro de window.initProductos para asegurar que el HTML esté cargado.

// --- NUEVA FUNCIÓN: POPULATE CATEGORIES ---
// Ahora acepta los elementos select como parámetros para mayor robustez
window.populateCategories = (productCategorySelect, filterCategorySelect) => {
    // Asegurarse de que window.categories esté disponible y sea un array
    if (!window.categories || !Array.isArray(window.categories)) {
        console.error('Error: window.categories no está cargado o no es un array.');
        return;
    }

    // Llenar el select del filtro de categorías
    if (filterCategorySelect) {
        // Limpiar opciones existentes, manteniendo la opción "Todas las categorías"
        filterCategorySelect.innerHTML = '<option value="all">Todas las categorías</option>';
        window.categories.forEach(category => {
            const option = document.createElement('option');
            option.value = category.id;
            option.textContent = category.name;
            filterCategorySelect.appendChild(option);
        });
    }

    // Llenar el select de categorías en el modal de producto
    if (productCategorySelect) {
        // Limpiar opciones existentes
        productCategorySelect.innerHTML = '<option value="">Selecciona una categoría</option>'; // Opción por defecto
        window.categories.forEach(category => {
            const option = document.createElement('option');
            option.value = category.id;
            option.textContent = category.name;
            productCategorySelect.appendChild(option);
        });
    }
};

// --- Funciones del Modal de Productos ---
// Ahora acepta las referencias del modal como parámetros para mayor robustez
window.openProductModal = (productModal, productForm, modalTitle, productIdInput, productNameInput, productSkuInput, productDescriptionInput, productPriceInput, productStockInput, productCategorySelect, product = null) => {
    // Asegurarse de que todos los elementos necesarios estén presentes
    if (!productModal || !productForm || !modalTitle || !productIdInput || !productNameInput || !productSkuInput || !productDescriptionInput || !productPriceInput || !productStockInput || !productCategorySelect) {
        console.error("Error: Elementos del modal de producto no encontrados al intentar abrir el modal.");
        return;
    }

    productForm.reset(); // Limpiar formulario
    productIdInput.value = ''; // Limpiar ID oculto

    // Asegurar que las categorías estén cargadas y los selects rellenados
    // Aquí solo necesitamos rellenar el select del modal, el filtro ya se llenó en initProductos
    window.populateCategories(productCategorySelect, null); // Pasamos null para el filtro ya que solo nos interesa el select del modal aquí

    if (product) {
        modalTitle.textContent = 'Editar Producto';
        productIdInput.value = product.id;
        productNameInput.value = product.name;
        productSkuInput.value = product.sku;
        productDescriptionInput.value = product.description;
        productPriceInput.value = product.price;
        productStockInput.value = product.stock;
        productCategorySelect.value = product.category_id; // Seleccionar la categoría del producto
    } else {
        modalTitle.textContent = 'Agregar Nuevo Producto';
    }

    productModal.classList.remove('hidden');
    // Para Tailwind CSS: añadir 'flex' para mostrar, quitar 'hidden'
    productModal.classList.add('flex');
};

window.closeProductModal = (productModal) => { // Acepta el modal como parámetro
    if (productModal) {
        productModal.classList.add('hidden');
        productModal.classList.remove('flex');
    }
};

// --- Funciones de Renderizado de Tablas ---
// Ahora acepta el tbody como parámetro para mayor robustez
window.renderProductTable = (productTableBody, productsToRender = window.products) => {
    
    if (!productTableBody) {
        console.error('Error: productTableBody no encontrado al renderizar productos.');
        return;
    }

    productTableBody.innerHTML = ''; // Limpiar tabla

    if (productsToRender.length === 0) {
        productTableBody.innerHTML = '<tr><td colspan="8" class="px-6 py-4 text-center text-gray-500">No hay productos disponibles.</td></tr>';
        return;
    }

    productsToRender.forEach(product => {
        const row = document.createElement('tr');
        row.className = 'border-b last:border-0 hover:bg-gray-50';
        row.innerHTML = `
            <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">${product.id}</td>
            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${product.name}</td>
            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${product.sku}</td>
            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${product.description || 'N/A'}</td>
            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${window.formatCurrency(product.price)}</td>
            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${product.stock}</td>
            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${product.category_name || 'Sin Categoría'}</td>
            <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                <button class="text-indigo-600 hover:text-indigo-900 mr-2 edit-product-btn" data-id="${product.id}">Editar</button>
                <button class="text-red-600 hover:text-red-900 delete-product-btn" data-id="${product.id}">Eliminar</button>
            </td>
        `;
        productTableBody.appendChild(row);
    });

    // Los listeners para los botones de editar/eliminar productos se adjuntan aquí
    // ya que los botones se recrean cada vez que la tabla se renderiza.
    productTableBody.querySelectorAll('.edit-product-btn').forEach(button => {
        button.addEventListener('click', (e) => {
            const productId = e.target.dataset.id;
            const productToEdit = window.products.find(p => p.id == productId);
            if (productToEdit) {
                // Obtener todas las referencias necesarias para openProductModal en el momento de la llamada
                const productModal = document.getElementById('product-modal');
                const productForm = document.getElementById('product-form');
                const modalTitle = document.getElementById('modal-title');
                const productIdInput = document.getElementById('product-id');
                const productNameInput = document.getElementById('product-name');
                const productSkuInput = document.getElementById('product-sku');
                const productDescriptionInput = document.getElementById('product-description');
                const productPriceInput = document.getElementById('product-price');
                const productStockInput = document.getElementById('product-stock');
                const productCategorySelect = document.getElementById('product-category');

                window.openProductModal(
                    productModal, productForm, modalTitle,
                    productIdInput, productNameInput, productSkuInput, productDescriptionInput,
                    productPriceInput, productStockInput, productCategorySelect,
                    productToEdit
                );
            }
        });
    });

    productTableBody.querySelectorAll('.delete-product-btn').forEach(button => {
        button.addEventListener('click', (e) => {
            const productId = e.target.dataset.id;
            if (confirm('¿Estás seguro de que quieres eliminar este producto?')) {
                window.deleteProduct(productId);
            }
        });
    });
};

window.renderCategoryTable = (categoryTableBody) => { // Acepta el tbody como parámetro
    
    if (!categoryTableBody) {
        console.error('Error: categoryTableBody no encontrado al renderizar categorías.');
        return;
    }

    categoryTableBody.innerHTML = ''; // Limpiar tabla

    if (window.categories.length === 0) {
        categoryTableBody.innerHTML = '<tr><td colspan="3" class="px-6 py-4 text-center text-gray-500">No hay categorías disponibles.</td></tr>';
        return;
    }

    window.categories.forEach(category => {
        const row = document.createElement('tr');
        row.className = 'border-b last:border-0 hover:bg-gray-50';
        row.innerHTML = `
            <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">${category.id}</td>
            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${category.name}</td>
            <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                <button class="text-indigo-600 hover:text-indigo-900 mr-2 edit-category-btn" data-id="${category.id}" data-name="${category.name}">Editar</button>
                <button class="text-red-600 hover:text-red-900 delete-category-btn" data-id="${category.id}">Eliminar</button>
            </td>
        `;
        categoryTableBody.appendChild(row);
    });

    // Los listeners para los botones de editar/eliminar categorías se adjuntan aquí
    categoryTableBody.querySelectorAll('.edit-category-btn').forEach(button => {
        button.addEventListener('click', (e) => {
            const categoryId = e.target.dataset.id;
            const categoryName = e.target.dataset.name;
            const newName = prompt('Editar nombre de categoría:', categoryName);
            if (newName !== null && newName.trim() !== '') {
                window.editCategory(categoryId, newName.trim());
            } else if (newName !== null) {
                window.showToast('El nombre de la categoría no puede estar vacío.', true);
            }
        });
    });

    categoryTableBody.querySelectorAll('.delete-category-btn').forEach(button => {
        button.addEventListener('click', (e) => {
            const categoryId = e.target.dataset.id;
            if (confirm('¿Estás seguro de que quieres eliminar esta categoría? Esto podría afectar a los productos asociados.')) {
                window.deleteCategory(categoryId);
            }
        });
    });
};


// --- Funciones de Interacción con la API (CRUD de Productos y Categorías) ---
// Estas funciones ahora obtienen las referencias DOM necesarias justo antes de usarlas
// para asegurarse de que siempre estén disponibles.
window.addProduct = async (productData) => {
    try {
        const response = await fetch('api/products.php?action=add', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(productData)
        });
        const data = await response.json();
        if (response.ok) {
            window.showToast(data.message || 'Producto agregado exitosamente.');
            const productModal = document.getElementById('product-modal'); // Obtener referencia aquí
            window.closeProductModal(productModal);
            await window.loadDataFromAPI(); // Recargar todos los datos globales
            const productTableBody = document.getElementById('product-table-body'); // Obtener referencia aquí
            window.renderProductTable(productTableBody); // Volver a renderizar la tabla de productos
        } else {
            window.showToast(data.error || 'Error al agregar producto.', true);
        }
    } catch (error) {
        console.error('Error de red al agregar producto:', error);
        window.showToast('Error de conexión al agregar producto.', true);
    }
};

window.editProduct = async (productData) => {
    try {
        const productId = productData.id;
        const response = await fetch(`api/products.php?action=update&id=${productId}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(productData)
        });
        const data = await response.json();
        if (response.ok) {
            window.showToast(data.message || 'Producto actualizado exitosamente.');
            const productModal = document.getElementById('product-modal');
            window.closeProductModal(productModal);
            await window.loadDataFromAPI(); // Recargar todos los datos globales
            const productTableBody = document.getElementById('product-table-body');
            window.renderProductTable(productTableBody);
        } else {
            window.showToast(data.error || 'Error al actualizar producto.', true);
        }
    } catch (error) {
        console.error('Error de red al actualizar producto:', error);
        window.showToast('Error de conexión al actualizar producto.', true);
    }
};

window.deleteProduct = async (id) => {
    try {
        const response = await fetch(`api/products.php?action=delete&id=${id}`, {
            method: 'DELETE'
        });
        const data = await response.json();
        if (response.ok) {
            window.showToast(data.message || 'Producto eliminado exitosamente.');
            await window.loadDataFromAPI(); // Recargar todos los datos globales
            const productTableBody = document.getElementById('product-table-body');
            window.renderProductTable(productTableBody);
        } else {
            window.showToast(data.error || 'Error al eliminar producto.', true);
        }
    } catch (error) {
        console.error('Error de red al eliminar producto:', error);
        window.showToast('Error de conexión al eliminar producto.', true);
    }
};

window.addCategory = async (name) => {
    try {
        const response = await fetch('api/products.php?action=add_category', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ name: name })
        });
        const data = await response.json();
        if (response.ok) {
            window.showToast(data.message || 'Categoría agregada exitosamente.');
            await window.loadDataFromAPI(); // Recargar categorías y productos
            const productCategorySelect = document.getElementById('product-category');
            const productCategoryFilter = document.getElementById('product-category-filter');
            window.populateCategories(productCategorySelect, productCategoryFilter); // Volver a poblar los selects
            const categoryTableBody = document.getElementById('category-table-body');
            window.renderCategoryTable(categoryTableBody); // Volver a renderizar la tabla de categorías
        } else {
            window.showToast(data.error || 'Error al agregar categoría.', true);
        }
    } catch (error) {
        console.error('Error de red al agregar categoría:', error);
        window.showToast('Error de conexión al agregar categoría.', true);
    }
};

window.editCategory = async (id, name) => {
    try {
        const response = await fetch(`api/products.php?action=update_category&id=${id}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ name: name })
        });
        const data = await response.json();
        if (response.ok) {
            window.showToast(data.message || 'Categoría actualizada exitosamente.');
            await window.loadDataFromAPI(); // Recargar categorías y productos
            const productCategorySelect = document.getElementById('product-category');
            const productCategoryFilter = document.getElementById('product-category-filter');
            window.populateCategories(productCategorySelect, productCategoryFilter); // Volver a poblar los selects
            const categoryTableBody = document.getElementById('category-table-body');
            window.renderCategoryTable(categoryTableBody); // Volver a renderizar la tabla de categorías
        } else {
            window.showToast(data.error || 'Error al actualizar categoría.', true);
        }
    } catch (error) {
        console.error('Error de red al actualizar categoría:', error);
        window.showToast('Error de conexión al actualizar categoría.', true);
    }
};

window.deleteCategory = async (id) => {
    try {
        const response = await fetch(`api/products.php?action=delete_category&id=${id}`, {
            method: 'DELETE'
        });
        const data = await response.json();
        if (response.ok) {
            window.showToast(data.message || 'Categoría eliminada exitosamente.');
            await window.loadDataFromAPI(); // Recargar categorías y productos
            const productCategorySelect = document.getElementById('product-category');
            const productCategoryFilter = document.getElementById('product-category-filter');
            window.populateCategories(productCategorySelect, productCategoryFilter); // Volver a poblar los selects
            const categoryTableBody = document.getElementById('category-table-body');
            window.renderCategoryTable(categoryTableBody); // Volver a renderizar la tabla de categorías
        } else {
            window.showToast(data.error || 'Error al eliminar categoría.', true);
        }
    } catch (error) {
        console.error('Error de red al eliminar categoría:', error);
        window.showToast('Error de conexión al eliminar categoría.', true);
    }
};


// --- Función de Inicialización de la Página de Productos ---
// Esta función se llama desde main.js DESPUÉS de que productos.html se ha cargado en el DOM.
window.initProductos = async () => {
    

    // 1. Obtener todas las referencias a los elementos DOM AQUÍ, cuando el HTML ya está cargado.
    const productModal = document.getElementById('product-modal');
    const productForm = document.getElementById('product-form');
    const modalTitle = document.getElementById('modal-title');
    const addProductBtn = document.getElementById('add-product-btn');
    const closeProductModalBtn = document.getElementById('close-product-modal-btn');
    const productTableBody = document.getElementById('product-table-body');
    const productTableSearch = document.getElementById('product-table-search');
    const productCategoryFilter = document.getElementById('product-category-filter');
    const newCategoryNameInput = document.getElementById('new-category-name');
    const addCategoryBtn = document.getElementById('add-category-btn');
    const categoryTableBody = document.getElementById('category-table-body');

    // Elementos del formulario del modal de producto que se necesitan para openProductModal
    const productIdInput = document.getElementById('product-id');
    const productNameInput = document.getElementById('product-name');
    const productSkuInput = document.getElementById('product-sku');
    const productDescriptionInput = document.getElementById('product-description');
    const productPriceInput = document.getElementById('product-price');
    const productStockInput = document.getElementById('product-stock');
    const productCategorySelect = document.getElementById('product-category');


    // Asegurarse de que los datos globales estén cargados antes de renderizar
    if (!window.products || window.products.length === 0 || !window.categories || window.categories.length === 0) {
        await window.loadDataFromAPI(); // Recargar si los datos no están disponibles
    }

    // 2. Llamar a las funciones de renderizado, pasándoles los elementos DOM
    window.populateCategories(productCategorySelect, productCategoryFilter);
    window.renderProductTable(productTableBody);
    window.renderCategoryTable(categoryTableBody);

    // 3. Adjuntar todos los Event Listeners AQUÍ, usando las referencias locales
    // (Estos listeners deben ser adjuntados CADA VEZ que se carga la página de productos)

    if (closeProductModalBtn) {
        closeProductModalBtn.addEventListener('click', () => window.closeProductModal(productModal));
    }
    if (addProductBtn) {
        addProductBtn.addEventListener('click', () => window.openProductModal(
            productModal, productForm, modalTitle,
            productIdInput, productNameInput, productSkuInput, productDescriptionInput,
            productPriceInput, productStockInput, productCategorySelect
        ));
    }

    if (productForm) {
        productForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            // Los valores de los inputs se obtienen justo antes del submit
            const productId = productIdInput.value;
            const productData = {
                name: productNameInput.value.trim(),
                sku: productSkuInput.value.trim(),
                description: productDescriptionInput.value.trim(),
                price: parseFloat(productPriceInput.value),
                stock: parseInt(productStockInput.value),
                category_id: parseInt(productCategorySelect.value)
            };

            if (productId) {
                productData.id = productId;
                await window.editProduct(productData);
            } else {
                await window.addProduct(productData);
            }
        });
    }

    if (productTableSearch) {
        productTableSearch.addEventListener('keyup', () => {
            const searchText = productTableSearch.value.toLowerCase();
            const categoryFilter = productCategoryFilter.value; // Obtener el valor del filtro
            const filteredProducts = window.products.filter(product => {
                const matchesSearch = product.name.toLowerCase().includes(searchText) ||
                                    product.sku.toLowerCase().includes(searchText) ||
                                    (product.id && product.id.toString().includes(searchText));
                const matchesCategory = categoryFilter === 'all' || product.category_id == categoryFilter;
                return matchesSearch && matchesCategory;
            });
            window.renderProductTable(productTableBody, filteredProducts); // Pasar productTableBody
        });
    }
    if (productCategoryFilter) {
        productCategoryFilter.addEventListener('change', () => {
            const searchText = productTableSearch.value.toLowerCase(); // Obtener el texto de búsqueda
            const categoryFilter = productCategoryFilter.value;
            const filteredProducts = window.products.filter(product => {
                const matchesSearch = product.name.toLowerCase().includes(searchText) ||
                                    product.sku.toLowerCase().includes(searchText) ||
                                    (product.id && product.id.toString().includes(searchText));
                const matchesCategory = categoryFilter === 'all' || product.category_id == categoryFilter;
                return matchesSearch && matchesCategory;
            });
            window.renderProductTable(productTableBody, filteredProducts); // Pasar productTableBody
        });
    }

    if (addCategoryBtn) {
        addCategoryBtn.addEventListener('click', () => {
            const categoryName = newCategoryNameInput.value.trim();
            if (categoryName) {
                window.addCategory(categoryName);
            } else {
                window.showToast('El nombre de la categoría no puede estar vacío.', true);
            }
        });
    }

    // NOTA: Los listeners para los botones .edit-product-btn, .delete-product-btn,
    // .edit-category-btn, .delete-category-btn se adjuntan dentro de
    // renderProductTable y renderCategoryTable, lo cual es correcto
    // porque esos botones se recrean con cada renderizado de la tabla.
};