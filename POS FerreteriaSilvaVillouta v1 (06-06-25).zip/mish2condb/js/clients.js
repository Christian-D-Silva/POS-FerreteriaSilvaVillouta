// js/clients.js

// Función de inicialización para el módulo de Clientes
window.initClientes = async () => {
    console.log('--- Iniciando initClientes ---');

    // Usamos requestAnimationFrame para asegurar que el DOM esté completamente renderizado
    // antes de intentar obtener los elementos.
    requestAnimationFrame(async () => {
        // 1. Obtener todas las referencias a los elementos DOM localmente dentro de initClientes
        let clientsTableBody = document.getElementById('clients-table-body');
        let clientSearchInput = document.getElementById('client-search-input');
        let noClientsMessage = document.getElementById('no-clients-message');
        let addClientBtn = document.getElementById('add-client-btn');
        let clientModal = document.getElementById('client-modal');
        let clientModalTitle = document.getElementById('client-modal-title');
        let clientForm = document.getElementById('client-form');
        let saveClientBtn = document.getElementById('save-client-btn');
        let cancelClientBtn = document.getElementById('cancel-client-btn');

        // Esta variable es auxiliar para el estado de edición, puede ser local a initClientes
        let currentEditingClientId = null;

        // Validar que los elementos esenciales existan
        if (!clientsTableBody || !clientSearchInput || !addClientBtn || !clientModal || !clientForm) {
            console.error('Error: Algunos elementos principales del DOM de clientes no se encontraron. Revisa clients.html');
            return;
        }

        // --- FUNCIONES AUXILIARES INTERNAS DEL MÓDULO DE CLIENTES ---
        // Estas funciones se definen aquí para que puedan acceder a las variables DOM locales.

        async function loadClients() {
            try {
                // Asegurarse de que los datos globales (clients) estén cargados
                if (!window.clients || window.clients.length === 0) {
                    await window.loadDataFromAPI(); // Carga todos los datos, incluyendo clients
                }
                window.renderClientsTable();
            } catch (error) {
                console.error('Error al cargar clientes:', error);
                window.showToast('Error al cargar la lista de clientes.', true);
            }
        }

        function renderClientsTable() {
            clientsTableBody.innerHTML = ''; // Limpiar tabla antes de renderizar
            const query = clientSearchInput.value.toLowerCase();
            const filteredClients = window.clients.filter(client =>
                client.rut.toLowerCase().includes(query) ||
                client.razon_social.toLowerCase().includes(query) ||
                (client.giro && client.giro.toLowerCase().includes(query)) ||
                (client.telefono && client.telefono.includes(query)) ||
                (client.email && client.email.toLowerCase().includes(query))
            );

            if (filteredClients.length === 0) {
                noClientsMessage.classList.remove('hidden');
                clientsTableBody.innerHTML = '';
                return;
            } else {
                noClientsMessage.classList.add('hidden');
            }

            filteredClients.forEach(client => {
                const row = clientsTableBody.insertRow();
                row.className = 'hover:bg-gray-50';
                row.innerHTML = `
                    <td class="py-3 px-6 text-left whitespace-nowrap">${client.rut}</td>
                    <td class="py-3 px-6 text-left">${client.razon_social}</td>
                    <td class="py-3 px-6 text-left">${client.giro || 'N/A'}</td>
                    <td class="py-3 px-6 text-left">${client.direccion || 'N/A'}</td>
                    <td class="py-3 px-6 text-left">${client.comuna || 'N/A'}</td>
                    <td class="py-3 px-6 text-left">${client.ciudad || 'N/A'}</td>
                    <td class="py-3 px-6 text-left">${client.telefono || 'N/A'}</td>
                    <td class="py-3 px-6 text-left">${client.email || 'N/A'}</td>
                    <td class="py-3 px-6 text-center">
                        <div class="flex item-center justify-center space-x-2">
                            <button class="text-blue-500 hover:text-blue-700" title="Editar" onclick="window.editClient(${client.id})">
                                <span data-lucide="edit-3" class="lucide-icon w-5 h-5"></span>
                            </button>
                            <button class="text-red-500 hover:text-red-700" title="Eliminar" onclick="window.deleteClient(${client.id})">
                                <span data-lucide="trash-2" class="lucide-icon w-5 h-5"></span>
                            </button>
                        </div>
                    </td>
                `;
            });
        }

        function openClientModal(client = null) {
            clientForm.reset();
            currentEditingClientId = null;
            clientModalTitle.textContent = 'Añadir Nuevo Cliente';
            document.getElementById('client-rut').readOnly = false; // RUT editable por defecto

            if (client) {
                currentEditingClientId = client.id;
                clientModalTitle.textContent = 'Editar Cliente';
                document.getElementById('client-rut').value = client.rut;
                document.getElementById('client-rut').readOnly = true; // RUT no editable al editar
                document.getElementById('client-razon-social').value = client.razon_social;
                document.getElementById('client-giro').value = client.giro || '';
                document.getElementById('client-direccion').value = client.direccion || '';
                document.getElementById('client-comuna').value = client.comuna || '';
                document.getElementById('client-ciudad').value = client.ciudad || '';
                document.getElementById('client-telefono').value = client.telefono || '';
                document.getElementById('client-email').value = client.email || '';
            }
            clientModal.classList.remove('hidden');
        }

        async function handleClientFormSubmit(event) {
            event.preventDefault();
            const formData = new FormData(clientForm);
            const clientData = Object.fromEntries(formData.entries());

            let url = 'api/clients.php';
            let method = 'POST';

            if (currentEditingClientId) {
                url += `?action=update&id=${currentEditingClientId}`;
                method = 'PUT'; // Usar PUT para actualizaciones
            } else {
                url += '?action=add';
            }

            try {
                const response = await fetch(url, {
                    method: method,
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(clientData)
                });
                const result = await response.json();

                if (response.ok) {
                    window.showToast(result.message);
                    clientModal.classList.add('hidden');
                    await window.loadDataFromAPI(); // Recargar datos globales
                    renderClientsTable(); // Re-renderizar la tabla con los nuevos datos
                } else {
                    throw new Error(result.error || 'Error al guardar el cliente.');
                }
            } catch (error) {
                console.error('Error al guardar cliente:', error);
                window.showToast(`Error: ${error.message}`, true);
            }
        }

        async function deleteClient(clientId) {
            if (!confirm('¿Estás seguro de que quieres eliminar este cliente? Las ventas asociadas no se eliminarán, pero su cliente se marcará como NULO.')) {
                return;
            }

            try {
                const response = await fetch(`api/clients.php?action=delete&id=${clientId}`, {
                    method: 'DELETE'
                });
                const result = await response.json();

                if (response.ok) {
                    window.showToast(result.message);
                    await window.loadDataFromAPI(); // Recargar datos
                    renderClientsTable(); // Re-renderizar
                } else {
                    throw new Error(result.error || 'Error al eliminar el cliente.');
                }
            } catch (error) {
                console.error('Error al eliminar cliente:', error);
                window.showToast(`Error: ${error.message}`, true);
            }
        }

        // --- ASIGNACIONES DE FUNCIONES AL OBJETO WINDOW ---
        // Se hace para que puedan ser llamadas desde el HTML (onclick) o desde main.js

        window.renderClientsTable = renderClientsTable;
        window.openClientModal = openClientModal;
        window.handleClientFormSubmit = handleClientFormSubmit;
        window.editClient = (id) => {
            const client = window.clients.find(c => c.id == id);
            if (client) {
                window.openClientModal(client);
            } else {
                console.error('Cliente no encontrado para editar:', id);
            }
        };
        window.deleteClient = deleteClient;
        window.filterClients = renderClientsTable; // filterClients ahora simplemente llama a renderClientsTable para aplicar el filtro

        // --- CONFIGURACIÓN DE EVENT LISTENERS ---
        addClientBtn.addEventListener('click', () => window.openClientModal());
        clientForm.addEventListener('submit', (e) => window.handleClientFormSubmit(e));
        cancelClientBtn.addEventListener('click', () => clientModal.classList.add('hidden'));

        // Event listener para búsqueda/filtrado de clientes
        clientSearchInput.addEventListener('input', () => window.filterClients());

        // Cargar y renderizar clientes al iniciar el módulo
        await loadClients();

        // Actualizar iconos Lucide para esta sección
        if (window.lucide) {
            window.lucide.createIcons();
        }
    });
};