// js/ventas.js

// Variables globales para el estado de ventas que se mantienen fuera de initVentas
// porque otras funciones globales (como searchProducts, addProductToCart, renderCart, etc.)
// también las necesitan y se definen en este archivo.
window.cart = [];
let discountAmount = 0; // Ahora es un monto fijo, no un porcentaje
let selectedClient = null; // Para almacenar el cliente seleccionado en caso de factura


// --- FUNCIONES ESPECÍFICAS DE VENTAS ---

// Función para buscar productos (ahora es global para ser accesible)
window.searchProducts = async (query) => {
    // Estas variables DOM no pueden ser accedidas directamente si se declaran en initVentas
    // La mejor práctica sería pasarlas como argumentos o re-obtenerlas si es estrictamente necesario,
    // pero si initVentas ya las asignó, y estas funciones también las necesitan, se podrían
    // pasar o si son pocas, re-obtener (menos eficiente).
    // Para simplificar, asumimos que si estas funciones son llamadas, los elementos ya existen
    // y se pueden obtener de nuevo si su referencia no está globalmente.
    // Otra opción es que initVentas devuelva un objeto con todas las referencias DOM.
    // Por ahora, las funciones globales que interactúen con el DOM tendrán que obtener sus propias referencias si no están en initVentas.
    const productSearchResults = document.getElementById('product-search-results');

    if (query.length < 2) { // Buscar solo si hay al menos 2 caracteres
        if (productSearchResults) {
            productSearchResults.classList.add('hidden');
        }
        return;
    }
    try {
        if (!window.products || window.products.length === 0) {
            await window.loadDataFromAPI(); // Asegura que los productos estén cargados globalmente
        }

        const filtered = window.products.filter(p =>
            p.name.toLowerCase().includes(query.toLowerCase()) ||
            p.sku.toLowerCase().includes(query.toLowerCase())
        );

        if (productSearchResults) {
            productSearchResults.innerHTML = '';
            if (filtered.length > 0) {
                filtered.forEach(p => {
                    const div = document.createElement('div');
                    div.className = 'p-3 hover:bg-gray-100 cursor-pointer border-b border-gray-200 last:border-b-0';
                    div.innerHTML = `<span class="font-semibold">${p.name}</span> (SKU: ${p.sku}) - ${window.formatCurrency(p.price)} <span class="text-gray-500">(Stock: ${p.stock})</span>`;
                    div.onclick = () => window.addProductToCart(p);
                    productSearchResults.appendChild(div);
                });
                productSearchResults.classList.remove('hidden');
            } else {
                productSearchResults.innerHTML = '<div class="p-3 text-gray-500">No se encontraron productos.</div>';
                productSearchResults.classList.remove('hidden');
            }
        }
    } catch (error) {
        console.error('Error al buscar productos:', error);
        window.showToast('Error al buscar productos.', true);
    }
};

// Función para buscar clientes (ahora es global para ser accesible)
window.searchClients = async (query) => {
    const clientSearchResults = document.getElementById('client-search-results');

    if (query.length < 2) { // Buscar solo si hay al menos 2 caracteres
        if (clientSearchResults) {
            clientSearchResults.classList.add('hidden');
        }
        return;
    }
    try {
        if (!window.clients || window.clients.length === 0) {
            await window.loadDataFromAPI(); // Asegura que los clientes estén cargados globalmente
        }

        const filtered = window.clients.filter(c =>
            c.rut.toLowerCase().includes(query.toLowerCase()) ||
            c.razon_social.toLowerCase().includes(query.toLowerCase())
        );

        if (clientSearchResults) {
            clientSearchResults.innerHTML = '';
            if (filtered.length > 0) {
                filtered.forEach(c => {
                    const div = document.createElement('div');
                    div.className = 'p-3 hover:bg-gray-100 cursor-pointer border-b border-gray-200 last:border-b-0';
                    div.innerHTML = `<span class="font-semibold">${c.razon_social}</span> (RUT: ${c.rut})`;
                    div.onclick = () => window.selectClientForSale(c);
                    clientSearchResults.appendChild(div);
                });
                clientSearchResults.classList.remove('hidden');
            } else {
                clientSearchResults.innerHTML = '<div class="p-3 text-gray-500">No se encontraron clientes.</div>';
                clientSearchResults.classList.remove('hidden');
            }
        }
    } catch (error) {
        console.error('Error al buscar clientes:', error);
        window.showToast('Error al buscar clientes.', true);
    }
};

// Función para seleccionar un cliente para la venta
window.selectClientForSale = (client) => {
    selectedClient = client;
    const selectedClientDisplay = document.getElementById('selected-client-display');
    const clientSearchInput = document.getElementById('client-search');
    const clientSearchResults = document.getElementById('client-search-results');
    const clearClientSelectionBtn = document.getElementById('clear-client-selection-btn');

    if (selectedClientDisplay) selectedClientDisplay.textContent = `${client.razon_social} (RUT: ${client.rut})`;
    if (clientSearchInput) clientSearchInput.value = ''; // Limpiar input de búsqueda
    if (clientSearchResults) clientSearchResults.classList.add('hidden'); // Ocultar resultados
    if (clearClientSelectionBtn) clearClientSelectionBtn.classList.remove('hidden');
};

// Función para agregar producto al carrito
window.addProductToCart = (product) => {
    if (product.stock <= 0) {
        window.showToast(`El producto "${product.name}" no tiene stock disponible.`, true);
        return;
    }

    const existingItem = window.cart.find(item => item.id === product.id);
    if (existingItem) {
        if (existingItem.quantity < product.stock) {
            existingItem.quantity++;
        } else {
            window.showToast(`No hay más stock para "${product.name}".`, true);
        }
    } else {
        window.cart.push({
            id: product.id,
            name: product.name,
            sku: product.sku,
            price: product.price,
            quantity: 1,
            stock: product.stock // Mantener el stock máximo disponible
        });
    }
    window.renderCart();
};

// Función para eliminar producto del carrito
window.removeProductFromCart = (productId) => {
    window.cart = window.cart.filter(item => item.id !== productId);
    window.renderCart();
};

// Función para actualizar cantidad de producto en el carrito
window.updateProductQuantity = (productId, newQuantity) => {
    const item = window.cart.find(item => item.id === productId);
    if (item) {
        if (newQuantity > 0 && newQuantity <= item.stock) {
            item.quantity = newQuantity;
        } else if (newQuantity > item.stock) {
            item.quantity = item.stock; // No exceder el stock
            window.showToast(`Cantidad limitada al stock disponible (${item.stock}).`, true);
        } else {
            // Si la cantidad es 0 o negativa, eliminar
            window.removeProductFromCart(productId);
            return; // No continuar con renderCart aquí, ya se llama en removeProductFromCart
        }
    }
    window.renderCart();
};

// Función para renderizar el carrito
window.renderCart = () => {
    const cartItemsContainer = document.getElementById('cart-items');
    const cartSubtotalSpan = document.getElementById('cart-subtotal');
    const cartDiscountSpan = document.getElementById('cart-discount');
    const cartTaxSpan = document.getElementById('cart-tax');
    const cartTotalSpan = document.getElementById('cart-total');
    const completeSaleBtn = document.getElementById('complete-sale-btn');

    if (!cartItemsContainer || !cartSubtotalSpan || !cartDiscountSpan || !cartTaxSpan || !cartTotalSpan || !completeSaleBtn) {
        console.error("Elementos del DOM del carrito no encontrados. `ventas.html` no cargado correctamente.");
        return;
    }

    cartItemsContainer.innerHTML = '';
    let subtotal = 0;

    if (window.cart.length === 0) {
        cartItemsContainer.innerHTML = '<tr><td colspan="5" class="py-4 text-center text-gray-500">El carrito está vacío.</td></tr>';
        completeSaleBtn.disabled = true;
    } else {
        window.cart.forEach(item => {
            const row = cartItemsContainer.insertRow();
            row.className = 'border-b border-gray-200 hover:bg-gray-50';
            row.innerHTML = `
                <td class="py-3 px-6">${item.name} (${item.sku})</td>
                <td class="py-3 px-6">${window.formatCurrency(item.price)}</td>
                <td class="py-3 px-6">
                    <input type="number" value="${item.quantity}" min="1" max="${item.stock}"
                           onchange="window.updateProductQuantity(${item.id}, parseInt(this.value))"
                           class="w-20 p-1 border rounded text-center">
                </td>
                <td class="py-3 px-6">${window.formatCurrency(item.price * item.quantity)}</td>
                <td class="py-3 px-6 text-right">
                    <button class="text-red-500 hover:text-red-700" onclick="window.removeProductFromCart(${item.id})">
                        <span data-lucide="x" class="lucide-icon w-5 h-5"></span>
                    </button>
                </td>
            `;
            subtotal += item.price * item.quantity;
        });
        completeSaleBtn.disabled = false;
    }

    // Cálculos
    const totalWithoutDiscount = subtotal;
    const currentDiscount = Math.min(discountAmount, totalWithoutDiscount); // El descuento no puede ser mayor que el subtotal
    const subtotalAfterDiscount = totalWithoutDiscount - currentDiscount;
    const taxAmount = subtotalAfterDiscount * 0.19; // Ejemplo 19% de IVA
    const total = subtotalAfterDiscount + taxAmount;

    cartSubtotalSpan.textContent = window.formatCurrency(subtotal);
    cartDiscountSpan.textContent = `-${window.formatCurrency(currentDiscount)}`;
    cartTaxSpan.textContent = window.formatCurrency(taxAmount);
    cartTotalSpan.textContent = window.formatCurrency(total);
};


// Función para aplicar descuento desde el modal
window.applyDiscount = () => {
    const discountAmountInput = document.getElementById('discount-amount');
    const discountModal = document.getElementById('discount-modal');

    const amount = parseFloat(discountAmountInput.value);
    if (isNaN(amount) || amount < 0) {
        window.showToast('Por favor, ingresa un monto de descuento válido.', true);
        return;
    }
    discountAmount = amount;
    window.renderCart(); // Re-renderizar el carrito con el descuento
    discountModal.classList.add('hidden'); // Ocultar el modal
};

// Función para completar la venta
window.completeSale = async () => {
    if (window.cart.length === 0) {
        window.showToast('El carrito está vacío. Agrega productos antes de completar la venta.', true);
        return;
    }

    const saleTypeSelect = document.getElementById('sale-type');
    const documentType = saleTypeSelect ? saleTypeSelect.value : 'Boleta'; // Boleta por defecto si no hay select

    if (documentType === 'Factura' && !selectedClient) {
        window.showToast('Por favor, selecciona un cliente para emitir una factura.', true);
        return;
    }

    const cartSubtotal = window.cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    const currentDiscount = Math.min(discountAmount, cartSubtotal);
    const subtotalAfterDiscount = cartSubtotal - currentDiscount;
    const taxAmount = subtotalAfterDiscount * 0.19;
    const totalAmount = subtotalAfterDiscount + taxAmount;

    const saleData = {
        products: window.cart.map(item => ({
            product_id: item.id,
            quantity: item.quantity,
            price_at_sale: item.price // Precio al momento de la venta
        })),
        total_amount: totalAmount,
        subtotal_amount: cartSubtotal, // Subtotal de items antes del descuento
        discount_amount: currentDiscount,
        tax_amount: taxAmount,
        document_type: documentType,
        client_id: selectedClient ? selectedClient.id : null
    };

    try {
        const response = await fetch('api/sales.php?action=add', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(saleData)
        });
        const result = await response.json();

        if (response.ok) {
            window.showToast(result.message);
            window.cart = []; // Limpiar carrito
            discountAmount = 0; // Resetear descuento
            selectedClient = null; // Resetear cliente
            window.renderCart(); // Re-renderizar carrito (vacío)

            // Limpiar la interfaz de selección de cliente
            const selectedClientDisplay = document.getElementById('selected-client-display');
            const clientSearchInput = document.getElementById('client-search');
            const clearClientSelectionBtn = document.getElementById('clear-client-selection-btn');
            const saleTypeSelect = document.getElementById('sale-type');
            const clientSelectionDiv = document.getElementById('client-selection-div');

            if (selectedClientDisplay) selectedClientDisplay.textContent = '';
            if (clientSearchInput) clientSearchInput.value = '';
            if (clearClientSelectionBtn) clearClientSelectionBtn.classList.add('hidden');
            if (saleTypeSelect) saleTypeSelect.value = 'Boleta'; // Volver a boleta
            if (clientSelectionDiv) clientSelectionDiv.classList.add('hidden'); // Ocultar div de cliente

            await window.loadDataFromAPI(); // Recargar datos (especialmente stock y historial de ventas)
        } else {
            throw new Error(result.error || 'Error al completar la venta.');
        }
    } catch (error) {
        console.error('Error al completar la venta:', error);
        window.showToast(`Error al completar la venta: ${error.message}`, true);
    }
};


// Función de inicialización principal para el módulo de Ventas
window.initVentas = async () => {
    console.log('Inicializando Módulo de Ventas...');

    // Usamos requestAnimationFrame para asegurar que el DOM esté completamente renderizado
    requestAnimationFrame(async () => {
        // 1. Obtener todas las referencias a los elementos DOM localmente dentro de initVentas
        let productSearchInput = document.getElementById('product-search');
        let productSearchResults = document.getElementById('product-search-results');
        let cartItemsContainer = document.getElementById('cart-items');
        let cartSubtotalSpan = document.getElementById('cart-subtotal');
        let cartDiscountSpan = document.getElementById('cart-discount');
        let cartTaxSpan = document.getElementById('cart-tax');
        let cartTotalSpan = document.getElementById('cart-total');
        let applyDiscountBtn = document.getElementById('apply-discount-btn');
        let completeSaleBtn = document.getElementById('complete-sale-btn');
        let discountModal = document.getElementById('discount-modal');
        let closeDiscountModalBtn = document.getElementById('close-discount-modal-btn');
        let discountAmountInput = document.getElementById('discount-amount');
        let confirmDiscountBtn = document.getElementById('confirm-discount-btn');
        let saleTypeSelect = document.getElementById('sale-type');
        let clientSelectionDiv = document.getElementById('client-selection-div');
        let clientSearchInput = document.getElementById('client-search'); // ID en ventas.html
        let clientSearchResults = document.getElementById('client-search-results');
        let selectedClientDisplay = document.getElementById('selected-client-display');
        let clearClientSelectionBtn = document.getElementById('clear-client-selection-btn');

        // Validación básica de elementos
        if (!productSearchInput || !cartItemsContainer || !cartTotalSpan || !completeSaleBtn || !saleTypeSelect || !clientSelectionDiv) {
            console.error("Error: Algunos elementos principales del DOM de ventas no se encontraron. Asegúrate de que ventas.html esté cargado correctamente.");
            return;
        }

        // --- CONFIGURACIÓN DE EVENT LISTENERS ---
        if (productSearchInput) {
            productSearchInput.addEventListener('input', (e) => window.searchProducts(e.target.value));
            productSearchInput.addEventListener('focus', (e) => {
                if (e.target.value.length >= 2) window.searchProducts(e.target.value);
            });
            productSearchInput.addEventListener('blur', () => {
                setTimeout(() => {
                    if (productSearchResults) productSearchResults.classList.add('hidden');
                }, 200);
            });
        }

        if (applyDiscountBtn) {
            applyDiscountBtn.addEventListener('click', () => {
                if (discountModal) discountModal.classList.remove('hidden');
            });
        }

        if (closeDiscountModalBtn) {
            closeDiscountModalBtn.addEventListener('click', () => {
                if (discountModal) discountModal.classList.add('hidden');
            });
        }

        if (confirmDiscountBtn) {
            confirmDiscountBtn.addEventListener('click', () => window.applyDiscount());
        }

        if (completeSaleBtn) {
            completeSaleBtn.addEventListener('click', () => window.completeSale());
        }

        if (saleTypeSelect) {
            saleTypeSelect.addEventListener('change', () => {
                if (saleTypeSelect.value === 'Factura' && clientSelectionDiv) {
                    clientSelectionDiv.classList.remove('hidden');
                } else if (clientSelectionDiv) {
                    clientSelectionDiv.classList.add('hidden');
                    // Al cambiar a Boleta, limpiar selección de cliente
                    selectedClient = null;
                    if (selectedClientDisplay) selectedClientDisplay.textContent = '';
                    if (clearClientSelectionBtn) clearClientSelectionBtn.classList.add('hidden');
                    if (clientSearchInput) clientSearchInput.value = '';
                }
            });
            // Ocultar al inicio si el tipo de venta es Boleta por defecto
            if (saleTypeSelect.value === 'Boleta' && clientSelectionDiv) {
                clientSelectionDiv.classList.add('hidden');
            }
        }

        // Event listener para búsqueda de clientes
        if (clientSearchInput) {
            clientSearchInput.addEventListener('input', (e) => window.searchClients(e.target.value));
            clientSearchInput.addEventListener('focus', (e) => {
                if (e.target.value.length >= 2) window.searchClients(e.target.value); // Búsqueda con al menos 2 caracteres
            });
            clientSearchInput.addEventListener('blur', () => {
                setTimeout(() => {
                    if (clientSearchResults) clientSearchResults.classList.add('hidden');
                }, 200);
            });
        }

        // Event listener para limpiar selección de cliente
        if (clearClientSelectionBtn) {
            clearClientSelectionBtn.addEventListener('click', () => {
                selectedClient = null;
                if (selectedClientDisplay) selectedClientDisplay.textContent = '';
                if (clearClientSelectionBtn) clearClientSelectionBtn.classList.add('hidden');
                if (clientSearchInput) clientSearchInput.value = '';
                if (clientSearchResults) clientSearchResults.classList.add('hidden'); // Ocultar resultados al limpiar
            });
        }

        // Asegurarse de que el modal de descuento esté oculto al iniciar
        if (discountModal) {
            discountModal.classList.add('hidden');
        }

        // Renderizar carrito inicial (vacío)
        window.renderCart();

        // Actualizar iconos Lucide para esta sección
        if (window.lucide) {
            window.lucide.createIcons();
        }
    });
};