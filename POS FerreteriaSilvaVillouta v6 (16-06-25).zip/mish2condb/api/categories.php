<?php
// api/categories.php
require_once __DIR__ . '/../db_connection.php';
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    http_response_code(401); // Unauthorized
    echo json_encode(['error' => 'Acceso no autorizado.']);
    exit();
}

$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? '';

switch ($method) {
    case 'GET':
        if ($action === 'list') {
            echo json_encode([]); // Placeholder
        } else {
            http_response_code(400);
            echo json_encode(['error' => 'Acción GET no válida.']);
        }
        break;
    case 'POST':
        http_response_code(200);
        echo json_encode(['message' => 'Categoría creada (placeholder).']);
        break;
    case 'PUT':
        http_response_code(200);
        echo json_encode(['message' => 'Categoría actualizada (placeholder).']);
        break;
    case 'DELETE':
        http_response_code(200);
        echo json_encode(['message' => 'Categoría eliminada (placeholder).']);
        break;
    default:
        http_response_code(405);
        echo json_encode(['error' => 'Método no permitido.']);
        break;
}
?>