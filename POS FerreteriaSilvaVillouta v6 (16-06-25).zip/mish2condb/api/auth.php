<?php
// api/auth.php

// Asegurarse de que la sesión se inicie al principio de todo el script.
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Incluir el archivo de conexión a la base de datos
require_once __DIR__ . '/../db_connection.php'; 

header('Content-Type: application/json');

// --- Configuración temporal para depuración (¡QUITAR EN PRODUCCIÓN!) ---
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
// ---------------------------------------------------------------------

// --- NUEVA LÍNEA DE DEPURACIÓN INICIAL ---
error_log("DEBUG: auth.php ha sido accedido. Método: " . $_SERVER['REQUEST_METHOD'] . ", Acción: " . ($_GET['action'] ?? 'N/A'));
// ------------------------------------------

$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? '';

try {
    $pdo = get_db_connection(); // Obtener la conexión PDO una sola vez al inicio del try-catch

    // Si la conexión falló (get_db_connection devolvió null y ya envió un error JSON),
    // simplemente salimos para evitar intentar operaciones de DB con un PDO nulo.
    if ($pdo === null) {
        exit();
    }

    switch ($method) {
        case 'POST':
            $input = json_decode(file_get_contents('php://input'), true);

            if ($action === 'login') {
                $username = $input['username'] ?? '';
                $password = $input['password'] ?? '';

                if (empty($username) || empty($password)) {
                    http_response_code(400);
                    echo json_encode(['error' => 'Usuario y contraseña son requeridos.']);
                    exit();
                }

                $stmt = $pdo->prepare("
                    SELECT u.id, u.username, u.password_hash, u.full_name, u.role_id, ur.name as role_name
                    FROM users u
                    JOIN users_roles ur ON u.role_id = ur.id
                    WHERE u.username = ?
                ");
                $stmt->execute([$username]);
                $user = $stmt->fetch(PDO::FETCH_ASSOC);

                // --- INICIO: DEBUG DE CONTRASEÑA ---
                error_log("DEBUG Login: Intentando iniciar sesión con usuario: " . $username);
                if ($user) {
                    error_log("DEBUG Login: Usuario encontrado. Hash de la DB: " . $user['password_hash']);
                    error_log("DEBUG Login: Contraseña proporcionada (PLANA): " . $password); // ¡CUIDADO! NO MANTENER ESTO EN PRODUCCIÓN
                    if (password_verify($password, $user['password_hash'])) {
                        error_log("DEBUG Login: password_verify RESULTADO: TRUE (Contraseña coincide)");
                    } else {
                        error_log("DEBUG Login: password_verify RESULTADO: FALSE (Contraseña NO coincide)");
                    }
                } else {
                    error_log("DEBUG Login: Usuario NO encontrado.");
                }
                // --- FIN: DEBUG DE CONTRASEÑA ---

                if ($user && password_verify($password, $user['password_hash'])) {
                    // Autenticación exitosa
                    $_SESSION['user_id'] = $user['id'];
                    $_SESSION['username'] = $user['username'];
                    $_SESSION['full_name'] = $user['full_name'];
                    $_SESSION['user_role_id'] = $user['role_id']; // Almacenar el role_id
                    $_SESSION['user_role_name'] = $user['role_name']; // Almacenar el role_name

                    http_response_code(200);
                    echo json_encode([
                        'message' => 'Inicio de sesión exitoso.',
                        'user' => [
                            'id' => $user['id'],
                            'username' => $user['username'],
                            'full_name' => $user['full_name'],
                            'role_id' => $user['role_id'],
                            'role_name' => $user['role_name']
                        ]
                    ]);
                } else {
                    http_response_code(401); // Unauthorized
                    echo json_encode(['error' => 'Usuario o contraseña incorrectos.']);
                }
                exit();

            } elseif ($action === 'logout') {
                // Destruir todas las variables de sesión
                $_SESSION = [];
                // Invalidar la cookie de sesión
                if (ini_get("session.use_cookies")) {
                    $params = session_get_cookie_params();
                    setcookie(session_name(), '', time() - 42000,
                        $params["path"], $params["domain"],
                        $params["secure"], $params["httponly"]
                    );
                }
                // Finalmente, destruir la sesión
                session_destroy();
                http_response_code(200);
                echo json_encode(['message' => 'Sesión cerrada exitosamente.']);
                exit();
            } else {
                error_log("DEBUG: Acción POST no válida: '" . $action . "'");
                http_response_code(400);
                echo json_encode(['error' => 'Acción POST no válida.']);
                exit();
            }
            break;

        case 'GET':
            if ($action === 'status') {
                // Verificar el estado de la sesión
                // Asegurarse de que las variables de sesión existan antes de acceder a ellas
                if (isset($_SESSION['user_id'])) {
                    $response_data = [
                        'logged_in' => true,
                        'user_id' => $_SESSION['user_id'],
                        'username' => $_SESSION['username'] ?? null, // Usar operador de coalescencia nula
                        'full_name' => $_SESSION['full_name'] ?? null,
                        'role_id' => $_SESSION['user_role_id'] ?? null,
                        'role_name' => $_SESSION['user_role_name'] ?? null
                    ];
                    http_response_code(200);
                    echo json_encode($response_data);
                } else {
                    error_log("DEBUG: No hay sesión activa.");
                    http_response_code(401);
                    echo json_encode(['logged_in' => false]);
                }
                exit();
            } else {
                error_log("DEBUG: Acción GET no válida: '" . $action . "'");
                http_response_code(400);
                echo json_encode(['error' => 'Acción GET no válida.']);
                exit();
            }
            break;

        default:
            error_log("DEBUG: Método HTTP no permitido: '" . $method . "'");
            http_response_code(405); // Method Not Allowed
            echo json_encode(['error' => 'Método no permitido.']);
            exit();
    }
} catch (PDOException $e) {
    error_log("ERROR CRÍTICO (PDO) en auth.php: " . $e->getMessage());
    http_response_code(500); // Internal Server Error
    echo json_encode(['error' => 'Error de base de datos. Por favor, inténtelo de nuevo más tarde.']);
    exit();
} catch (Exception $e) {
    error_log("ERROR CRÍTICO (GENERAL) en auth.php: " . $e->getMessage());
    http_response_code(500); // Internal Server Error
    echo json_encode(['error' => 'Ocurrió un error inesperado en el servidor.']);
    exit();
}
