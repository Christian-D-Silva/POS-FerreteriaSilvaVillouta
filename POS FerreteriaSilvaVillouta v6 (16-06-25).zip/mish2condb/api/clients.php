<?php
// api/clients.php
require_once __DIR__ . '/../db_connection.php';
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    http_response_code(401); // Unauthorized
    echo json_encode(['error' => 'Acceso no autorizado.']);
    exit();
}

$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? '';

// Eliminamos: $conn = get_db_connection(); // Esto era problemático fuera de un try-catch

switch ($method) {
    case 'GET':
        try {
            $pdo = get_db_connection(); // Obtener la conexión PDO dentro del try-catch
            if ($action === 'list') {
                $search = $_GET['search'] ?? '';
                $sql = "SELECT id, rut, razon_social, giro, direccion, comuna, ciudad, telefono, email, fecha_creacion FROM clientes";
                $params = [];

                if (!empty($search)) {
                    $sql .= " WHERE rut LIKE ? OR razon_social LIKE ? OR giro LIKE ?";
                    $search_param = '%' . $search . '%';
                    $params = [$search_param, $search_param, $search_param];
                }
                $sql .= " ORDER BY razon_social ASC";

                $stmt = $pdo->prepare($sql);
                $stmt->execute($params);
                $clients = $stmt->fetchAll(PDO::FETCH_ASSOC);
                echo json_encode($clients);
            } elseif ($action === 'search') {
                $query = $_GET['query'] ?? '';
                if (empty($query) || strlen($query) < 2) { // Búsqueda con al menos 2 caracteres
                    echo json_encode([]); // Devolver array vacío si la query es muy corta
                    exit();
                }
                $stmt = $pdo->prepare("SELECT id, rut, razon_social FROM clientes WHERE rut LIKE ? OR razon_social LIKE ? LIMIT 10");
                $search_param = '%' . $query . '%';
                $stmt->execute([$search_param, $search_param]);
                $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
                echo json_encode($results);
            } else {
                http_response_code(400);
                echo json_encode(['error' => 'Acción GET no válida.']);
            }
        } catch (PDOException $e) {
            http_response_code(500);
            echo json_encode(['error' => 'Error de base de datos en GET (clientes): ' . $e->getMessage()]);
        }
        break;

    case 'POST': // Añadir nuevo cliente
        try {
            $pdo = get_db_connection(); // Obtener la conexión PDO dentro del try-catch
            $data = json_decode(file_get_contents('php://input'), true);

            if (!isset($data['rut'], $data['razon_social'], $data['giro'])) {
                http_response_code(400);
                echo json_encode(['error' => 'Datos de cliente incompletos.']);
                exit();
            }

            // Verificar si el RUT ya existe
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM clientes WHERE rut = ?");
            $stmt->execute([$data['rut']]);
            if ($stmt->fetchColumn() > 0) {
                http_response_code(409); // Conflict
                echo json_encode(['error' => 'El RUT ya está registrado.']);
                exit();
            }

            $stmt = $pdo->prepare("INSERT INTO clientes (rut, razon_social, giro, direccion, comuna, ciudad, telefono, email) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->execute([
                $data['rut'],
                $data['razon_social'],
                $data['giro'],
                $data['direccion'] ?? null,
                $data['comuna'] ?? null,
                $data['ciudad'] ?? null,
                $data['telefono'] ?? null,
                $data['email'] ?? null
            ]);

            if ($stmt->rowCount() > 0) { // Usar rowCount() para PDO
                http_response_code(201); // Created
                echo json_encode(['message' => 'Cliente añadido exitosamente!', 'id' => $pdo->lastInsertId()]);
            } else {
                http_response_code(500);
                echo json_encode(['error' => 'Error al añadir el cliente.']);
            }
        } catch (PDOException $e) {
            http_response_code(500);
            echo json_encode(['error' => 'Error de base de datos al añadir cliente: ' . $e->getMessage()]);
        }
        break;

    case 'PUT': // Actualizar cliente
        try {
            $pdo = get_db_connection(); // Obtener la conexión PDO dentro del try-catch
            $data = json_decode(file_get_contents('php://input'), true);
            $id = $_GET['id'] ?? null;

            if (!$id || !isset($data['rut'], $data['razon_social'], $data['giro'])) {
                http_response_code(400);
                echo json_encode(['error' => 'Datos de cliente incompletos o ID no proporcionado.']);
                exit();
            }

            // Verificar si el RUT ya existe y no pertenece al cliente actual
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM clientes WHERE rut = ? AND id != ?");
            $stmt->execute([$data['rut'], $id]);
            if ($stmt->fetchColumn() > 0) {
                http_response_code(409); // Conflict
                echo json_encode(['error' => 'El RUT ya está registrado para otro cliente.']);
                exit();
            }

            $stmt = $pdo->prepare("UPDATE clientes SET rut = ?, razon_social = ?, giro = ?, direccion = ?, comuna = ?, ciudad = ?, telefono = ?, email = ? WHERE id = ?");
            $stmt->execute([
                $data['rut'],
                $data['razon_social'],
                $data['giro'],
                $data['direccion'] ?? null,
                $data['comuna'] ?? null,
                $data['ciudad'] ?? null,
                $data['telefono'] ?? null,
                $data['email'] ?? null,
                $id
            ]);

            if ($stmt->rowCount() > 0) { // Usar rowCount() para PDO
                http_response_code(200);
                echo json_encode(['message' => 'Cliente actualizado exitosamente!']);
            } else {
                http_response_code(404);
                echo json_encode(['error' => 'Cliente no encontrado o no se realizaron cambios.']);
            }
        } catch (PDOException $e) {
            http_response_code(500);
            echo json_encode(['error' => 'Error de base de datos al actualizar cliente: ' . $e->getMessage()]);
        }
        break;

    case 'DELETE': // Eliminar cliente
        try {
            $pdo = get_db_connection(); // Obtener la conexión PDO dentro del try-catch
            $id = $_GET['id'] ?? null;
            if (!$id) {
                http_response_code(400);
                echo json_encode(['error' => 'ID de cliente no proporcionado.']);
                exit();
            }

            // La FK en 'sales' con ON DELETE SET NULL manejará la referencia.
            $stmt = $pdo->prepare("DELETE FROM clientes WHERE id = ?");
            $stmt->execute([$id]);

            if ($stmt->rowCount() > 0) { // Usar rowCount() para PDO
                http_response_code(200);
                echo json_encode(['message' => 'Cliente eliminado exitosamente!']);
            } else {
                http_response_code(404); // Not Found
                echo json_encode(['error' => 'Cliente no encontrado.']);
            }
        } catch (PDOException $e) {
            http_response_code(500);
            echo json_encode(['error' => 'Error de base de datos al eliminar cliente: ' . $e->getMessage()]);
        }
        break;

    default:
        http_response_code(405); // Method Not Allowed
        echo json_encode(['error' => 'Método no permitido.']);
        break;
}
?>