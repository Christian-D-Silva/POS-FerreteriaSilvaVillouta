<?php
// api/roles.php

require_once __DIR__ . '/../db_connection.php'; // ASEGÚRATE DE QUE ESTA RUTA ES CORRECTA

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

header('Content-Type: application/json');

$pdo = get_db_connection(); // Obtener la conexión PDO

// Puedes añadir una validación de rol aquí si solo ciertos usuarios pueden ver los roles
// Por ejemplo, solo un administrador (rol_id = 1)
/*
if (!isset($_SESSION['user_id']) || ($_SESSION['role_id'] !== '1' && $_SESSION['role_id'] !== 1)) {
    http_response_code(403); // Forbidden
    echo json_encode(['error' => 'Acceso no autorizado para ver roles.']);
    exit();
}
*/

$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? '';

switch ($method) {
    case 'GET':
        if ($action === 'list') {
            try {
                $stmt = $pdo->query("SELECT id, name FROM users_roles ORDER BY name ASC");
                $stmt->execute();
                $roles = $stmt->fetchAll(PDO::FETCH_ASSOC);

                echo json_encode($roles);

            } catch (PDOException $e) {
                http_response_code(500);
                echo json_encode(['error' => 'Error de base de datos al listar roles: ' . $e->getMessage()]);
                error_log('Error PDO en roles.php: ' . $e->getMessage()); // Para logs del servidor
            }
        } else {
            http_response_code(400); // Bad Request
            echo json_encode(['error' => 'Acción GET no válida para roles.']);
        }
        break;
    // Si necesitas añadir, editar o eliminar roles en el futuro, añadirías los casos 'POST', 'PUT', 'DELETE' aquí.
    default:
        http_response_code(405); // Method Not Allowed
        echo json_encode(['error' => 'Método no permitido para roles.']);
        break;
}
?>