<?php
// api/proveedores.php

require_once __DIR__ . '/../db_connection.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    http_response_code(401); // Unauthorized
    echo json_encode(['error' => 'Acceso no autorizado. Debe iniciar sesión.']);
    exit();
}

$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? '';

try {
    $pdo = get_db_connection();

    switch ($method) {
        case 'GET':
            if ($action === 'list') {
                // Listar todos los proveedores
                $stmt = $pdo->query("SELECT id, rut, razon_social, direccion, telefono, email, contacto_nombre, contacto_telefono, creado_en FROM proveedores ORDER BY razon_social ASC");
                echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
            } elseif ($action === 'details' && isset($_GET['id'])) {
                // Obtener detalles de un proveedor específico
                $stmt = $pdo->prepare("SELECT id, rut, razon_social, direccion, telefono, email, contacto_nombre, contacto_telefono, creado_en FROM proveedores WHERE id = ?");
                $stmt->execute([$_GET['id']]);
                $proveedor = $stmt->fetch(PDO::FETCH_ASSOC);
                if ($proveedor) {
                    echo json_encode($proveedor);
                } else {
                    http_response_code(404);
                    echo json_encode(['error' => 'Proveedor no encontrado.']);
                }
            } else {
                http_response_code(400); // Bad Request
                echo json_encode(['error' => 'Acción GET no válida para proveedores.']);
            }
            break;

        case 'POST':
            $input = json_decode(file_get_contents('php://input'), true);

            if ($action === 'add') {
                // Añadir nuevo proveedor
                $rut = $input['rut'] ?? null;
                $razon_social = $input['razon_social'] ?? null;
                $direccion = $input['direccion'] ?? null;
                $telefono = $input['telefono'] ?? null;
                $email = $input['email'] ?? null;
                $contacto_nombre = $input['contacto_nombre'] ?? null;
                $contacto_telefono = $input['contacto_telefono'] ?? null;

                if (empty($rut) || empty($razon_social)) {
                    http_response_code(400);
                    echo json_encode(['error' => 'RUT y Razón Social son obligatorios para el proveedor.']);
                    exit();
                }

                // Verificar si el RUT ya existe
                $stmt_check = $pdo->prepare("SELECT COUNT(*) FROM proveedores WHERE rut = ?");
                $stmt_check->execute([$rut]);
                if ($stmt_check->fetchColumn() > 0) {
                    http_response_code(409); // Conflict
                    echo json_encode(['error' => 'El RUT del proveedor ya está registrado.']);
                    exit();
                }

                $stmt = $pdo->prepare("
                    INSERT INTO proveedores (rut, razon_social, direccion, telefono, email, contacto_nombre, contacto_telefono, creado_en)
                    VALUES (?, ?, ?, ?, ?, ?, ?, NOW()) -- Cambiado GETDATE() a NOW()
                ");
                $stmt->execute([$rut, $razon_social, $direccion, $telefono, $email, $contacto_nombre, $contacto_telefono]);

                http_response_code(201); // Created
                echo json_encode(['message' => 'Proveedor añadido exitosamente!', 'id' => $pdo->lastInsertId()]);

            } elseif ($action === 'update' && isset($_GET['id'])) {
                // Actualizar proveedor existente
                $id = $_GET['id'];
                $rut = $input['rut'] ?? null;
                $razon_social = $input['razon_social'] ?? null;
                $direccion = $input['direccion'] ?? null;
                $telefono = $input['telefono'] ?? null; // Añadido telefono para actualización
                $email = $input['email'] ?? null;
                $contacto_nombre = $input['contacto_nombre'] ?? null;
                $contacto_telefono = $input['contacto_telefono'] ?? null;

                if (empty($rut) || empty($razon_social)) {
                    http_response_code(400);
                    echo json_encode(['error' => 'RUT y Razón Social son obligatorios para el proveedor.']);
                    exit();
                }

                // Verificar si el nuevo RUT ya existe en otro proveedor (excepto el actual)
                $stmt_check = $pdo->prepare("SELECT COUNT(*) FROM proveedores WHERE rut = ? AND id <> ?");
                $stmt_check->execute([$rut, $id]);
                if ($stmt_check->fetchColumn() > 0) {
                    http_response_code(409); // Conflict
                    echo json_encode(['error' => 'El RUT del proveedor ya está registrado por otro proveedor.']);
                    exit();
                }

                $stmt = $pdo->prepare("
                    UPDATE proveedores SET
                        rut = ?, razon_social = ?, direccion = ?, telefono = ?, email = ?, -- Añadido telefono aquí
                        contacto_nombre = ?, contacto_telefono = ?
                    WHERE id = ?
                ");
                $stmt->execute([$rut, $razon_social, $direccion, $telefono, $email, $contacto_nombre, $contacto_telefono, $id]);

                if ($stmt->rowCount() > 0) {
                    http_response_code(200);
                    echo json_encode(['message' => 'Proveedor actualizado exitosamente!']);
                } else {
                    http_response_code(404);
                    echo json_encode(['error' => 'Proveedor no encontrado o sin cambios.']);
                }

            } else {
                http_response_code(400);
                echo json_encode(['error' => 'Acción POST no válida para proveedores.']);
            }
            break;

        case 'DELETE':
            if ($action === 'delete' && isset($_GET['id'])) {
                $id = $_GET['id'];
                $stmt = $pdo->prepare("DELETE FROM proveedores WHERE id = ?");
                $stmt->execute([$id]);

                if ($stmt->rowCount() > 0) {
                    http_response_code(200);
                    echo json_encode(['message' => 'Proveedor eliminado exitosamente!']);
                } else {
                    http_response_code(404);
                    echo json_encode(['error' => 'Proveedor no encontrado.']);
                }
            } else {
                http_response_code(400);
                echo json_encode(['error' => 'Acción DELETE no válida para proveedores.']);
            }
            break;

        default:
            http_response_code(405); // Method Not Allowed
            echo json_encode(['error' => 'Método no permitido.']);
            break;
    }

} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Error de base de datos: ' . $e->getMessage()]);
    error_log('Error PDO en proveedores.php: ' . $e->getMessage());
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Error inesperado: ' . $e->getMessage()]);
    error_log('Error general en proveedores.php: ' . $e->getMessage());
}
?>
