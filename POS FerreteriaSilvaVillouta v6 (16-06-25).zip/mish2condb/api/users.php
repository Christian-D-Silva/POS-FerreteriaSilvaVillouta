<?php
// api/users.php

require_once __DIR__ . '/../db_connection.php'; // Asegúrate de que esta ruta sea correcta
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

header('Content-Type: application/json');
// Verificar autenticación y permisos (solo administradores pueden gestionar usuarios)
// Asumiendo que el role_id de 'Administrador' es 1. Ajusta según tu DB.
$isAdmin = isset($_SESSION['user_role_id']) && $_SESSION['user_role_id'] == 1; // ID del rol de Administrador

if (!$isAdmin) {
    http_response_code(403); // Forbidden
    echo json_encode(['error' => 'Acceso denegado. Se requiere rol de Administrador.']);
    exit();
}

$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? '';

try {
    $pdo = get_db_connection();

    switch ($method) {
        case 'GET':
            if ($action === 'list') {
                // Listar todos los usuarios con su rol
                $stmt = $pdo->query("
                    SELECT u.id, u.username, u.full_name, u.email, u.role_id, ur.name as role_name
                    FROM users u
                    JOIN users_roles ur ON u.role_id = ur.id
                    ORDER BY u.username ASC
                ");
                echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
            } elseif ($action === 'list_roles') {
                // Listar todos los roles disponibles
                // CORREGIDO: Seleccionar 'name' en lugar de 'role_name'
                $stmt = $pdo->query("SELECT id, name as role_name FROM users_roles ORDER BY name ASC");
                echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
            } elseif ($action === 'details' && isset($_GET['id'])) {
                // Obtener detalles de un usuario específico
                $stmt = $pdo->prepare("
                    SELECT u.id, u.username, u.full_name, u.email, u.role_id, ur.name as role_name
                    FROM users u
                    JOIN users_roles ur ON u.role_id = ur.id
                    WHERE u.id = ?
                ");
                $stmt->execute([$_GET['id']]);
                $user = $stmt->fetch(PDO::FETCH_ASSOC);
                if ($user) {
                    echo json_encode($user);
                } else {
                    http_response_code(404);
                    echo json_encode(['error' => 'Usuario no encontrado.']);
                }
            } else {
                http_response_code(400); // Bad Request
                echo json_encode(['error' => 'Acción GET no válida para usuarios.']);
            }
            break;

        case 'POST':
            $input = json_decode(file_get_contents('php://input'), true);

            if ($action === 'add') {
                // Añadir nuevo usuario
                $username = $input['username'] ?? null;
                $full_name = $input['full_name'] ?? null;
                $email = $input['email'] ?? null;
                $password = $input['password'] ?? null;
                $confirm_password = $input['confirm_password'] ?? null;
                $role_id = $input['role_id'] ?? null;

                if (empty($username) || empty($password) || empty($confirm_password) || empty($role_id)) {
                    http_response_code(400);
                    echo json_encode(['error' => 'Usuario, contraseña, confirmación de contraseña y rol son obligatorios.']);
                    exit();
                }
                if ($password !== $confirm_password) {
                    http_response_code(400);
                    echo json_encode(['error' => 'Las contraseñas no coinciden.']);
                    exit();
                }
                if (strlen($password) < 6) {
                    http_response_code(400);
                    echo json_encode(['error' => 'La contraseña debe tener al menos 6 caracteres.']);
                    exit();
                }

                // Verificar si el username o email ya existen
                $stmt_check = $pdo->prepare("SELECT COUNT(*) FROM users WHERE username = ? OR email = ?");
                $stmt_check->execute([$username, $email]);
                if ($stmt_check->fetchColumn() > 0) {
                    http_response_code(409); // Conflict
                    echo json_encode(['error' => 'El nombre de usuario o el email ya están registrados.']);
                    exit();
                }

                $hashed_password = password_hash($password, PASSWORD_DEFAULT);

                $stmt = $pdo->prepare("
                    INSERT INTO users (username, full_name, email, password_hash, role_id)
                    VALUES (?, ?, ?, ?, ?)
                ");
                $stmt->execute([$username, $full_name, $email, $hashed_password, $role_id]);

                http_response_code(201); // Created
                echo json_encode(['message' => 'Usuario añadido exitosamente!', 'id' => $pdo->lastInsertId()]);

            } elseif ($action === 'update' && isset($_GET['id'])) {
                // Actualizar usuario existente
                $id = $_GET['id'];
                $username = $input['username'] ?? null;
                $full_name = $input['full_name'] ?? null;
                $email = $input['email'] ?? null;
                $password = $input['password'] ?? null; // Nueva contraseña, opcional
                $confirm_password = $input['confirm_password'] ?? null; // Confirmación, opcional
                $role_id = $input['role_id'] ?? null;

                if (empty($username) || empty($role_id)) {
                    http_response_code(400);
                    echo json_encode(['error' => 'Usuario y Rol son obligatorios para la actualización.']);
                    exit();
                }

                // Verificar si el username o email ya existen para otro usuario
                $stmt_check = $pdo->prepare("SELECT COUNT(*) FROM users WHERE (username = ? OR email = ?) AND id <> ?");
                $stmt_check->execute([$username, $email, $id]);
                if ($stmt_check->fetchColumn() > 0) {
                    http_response_code(409); // Conflict
                    echo json_encode(['error' => 'El nombre de usuario o el email ya están registrados por otro usuario.']);
                    exit();
                }

                $sql = "UPDATE users SET username = ?, full_name = ?, email = ?, role_id = ?";
                $params = [$username, $full_name, $email, $role_id];

                // Si se proporciona una nueva contraseña
                if (!empty($password)) {
                    if ($password !== $confirm_password) {
                        http_response_code(400);
                        echo json_encode(['error' => 'Las contraseñas no coinciden.']);
                        exit();
                    }
                     if (strlen($password) < 6) {
                        http_response_code(400);
                        echo json_encode(['error' => 'La contraseña debe tener al menos 6 caracteres.']);
                        exit();
                    }
                    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                    $sql .= ", password_hash = ?";
                    $params[] = $hashed_password;
                }
                
                $sql .= " WHERE id = ?";
                $params[] = $id;

                $stmt = $pdo->prepare($sql);
                $stmt->execute($params);

                if ($stmt->rowCount() > 0) {
                    http_response_code(200);
                    echo json_encode(['message' => 'Usuario actualizado exitosamente!']);
                } else {
                    http_response_code(404);
                    echo json_encode(['error' => 'Usuario no encontrado o sin cambios.']);
                }

            } else {
                http_response_code(400);
                echo json_encode(['error' => 'Acción POST no válida para usuarios.']);
            }
            break;

        case 'DELETE':
            if ($action === 'delete' && isset($_GET['id'])) {
                $id = $_GET['id'];

                // Opcional: Validar que no se puede eliminar el propio usuario loggeado
                if (isset($_SESSION['user_id']) && $_SESSION['user_id'] == $id) {
                    http_response_code(403);
                    echo json_encode(['error' => 'No puedes eliminar tu propia cuenta de usuario.']);
                    exit();
                }

                $stmt = $pdo->prepare("DELETE FROM users WHERE id = ?");
                $stmt->execute([$id]);

                if ($stmt->rowCount() > 0) {
                    http_response_code(200);
                    echo json_encode(['message' => 'Usuario eliminado exitosamente!']);
                } else {
                    http_response_code(404);
                    echo json_encode(['error' => 'Usuario no encontrado.']);
                }
            } else {
                http_response_code(400);
                echo json_encode(['error' => 'Acción DELETE no válida para usuarios.']);
            }
            break;

        default:
            http_response_code(405); // Method Not Allowed
            echo json_encode(['error' => 'Método no permitido.']);
            break;
    }

} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Error de base de datos: ' . $e->getMessage()]);
    error_log('Error PDO en users.php: ' . $e->getMessage());
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Error inesperado: ' . $e->getMessage()]);
    error_log('Error general en users.php: ' . $e->getMessage());
}
?>
