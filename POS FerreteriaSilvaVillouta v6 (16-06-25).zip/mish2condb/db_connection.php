<?php
// db_connection.php

// --- Configuración de la base de datos ---
// ¡IMPORTANTE! Reemplaza estos valores con tus credenciales reales de la base de datos
$db_config = [
    'host'     => 'localhost',
    'dbname'   => 'ferretera_pos', // Asegúrate de que este es el nombre correcto de tu DB
    'user'     => 'root',          // Tu usuario de la base de datos
    'password' => '',              // Tu contraseña de la base de datos
    'charset'  => 'utf8mb4'
];

/**
 * Establece y devuelve una conexión PDO a la base de datos.
 * Incluye manejo de errores para conexiones fallidas.
 *
 * @return PDO|null Retorna un objeto PDO si la conexión es exitosa, de lo contrario null.
 */
function get_db_connection() {
    global $db_config;

    // Asegurarse de que los errores de PDO lancen excepciones
    $options = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ];

    $dsn = "mysql:host={$db_config['host']};dbname={$db_config['dbname']};charset={$db_config['charset']}";

    try {
        $pdo = new PDO($dsn, $db_config['user'], $db_config['password'], $options);
        return $pdo;
    } catch (PDOException $e) {
        // En caso de error de conexión, registra el error y devuelve un mensaje JSON.
        // Esto evita que PDOException genere HTML en la salida, lo que rompería el JSON.
        error_log("Error de conexión a la base de datos: " . $e->getMessage());
        
        // Comprobar si las cabeceras ya se han enviado (podría ocurrir si hay un error PHP anterior)
        if (!headers_sent()) {
            http_response_code(500); // Internal Server Error
            header('Content-Type: application/json'); // Asegurarse de que la cabecera sea JSON
        }
        
        // No salimos con exit() para permitir que el script principal maneje el error,
        // pero enviamos un mensaje de error claro.
        echo json_encode(['error' => 'Error de conexión a la base de datos. Por favor, inténtelo de nuevo más tarde.']);
        
        // Retornar null para indicar que la conexión falló
        return null;
    }
}
