// js/historial.js

// Función de inicialización principal para el módulo de Historial de Ventas
window.initHistorial = async () => {
    // Estas variables ahora son accesibles en todo el ámbito de initHistorial
    const historyTableBody = document.getElementById('history-table-body');
    const historyDateFilter = document.getElementById('history-date-filter');
    const clearHistoryFilterBtn = document.getElementById('clear-history-filter');
    const saleDetailsModal = document.getElementById('sale-details-modal');
    const saleDetailsContent = document.getElementById('sale-details-content');
    const closeSaleDetailsModalBtn = document.getElementById('close-sale-details-modal-btn');

    // Mantenemos requestAnimationFrame, es una buena práctica
    requestAnimationFrame(async () => {
        // Validación de elementos: Si esto se dispara, aún hay un problema en el HTML
        if (!historyTableBody || !historyDateFilter || !clearHistoryFilterBtn || !saleDetailsModal || !saleDetailsContent || !closeSaleDetailsModalBtn) {
            console.error('Faltan referencias a elementos del DOM en historial.js. Asegúrate de que historial.html esté cargado correctamente y los IDs sean correctos.');
            window.showToast('Error: No se cargó la interfaz de historial correctamente.', true);
            return;
        }

        // --- FUNCIONES AUXILIARES INTERNAS DEL MÓDULO DE HISTORIAL ---

        async function loadSalesHistory() {
            try {
                // Asegurarse de que los datos globales (salesHistory, clients, products, users) estén cargados
                // NOTA: 'window.loadDataFromAPI()' debe encargarse de cargar todos estos.
                if (!window.salesHistory || window.salesHistory.length === 0 ||
                    !window.clients || window.clients.length === 0 ||
                    !window.products || window.products.length === 0 ||
                    !window.users || window.users.length === 0) {
                    console.warn('Datos globales faltantes. Intentando recargar datos de la API...');
                    await window.loadDataFromAPI(); // Recargar si los datos no están disponibles
                }
                console.log('Datos de ventas disponibles para renderizar:', window.salesHistory);
                renderSalesHistory();
            } catch (error) {
                console.error('Error al cargar historial de ventas:', error);
                window.showToast('Error al cargar el historial de ventas.', true);
            }
        }

        function renderSalesHistory() {
            console.log('--- Iniciando renderSalesHistory ---');
            const filterDate = historyDateFilter.value;
            let filteredSales = window.salesHistory || []; // Asegurarse de que sea un array

            console.log('Fecha de filtro seleccionada:', filterDate);

            if (filterDate) {
                filteredSales = filteredSales.filter(sale => {
                    const saleDatePart = sale.sale_date ? sale.sale_date.substring(0, 10) : '';
                    return saleDatePart === filterDate;
                });
            }

            console.log('Ventas filtradas para mostrar:', filteredSales);

            historyTableBody.innerHTML = ''; // Limpiar la tabla

            if (filteredSales.length === 0) {
                const noDataRow = document.createElement('tr');
                noDataRow.innerHTML = `<td colspan="8" class="p-3 text-center text-gray-500">No hay ventas registradas para el filtro seleccionado.</td>`;
                historyTableBody.appendChild(noDataRow);
                console.log('No hay ventas para mostrar o el filtro es demasiado estricto.');
                return;
            }

            filteredSales.forEach(sale => {
                console.log('Procesando venta:', sale); // Log de cada venta

                const row = document.createElement('tr');

                // Procesamiento de datos para asegurar que sean cadenas válidas
                const saleId = sale.id || 'N/A';
                const saleDate = sale.sale_date ? sale.sale_date.substring(0, 10) : 'N/A';
                const saleTime = sale.sale_date ? sale.sale_date.substring(11, 16) : 'N/A'; // Asumiendo que sale_date incluye tiempo
                const documentType = sale.document_type || 'N/A';

                // Buscar cliente por ID, si existe. Fallback a 'Consumidor Final'
                const client = window.clients.find(c => c.id == sale.client_id);
                const clientName = client ? client.razon_social : 'Consumidor Final';

                // Buscar vendedor por ID. Fallback a 'Desconocido'
                const user = window.users.find(u => u.id == sale.user_id);
                const userName = user ? (user.full_name || user.username) : 'Desconocido';

                const totalAmount = window.formatCurrency ? window.formatCurrency(sale.total_amount) : (sale.total_amount || 'N/A');

                row.innerHTML = `
                    <td class="p-3">${saleId}</td>
                    <td class="p-3">${saleDate}</td>
                    <td class="p-3">${saleTime}</td>
                    <td class="p-3">${documentType}</td>
                    <td class="p-3">${clientName}</td>
                    <td class="p-3">${userName}</td>
                    <td class="p-3">${totalAmount}</td>
                    <td class="p-3">
                        <button class="text-blue-600 hover:underline" onclick="window.viewSaleDetails(${saleId})">Ver Detalles</button>
                    </td>
                `;
                historyTableBody.appendChild(row);
                console.log('Fila añadida al DOM para venta ID:', saleId); // Confirmación de añadido
            });

            // Re-crear iconos Lucide si es necesario
            if (window.lucide) {
                window.lucide.createIcons();
            }
            console.log('--- Finalizado renderSalesHistory ---');
        }

        async function viewSaleDetails(saleId) {
            try {
                const saleDetails = window.salesHistory.find(s => s.id == saleId);

                if (!saleDetails) {
                    console.error('Detalles de venta no encontrados para ID:', saleId);
                    window.showToast('Detalles de venta no encontrados.', true);
                    return;
                }

                // Cargar ítems de la venta si no están ya en el objeto de venta
                if (!saleDetails.items) {
                    console.log(`Cargando ítems para la venta ID: ${saleId} desde la API.`);
                    const response = await fetch(`api/sales.php?action=get_details&id=${saleId}`);
                    if (!response.ok) {
                        throw new Error(`Error al obtener detalles de venta: ${response.statusText}`);
                    }
                    const data = await response.json();
                    saleDetails.items = data.items; // Añadir los ítems a la venta cargada
                }

                const client = window.clients.find(c => c.id == saleDetails.client_id);
                const user = window.users.find(u => u.id == saleDetails.user_id);

                // Mejor manejo de fechas para toLocaleDateString/TimeString
                const saleDateTime = new Date(saleDetails.sale_date);
                const dateStr = saleDateTime.toLocaleDateString('es-CL');
                const timeStr = saleDateTime.toLocaleTimeString('es-CL', { hour: '2-digit', minute: '2-digit' });

                const clientInfo = client ? `<p><strong>Cliente:</strong> ${client.razon_social} (RUT: ${client.rut})</p>` : `<p><strong>Cliente:</strong> Consumidor Final</p>`;
                const userInfo = user ? `<p><strong>Vendedor:</strong> ${user.full_name}</p>` : `<p><strong>Vendedor:</strong> Desconocido</p>`;

                const itemsSubtotal = saleDetails.items.reduce((sum, item) => sum + (item.quantity * item.price_at_sale), 0);

                saleDetailsContent.innerHTML = `
                    <p><strong>ID Venta:</strong> ${saleDetails.id}</p>
                    <p><strong>Fecha:</strong> ${dateStr} ${timeStr}</p>
                    <p><strong>Tipo Documento:</strong> ${saleDetails.document_type || 'N/A'}</p>
                    ${clientInfo}
                    ${userInfo}
                    <h4 class="text-lg font-semibold mb-2 mt-4">Productos:</h4>
                    <ul class="list-disc pl-5 mb-4">
                        ${saleDetails.items.map(item => {
                            const product = window.products.find(p => p.id == item.product_id);
                            const productName = product ? product.name : `Producto ID: ${item.product_id || 'N/A'}`;
                            const productSku = product ? `(SKU: ${product.sku || 'N/A'})` : '';
                            return `<li>${productName} ${productSku} - ${item.quantity || 0} x ${window.formatCurrency(item.price_at_sale || 0)} = ${window.formatCurrency((item.quantity || 0) * (item.price_at_sale || 0))}</li>`;
                        }).join('')}
                    </ul>
                    <p><strong>Subtotal de Ítems:</strong> ${window.formatCurrency(itemsSubtotal)}</p>
                    <p><strong>Descuento Aplicado:</strong> -${window.formatCurrency(saleDetails.discount_amount || 0)}</p>
                    <p class="text-xl font-semibold mt-2">IVA (19%): ${window.formatCurrency(saleDetails.tax_amount || 0)}</p>
                    <p class="text-2xl font-bold mt-2">Total Final: ${window.formatCurrency(saleDetails.total_amount || 0)}</p>
                `;
                saleDetailsModal.classList.remove('hidden');

            } catch (error) {
                console.error('Error al mostrar detalles de venta:', error);
                window.showToast(`Error al cargar los detalles de la venta: ${error.message}`, true);
            }
        }

        // --- ASIGNACIONES DE FUNCIONES AL OBJETO WINDOW ---
        window.renderSalesHistory = renderSalesHistory;
        window.viewSaleDetails = viewSaleDetails;

        // --- CONFIGURACIÓN DE EVENT LISTENERS ---
        historyDateFilter.addEventListener('change', renderSalesHistory); // Llama a la función directamente
        clearHistoryFilterBtn.addEventListener('click', () => {
            historyDateFilter.value = ''; // Limpiar el filtro de fecha
            renderSalesHistory(); // Re-renderizar sin filtro
        });
        closeSaleDetailsModalBtn.addEventListener('click', () => saleDetailsModal.classList.add('hidden'));

        // Cargar y renderizar historial al iniciar el módulo
        await loadSalesHistory();

        // Actualizar iconos Lucide para esta sección
        if (window.lucide) {
            window.lucide.createIcons();
        }
    }); // Fin de requestAnimationFrame
};