// js/users.js

// Variable global para almacenar el ID del usuario que se está editando
let currentEditingUserId = null;

// Función de inicialización para el módulo de Usuarios
window.initUsers = async () => {
    console.log('--- Iniciando initUsers ---');

    // 1. Obtener todas las referencias a los elementos DOM localmente
    const usersTableBody = document.getElementById('users-table-body');
    const userSearchInput = document.getElementById('user-search-input');
    const noUsersMessage = document.getElementById('no-users-message');
    const addUserBtn = document.getElementById('add-user-btn');
    const userModal = document.getElementById('user-modal');
    const closeModalBtn = userModal.querySelector('#cancel-user-btn'); // Botón de cancelar/cerrar
    const userModalTitle = document.getElementById('user-modal-title');
    const userForm = document.getElementById('user-form');
    const userIdInput = document.getElementById('user-id');
    const usernameInput = document.getElementById('username');
    const fullNameInput = document.getElementById('full-name');
    const emailInput = document.getElementById('email');
    const passwordFields = document.getElementById('password-fields'); // Contenedor de campos de contraseña
    const passwordInput = document.getElementById('password');
    const confirmPasswordInput = document.getElementById('confirm-password');
    const userRoleSelect = document.getElementById('user-role');
    const userFormErrorMessage = document.getElementById('user-form-error-message');


    // Validar que los elementos esenciales existan
    if (!usersTableBody || !userSearchInput || !addUserBtn || !userModal || !closeModalBtn || !userModalTitle || !userForm || !userIdInput || !usernameInput || !fullNameInput || !emailInput || !passwordFields || !passwordInput || !confirmPasswordInput || !userRoleSelect || !userFormErrorMessage) {
        console.error('Error: Faltan algunos elementos principales del DOM de usuarios. Asegúrate de que los IDs sean correctos.');
        window.showToast('Error: No se pudo cargar la interfaz de usuarios correctamente. Ver consola.', true);
        return;
    }

    // --- FUNCIONES INTERNAS (CLOSURES) ---

    /**
     * Carga la lista de usuarios desde la API y la almacena globalmente.
     * Luego, renderiza la tabla.
     */
    async function loadUsers() {
        try {
            if (noUsersMessage) noUsersMessage.textContent = 'Cargando usuarios...';
            usersTableBody.innerHTML = ''; // Limpiar la tabla antes de cargar

            const response = await fetch('api/users.php?action=list');
            if (!response.ok) throw new Error('Error al cargar listado de usuarios.');
            
            window.users = await response.json(); // Almacenar usuarios globalmente

            renderUsersTable(); // Renderizar la tabla con los datos cargados

        } catch (error) {
            console.error('Error cargando usuarios:', error);
            if (noUsersMessage) noUsersMessage.textContent = 'Error al cargar usuarios.';
            window.showToast(`Error al cargar usuarios: ${error.message}`, true);
        }
    }

    /**
     * Carga la lista de roles desde la API y los popula en el select de roles.
     */
    async function loadRoles() {
        try {
            const response = await fetch('api/users.php?action=list_roles');
            if (!response.ok) throw new Error('Error al cargar roles.');
            
            window.roles = await response.json(); // Almacenar roles globalmente

            userRoleSelect.innerHTML = '<option value="">Selecciona un Rol</option>'; // Opción por defecto
            window.roles.forEach(role => {
                const option = document.createElement('option');
                option.value = role.id;
                option.textContent = role.role_name; // Asumiendo que el campo es 'role_name'
                userRoleSelect.appendChild(option);
            });

        } catch (error) {
            console.error('Error cargando roles:', error);
            window.showToast(`Error al cargar roles: ${error.message}`, true);
        }
    }

    /**
     * Renderiza la tabla de usuarios en el DOM.
     * Aplica filtrado basado en el input de búsqueda.
     * Adjunta listeners de eventos a los botones de acción.
     */
    function renderUsersTable() {
        usersTableBody.innerHTML = '';
        const searchTerm = userSearchInput.value.toLowerCase().trim();
        
        const filteredUsers = window.users.filter(user => {
            const matchesSearch = searchTerm === '' ||
                                  (user.username && user.username.toLowerCase().includes(searchTerm)) ||
                                  (user.full_name && user.full_name.toLowerCase().includes(searchTerm)) ||
                                  (user.email && user.email.toLowerCase().includes(searchTerm)) ||
                                  (user.role_name && user.role_name.toLowerCase().includes(searchTerm)); // Filtrar por nombre de rol
            return matchesSearch;
        });

        if (filteredUsers.length === 0) {
            usersTableBody.innerHTML = `<tr><td colspan="6" class="p-4 text-center text-gray-500">${window.users && window.users.length > 0 ? 'No se encontraron resultados para la búsqueda.' : 'No hay usuarios registrados aún.'}</td></tr>`;
            if (noUsersMessage) noUsersMessage.classList.remove('hidden');
        } else {
            if (noUsersMessage) noUsersMessage.classList.add('hidden');
            filteredUsers.forEach(user => {
                const row = document.createElement('tr');
                row.className = 'hover:bg-gray-50';

                row.innerHTML = `
                    <td class="p-3">${user.id}</td>
                    <td class="p-3">${user.username || 'N/A'}</td>
                    <td class="p-3">${user.full_name || 'N/A'}</td>
                    <td class="p-3">${user.email || 'N/A'}</td>
                    <td class="p-3">${user.role_name || 'N/A'}</td>
                    <td class="p-3">
                        <div class="flex items-center space-x-2">
                            <button class="edit-user-btn text-yellow-600 hover:text-yellow-800 p-1 rounded-md hover:bg-yellow-100 transition-colors" data-user-id="${user.id}" title="Editar Usuario">
                                <span class="lucide" data-lucide="edit"></span>
                            </button>
                            <button class="delete-user-btn text-red-600 hover:text-red-800 p-1 rounded-md hover:bg-red-100 transition-colors" data-user-id="${user.id}" title="Eliminar Usuario">
                                <span class="lucide" data-lucide="trash-2"></span>
                            </button>
                        </div>
                    </td>
                `;
                usersTableBody.appendChild(row);
            });

            // Adjuntar Event Listeners a los botones DESPUÉS de que se hayan agregado al DOM
            usersTableBody.querySelectorAll('.edit-user-btn').forEach(button => {
                button.addEventListener('click', (event) => {
                    const id = event.currentTarget.dataset.userId;
                    window.editUser(id); // Llamada a la función globalmente accesible
                });
            });
            usersTableBody.querySelectorAll('.delete-user-btn').forEach(button => {
                button.addEventListener('click', (event) => {
                    const id = event.currentTarget.dataset.userId;
                    window.deleteUser(id); // Llamada a la función globalmente accesible
                });
            });
        }
        if (window.lucide) window.lucide.createIcons(); // Re-renderizar iconos Lucide
    }

    /**
     * Abre el modal para añadir o editar un usuario.
     * @param {Object} [user=null] - Objeto usuario si es para edición, null para añadir.
     */
    function openUserModal(user = null) {
        userForm.reset();
        userFormErrorMessage.classList.add('hidden'); // Ocultar mensaje de error
        userFormErrorMessage.textContent = ''; // Limpiar mensaje de error

        userModal.classList.remove('hidden');
        userModal.classList.add('flex'); // Asegurarse de que el modal se muestre con flexbox

        if (user) {
            currentEditingUserId = user.id;
            userModalTitle.textContent = 'Editar Usuario';
            userIdInput.value = user.id; // Asignar el ID al campo oculto
            usernameInput.value = user.username || '';
            fullNameInput.value = user.full_name || '';
            emailInput.value = user.email || '';
            userRoleSelect.value = user.role_id || ''; // Seleccionar el rol actual

            // Ocultar campos de contraseña en modo edición por defecto,
            // a menos que se quiera cambiar explícitamente la contraseña
            passwordFields.classList.add('hidden');
            passwordInput.removeAttribute('required');
            confirmPasswordInput.removeAttribute('required');

        } else {
            currentEditingUserId = null;
            userModalTitle.textContent = 'Añadir Nuevo Usuario';
            userIdInput.value = ''; // Limpiar el ID si es un nuevo usuario

            // Mostrar campos de contraseña y hacerlos requeridos para nuevos usuarios
            passwordFields.classList.remove('hidden');
            passwordInput.setAttribute('required', 'true');
            confirmPasswordInput.setAttribute('required', 'true');
        }
        if (window.lucide) window.lucide.createIcons(); // Asegurar que los iconos en el modal se rendericen
    }

    /**
     * Maneja el envío del formulario de usuario (añadir o actualizar).
     */
    async function handleUserFormSubmit(event) {
        event.preventDefault();

        userFormErrorMessage.classList.add('hidden'); // Ocultar mensaje de error al enviar
        userFormErrorMessage.textContent = '';

        const isEditing = currentEditingUserId !== null;
        const method = 'POST'; // Siempre POST, la acción se define en la URL
        const action = isEditing ? 'update' : 'add';
        const url = `api/users.php?action=${action}` + (isEditing ? `&id=${currentEditingUserId}` : '');

        const payload = {
            username: usernameInput.value.trim(),
            full_name: fullNameInput.value.trim(),
            email: emailInput.value.trim(),
            role_id: userRoleSelect.value
        };

        if (!isEditing) { // Solo si es un nuevo usuario
            payload.password = passwordInput.value;
            payload.confirm_password = confirmPasswordInput.value;
        } else {
            // Si en modo edición se rellenan las contraseñas, incluirlas
            if (passwordInput.value !== '' || confirmPasswordInput.value !== '') {
                payload.password = passwordInput.value;
                payload.confirm_password = confirmPasswordInput.value;
            }
        }

        // Validaciones frontend
        if (!payload.username || !payload.role_id) {
            userFormErrorMessage.textContent = 'Usuario y Rol son campos obligatorios.';
            userFormErrorMessage.classList.remove('hidden');
            return;
        }

        if (!isEditing || (payload.password || payload.confirm_password)) { // Si es nuevo o si se están cambiando contraseñas
            if (payload.password !== payload.confirm_password) {
                userFormErrorMessage.textContent = 'Las contraseñas no coinciden.';
                userFormErrorMessage.classList.remove('hidden');
                return;
            }
            if (payload.password.length < 6) { // Validación de longitud mínima de contraseña
                userFormErrorMessage.textContent = 'La contraseña debe tener al menos 6 caracteres.';
                userFormErrorMessage.classList.remove('hidden');
                return;
            }
        }

        try {
            const response = await fetch(url, {
                method: method,
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(payload)
            });

            const data = await response.json();

            if (response.ok) {
                window.showToast(data.message || (isEditing ? 'Usuario actualizado exitosamente!' : 'Usuario añadido exitosamente!'));
                userModal.classList.add('hidden'); // Ocultar modal
                userForm.reset(); // Resetear formulario
                await loadUsers(); // Recargar la lista de usuarios para actualizar la tabla
                await window.loadDataFromAPI(); // Recargar datos globales si es necesario (ej. currentUser, roles)
            } else {
                userFormErrorMessage.textContent = data.error || 'Error al guardar usuario.';
                userFormErrorMessage.classList.remove('hidden');
            }
        } catch (error) {
            console.error('Error de red al guardar usuario:', error);
            userFormErrorMessage.textContent = 'Error de conexión al guardar usuario. Inténtelo de nuevo.';
            userFormErrorMessage.classList.remove('hidden');
        }
    }

    /**
     * Elimina un usuario de la base de datos.
     * @param {number} id - ID del usuario a eliminar.
     */
    async function deleteUser(id) {
        // Reemplazar confirm() con un modal personalizado para mejor UX
        if (!confirm('¿Está seguro de que desea eliminar este usuario? Esta acción es irreversible.')) {
            return;
        }

        try {
            const response = await fetch(`api/users.php?action=delete&id=${id}`, {
                method: 'DELETE'
            });
            const data = await response.json();

            if (response.ok) {
                window.showToast(data.message || 'Usuario eliminado exitosamente!');
                await loadUsers(); // Recargar la lista de usuarios
                await window.loadDataFromAPI(); // Recargar datos globales si es necesario
            } else {
                window.showToast(data.error || 'Error al eliminar usuario.', true);
            }
        } catch (error) {
            console.error('Error de red al eliminar usuario:', error);
            window.showToast('Error de conexión al eliminar usuario.', true);
        }
    }


    // --- ASIGNACIONES DE FUNCIONES AL OBJETO WINDOW ---
    // Hacemos que estas funciones sean accesibles globalmente para los eventos en el HTML (si no se usan addEventListener)
    // o para llamadas desde otros módulos (ej. main.js).
    window.renderUsersTable = renderUsersTable;
    window.openUserModal = openUserModal;
    window.handleUserFormSubmit = handleUserFormSubmit;
    window.editUser = (id) => {
        const user = window.users.find(u => u.id == id);
        if (user) {
            window.openUserModal(user);
        } else {
            console.error('Usuario no encontrado para editar:', id);
            window.showToast('Usuario no encontrado para editar.', true);
        }
    };
    window.deleteUser = deleteUser;
    window.filterUsers = renderUsersTable; // filterUsers ahora simplemente llama a renderUsersTable para aplicar el filtro


    // --- CONFIGURACIÓN DE EVENT LISTENERS ---
    addUserBtn.addEventListener('click', () => window.openUserModal());
    closeModalBtn.addEventListener('click', () => userModal.classList.add('hidden'));
    userForm.addEventListener('submit', (e) => window.handleUserFormSubmit(e));

    // Event listener para búsqueda/filtrado de usuarios
    userSearchInput.addEventListener('input', () => window.filterUsers());

    // --- Carga inicial de datos al iniciar el módulo ---
    await loadRoles(); // Primero cargar los roles para que el select esté listo
    await loadUsers(); // Luego cargar los usuarios

    // Asegurarse de que los iconos Lucide se creen para toda la página
    if (window.lucide) {
        window.lucide.createIcons();
    }
};
