// js/adquisiciones.js

// Variables globales para el estado del módulo de Adquisiciones
let currentAcquisitionItems = []; // Array para almacenar los productos añadidos a la adquisición
let currentEditingAcquisitionId = null; // Para futura edición (no implementado en este set)
let currentEditingSupplierId = null; // Para la edición de proveedores

// --- FUNCIONES GLOBALES (DEFINICIONES COMPLETAS) ---
// Estas funciones se definen directamente en el objeto window para asegurar su disponibilidad global
// ANTES de que cualquier HTML dinámico las intente llamar, eliminando ReferenceErrors.

/**
 * Renderiza la tabla principal de adquisiciones, aplicando filtros si existen.
 * Los eventos para los botones de acción se adjuntan programáticamente.
 */
window.renderAcquisitionsTable = function() {
  const acquisitionTableBody = document.getElementById('acquisition-table-body');
  const acquisitionSearchInput = document.getElementById('acquisition-search-input'); // Se usa para el filtro
  const noAcquisitionsMessage = document.getElementById('no-acquisitions-message');

  if (!acquisitionTableBody || !noAcquisitionsMessage) {
    console.error('Elementos DOM para la tabla de adquisiciones no encontrados.');
    return;
  }

  acquisitionTableBody.innerHTML = '';
  const searchTerm = (acquisitionSearchInput ? acquisitionSearchInput.value.toLowerCase().trim() : '');

  const filteredAcquisitions = window.adquisitions ? window.adquisitions.filter(acq => {
    const matchesSearch = searchTerm === '' ||
                          (acq.numero_factura && acq.numero_factura.toLowerCase().includes(searchTerm)) ||
                          (acq.proveedor_nombre && acq.proveedor_nombre.toLowerCase().includes(searchTerm));
    return matchesSearch;
  }) : [];

  if (filteredAcquisitions.length === 0) {
    acquisitionTableBody.innerHTML = `<tr><td colspan="9" class="p-4 text-center text-gray-500">${window.adquisitions && window.adquisitions.length > 0 ? 'No se encontraron resultados para la búsqueda.' : 'No hay adquisiciones registradas aún.'}</td></tr>`;
    noAcquisitionsMessage.classList.remove('hidden');
  } else {
      noAcquisitionsMessage.classList.add('hidden');
      filteredAcquisitions.forEach(acq => {
          const row = document.createElement('tr');
          row.className = 'hover:bg-gray-50';
          row.innerHTML = `
              <td class="p-3">${acq.id}</td>
              <td class="p-3">${acq.numero_factura || 'N/A'}</td>
              <td class="p-3">${acq.proveedor_nombre || 'Desconocido'}</td>
              <td class="p-3">${acq.fecha_compra ? new Date(acq.fecha_compra).toLocaleDateString('es-CL') : 'N/A'}</td>
              <td class="p-3">${acq.fecha_vencimiento ? new Date(acq.fecha_vencimiento).toLocaleDateString('es-CL') : 'N/A'}</td>
              <td class="p-3">${window.formatCurrency(acq.total)}</td>
              <td class="p-3">
                  <span class="px-2 py-1 rounded-full text-xs font-semibold
                      ${acq.estado_pago === 'Pagada' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'}">
                      ${acq.estado_pago || 'Pendiente'}
                  </span>
              </td>
              <td class="p-3">${acq.usuario_nombre || 'Desconocido'}</td>
              <td class="p-3">
                  <div class="flex items-center space-x-2">
                      <button class="view-details-btn text-blue-600 hover:text-blue-800 p-1 rounded-md hover:bg-blue-100 transition-colors" data-acquisition-id="${acq.id}" title="Ver Detalles">
                          <span class="lucide" data-lucide="eye"></span>
                      </button>
                      <!-- Botones de Editar y Eliminar (implementación futura) -->
                  </div>
              </td>
          `;
          acquisitionTableBody.appendChild(row);
      });
      // Adjuntar event listeners DESPUÉS de que todas las filas han sido añadidas al DOM
      acquisitionTableBody.querySelectorAll('.view-details-btn').forEach(button => {
          button.addEventListener('click', (event) => {
              const id = event.currentTarget.dataset.acquisitionId;
              window.viewAcquisitionDetails(id);
          });
      });
      if (window.lucide) window.lucide.createIcons();
  }
};

/**
 * Actualiza la cantidad de un ítem de adquisición en la lista actual.
 * Renderiza los ítems para actualizar la UI.
 */
window.updateAcquisitionItemQuantity = function(index, newQuantity) {
  const quantity = parseInt(newQuantity);
  if (!isNaN(quantity) && quantity > 0) {
    currentAcquisitionItems[index].cantidad = quantity;
    currentAcquisitionItems[index].total_item = currentAcquisitionItems[index].cantidad * currentAcquisitionItems[index].precio_unitario;
    renderAcquisitionItems(); // Llamada a la función local para re-renderizar
  } else {
      window.showToast('La cantidad debe ser un número positivo.', true);
      renderAcquisitionItems(); // Volver a renderizar para mostrar el valor anterior
  }
};

/**
 * Actualiza el precio unitario de un ítem de adquisición en la lista actual.
 * Renderiza los ítems para actualizar la UI.
 */
window.updateAcquisitionItemPrice = function(index, newPrice) {
  const price = parseFloat(newPrice);
  if (!isNaN(price) && price >= 0) {
    currentAcquisitionItems[index].precio_unitario = price;
    currentAcquisitionItems[index].total_item = currentAcquisitionItems[index].cantidad * currentAcquisitionItems[index].precio_unitario;
    renderAcquisitionItems(); // Llamada a la función local para re-renderizar
  } else {
      window.showToast('El precio unitario debe ser un número válido.', true);
      renderAcquisitionItems(); // Volver a renderizar
  }
};

/**
 * Elimina un ítem de adquisición de la lista actual.
 * Renderiza los ítems para actualizar la UI.
 */
window.removeAcquisitionItem = function(index) {
  currentAcquisitionItems.splice(index, 1);
  renderAcquisitionItems(); // Llamada a la función local para re-renderizar
};

/**
 * Muestra los detalles de una adquisición en un modal.
 * @param {number} id - ID de la adquisición a mostrar.
 */
window.viewAcquisitionDetails = async function(id) {
  const acquisitionDetailsModal = document.getElementById('acquisition-details-modal');
  const detailId = document.getElementById('detail-id');
  const detailInvoiceNumber = document.getElementById('detail-invoice-number');
  const detailSupplier = document.getElementById('detail-supplier');
  const detailPurchaseDate = document.getElementById('detail-purchase-date');
  const detailDueDate = document.getElementById('detail-due-date');
  const detailPaymentStatus = document.getElementById('detail-payment-status');
  const detailUser = document.getElementById('detail-user');
  const detailItemsBody = document.getElementById('detail-items-body');
  const detailTotal = document.getElementById('detail-total');

  if (!acquisitionDetailsModal || !detailId || !detailItemsBody) {
    console.error('Elementos DOM para el modal de detalles de adquisición no encontrados.');
    return;
  }

  try {
      const response = await fetch(`api/adquisiciones.php?action=details&id=${id}`);
      if (!response.ok) throw new Error('Error al cargar detalles de la adquisición.');
      const details = await response.json();

      detailId.textContent = details.id;
      detailInvoiceNumber.textContent = details.numero_factura || 'N/A';
      detailSupplier.textContent = details.proveedor_nombre || 'Desconocido';
      detailPurchaseDate.textContent = details.fecha_compra ? new Date(details.fecha_compra).toLocaleDateString('es-CL') + ' ' + new Date(details.fecha_compra).toLocaleTimeString('es-CL', {hour: '2-digit', minute:'2-digit'}) : 'N/A';
      detailDueDate.textContent = details.fecha_vencimiento ? new Date(details.fecha_vencimiento).toLocaleDateString('es-CL') : 'N/A';
      detailPaymentStatus.textContent = details.estado_pago || 'Pendiente';
      detailUser.textContent = details.usuario_nombre || 'Desconocido';
      detailTotal.textContent = window.formatCurrency(details.total);

      detailItemsBody.innerHTML = '';
      if (details.items && details.items.length > 0) {
          details.items.forEach(item => {
              const row = document.createElement('tr');
              row.className = 'border-b last:border-b-0';
              row.innerHTML = `
                  <td class="p-2 border">${item.nombre_producto || 'Desconocido'} (ID: ${item.product_id})</td>
                  <td class="p-2 border">${item.cantidad}</td>
                  <td class="p-2 border">${window.formatCurrency(item.precio_unitario)}</td>
                  <td class="p-2 border">${window.formatCurrency(item.total_item)}</td>
              `;
              detailItemsBody.appendChild(row);
          });
      } else {
          detailItemsBody.innerHTML = '<tr><td colspan="4" class="p-2 text-center text-gray-500">No hay productos detallados para esta adquisición.</td></tr>';
      }

      acquisitionDetailsModal.classList.remove('hidden');
      acquisitionDetailsModal.classList.add('flex');
      if (window.lucide) window.lucide.createIcons();
  }
  catch (error) {
      console.error('Error al mostrar detalles de adquisición:', error);
      window.showToast(`Error al cargar los detalles de la adquisición: ${error.message}`, true);
  }
};

/**
 * Renderiza la tabla de proveedores en el modal de gestión.
 * Los eventos para los botones de acción se adjuntan programáticamente.
 */
window.renderSuppliersTable = function() {
  const suppliersTableBody = document.getElementById('suppliers-table-body');
  const noSuppliersMessage = document.getElementById('no-suppliers-message');

  if (!suppliersTableBody || !noSuppliersMessage) {
    console.error('Elementos DOM para la tabla de proveedores no encontrados.');
    return;
  }

  suppliersTableBody.innerHTML = '';
  if (!window.suppliers || window.suppliers.length === 0) {
      noSuppliersMessage.textContent = 'No hay proveedores registrados.';
      noSuppliersMessage.classList.remove('hidden');
  } else {
      noSuppliersMessage.classList.add('hidden');
      window.suppliers.forEach(sup => {
          const row = document.createElement('tr');
          row.className = 'hover:bg-gray-50';
          row.innerHTML = `
              <td class="p-3">${sup.id}</td>
              <td class="p-3">${sup.rut}</td>
              <td class="p-3">${sup.razon_social}</td>
              <td class="p-3">${sup.telefono || 'N/A'}</td>
              <td class="p-3">
                  <div class="flex items-center space-x-2">
                      <button class="edit-supplier-btn text-yellow-600 hover:text-yellow-800 p-1 rounded-md hover:bg-yellow-100 transition-colors" data-supplier-id="${sup.id}" title="Editar Proveedor">
                          <span class="lucide" data-lucide="edit"></span>
                      </button>
                      <button class="delete-supplier-btn text-red-600 hover:text-red-800 p-1 rounded-md hover:bg-red-100 transition-colors" data-supplier-id="${sup.id}" title="Eliminar Proveedor">
                          <span class="lucide" data-lucide="trash-2"></span>
                      </button>
                  </div>
              </td>
          `;
          suppliersTableBody.appendChild(row);
      });
      // Adjuntar event listeners DESPUÉS de que todas las filas han sido añadidas al DOM
      suppliersTableBody.querySelectorAll('.edit-supplier-btn').forEach(button => {
          button.addEventListener('click', (event) => {
              const id = event.currentTarget.dataset.supplierId;
              window.editSupplier(id);
          });
      });
      suppliersTableBody.querySelectorAll('.delete-supplier-btn').forEach(button => {
          button.addEventListener('click', (event) => {
              const id = event.currentTarget.dataset.supplierId;
              window.deleteSupplier(id);
          });
      });
  }
  if (window.lucide) window.lucide.createIcons();
};

/**
 * Rellena el formulario de proveedor para editar un proveedor existente.
 * @param {number} id - ID del proveedor a editar.
 */
window.editSupplier = function(id) {
  const supplierFormTitle = document.getElementById('supplier-form-title');
  const supplierIdInput = document.getElementById('supplier-id');
  const supplierRutInput = document.getElementById('supplier-rut');
  const supplierRazonSocialInput = document.getElementById('supplier-razon-social');
  const supplierDireccionInput = document.getElementById('supplier-direccion');
  const supplierTelefonoInput = document.getElementById('supplier-telefono');
  const supplierEmailInput = document.getElementById('supplier-email');
  const supplierContactoNombreInput = document.getElementById('supplier-contacto-nombre');
  const supplierContactoTelefonoInput = document.getElementById('supplier-contacto-telefono');
  const saveSupplierBtn = document.getElementById('save-supplier-btn');
  const cancelSupplierEditBtn = document.getElementById('cancel-supplier-edit-btn');

  const supplier = window.suppliers.find(s => s.id == id);
  if (supplier) {
      currentEditingSupplierId = supplier.id;
      supplierFormTitle.textContent = 'Editar Proveedor';
      supplierIdInput.value = supplier.id;
      supplierRutInput.value = supplier.rut;
      supplierRazonSocialInput.value = supplier.razon_social;
      supplierDireccionInput.value = supplier.direccion || '';
      supplierTelefonoInput.value = supplier.telefono || '';
      supplierEmailInput.value = supplier.email || '';
      supplierContactoNombreInput.value = supplier.contacto_nombre || '';
      supplierContactoTelefonoInput.value = supplier.contacto_telefono || '';
      
      saveSupplierBtn.textContent = 'Actualizar Proveedor';
      if (window.lucide) window.lucide.createIcons();
      cancelSupplierEditBtn.classList.remove('hidden');
  } else {
      window.showToast('Proveedor no encontrado para editar.', true);
  }
};

/**
 * Cancela el modo de edición de proveedor y resetea el formulario.
 */
window.cancelSupplierEdit = function() {
  const supplierForm = document.getElementById('supplier-form');
  const supplierFormTitle = document.getElementById('supplier-form-title');
  const saveSupplierBtn = document.getElementById('save-supplier-btn');
  const cancelSupplierEditBtn = document.getElementById('cancel-supplier-edit-btn');

  currentEditingSupplierId = null;
  supplierForm.reset();
  supplierFormTitle.textContent = 'Añadir Nuevo Proveedor';
  saveSupplierBtn.textContent = 'Guardar Proveedor';
  if (window.lucide) window.lucide.createIcons();
  cancelSupplierEditBtn.classList.add('hidden');
};

/**
 * Elimina un proveedor de la base de datos.
 * @param {number} id - ID del proveedor a eliminar.
 */
window.deleteSupplier = async function(id) {
  // Considera usar un modal personalizado en lugar de confirm() para mejor UX
  if (!confirm('¿Está seguro de que desea eliminar este proveedor? Esta acción es irreversible.')) {
      return;
  }
  try {
      const res = await fetch(`api/proveedores.php?action=delete&id=${id}`, {
          method: 'DELETE'
      });
      const data = await res.json();
      if (res.ok) {
          window.showToast(data.message || 'Proveedor eliminado exitosamente.');
          await loadSuppliersInternal(); // Recargar el select y la tabla de proveedores
          window.loadAndRenderSuppliersTable(); // Recargar la tabla en el modal de gestión
      } else {
          window.showToast(data.error || 'Error al eliminar proveedor.', true);
      }
  } catch (error) {
      console.error('Error de red al eliminar proveedor:', error);
      window.showToast('Error de conexión al eliminar proveedor.', true);
  }
};

/**
 * Abre el modal de gestión de proveedores y carga la tabla de proveedores.
 */
window.openSupplierManagementModal = async function() {
  const supplierManagementModal = document.getElementById('supplier-management-modal');
  window.cancelSupplierEdit(); // Asegurarse de que el formulario esté limpio al abrir
  await window.loadAndRenderSuppliersTable(); // Cargar y mostrar la tabla de proveedores
  supplierManagementModal.classList.remove('hidden');
  supplierManagementModal.classList.add('flex');
};


// --- INICIALIZACIÓN DEL MÓDULO ---
window.initAdquisiciones = async () => {
  console.log("✅ Módulo de adquisiciones inicializado correctamente.");

  // 1. Obtener todas las referencias a los elementos DOM localmente
  const acquisitionTableBody = document.getElementById('acquisition-table-body');
  const acquisitionSearchInput = document.getElementById('acquisition-search-input');
  const noAcquisitionsMessage = document.getElementById('no-acquisitions-message');
  const btnNuevaAdquisicion = document.getElementById("add-acquisition-btn");
  const acquisitionModal = document.getElementById("acquisition-modal");
  const closeAcquisitionModalBtn = document.getElementById("close-acquisition-modal-btn");
  const acquisitionForm = document.getElementById("acquisition-form");
  const supplierSelect = document.getElementById("supplier-select");
  const invoiceNumberInput = document.getElementById("invoice-number");
  const dueDateInput = document.getElementById("due-date");
  const paymentStatusSelect = document.getElementById("payment-status");
  const acquisitionTotalDisplay = document.getElementById("acquisition-total-display");
  const acquisitionTotalInput = document.getElementById("acquisition-total-input");

  // Referencias para la sección "Añadir Producto Existente"
  const existingProductSection = document.getElementById('existing-product-section');
  const productItemIdInput = document.getElementById('product-item-id-input');
  const productItemQuantityInput = document.getElementById('product-item-quantity-input');
  const productItemAcquisitionPriceInput = document.getElementById('product-item-acquisition-price-input'); // Renombrado
  const addItemToAcquisitionBtn = document.getElementById('add-item-to-acquisition-btn');
  const productLookupInfo = document.getElementById('product-lookup-info');

  // Referencias para la sección "Crear y Añadir Nuevo Producto"
  const newProductSection = document.getElementById('new-product-section');
  const productNewNameInput = document.getElementById('product-new-name');
  const productNewSkuInput = document.getElementById('product-new-sku');
  const productNewSellingPriceInput = document.getElementById('product-new-selling-price');
  const productNewInitialStockInput = document.getElementById('product-new-initial-stock');
  const productNewCategorySelect = document.getElementById('product-new-category');
  const productNewDescriptionTextarea = document.getElementById('product-new-description');
  const createAndAddNewProductBtn = document.getElementById('create-and-add-new-product-btn');

  const acquisitionItemsTableBody = document.getElementById('acquisition-items-table-body');
  const noItemsMessageRow = document.getElementById('no-items-message-row');
  const addItemErrorMessage = document.getElementById('add-item-error-message');

  const acquisitionDetailsModal = document.getElementById('acquisition-details-modal');
  const closeAcquisitionDetailsModalBtn = document.getElementById('close-acquisition-details-modal-btn');

  const manageSuppliersBtn = document.getElementById('manage-suppliers-btn');
  const supplierManagementModal = document.getElementById('supplier-management-modal');
  const closeSupplierManagementModalBtn = document.getElementById('close-supplier-management-modal-btn');
  const supplierForm = document.getElementById('supplier-form');
  const supplierRutInput = document.getElementById('supplier-rut');
  const supplierRazonSocialInput = document.getElementById('supplier-razon-social');
  const supplierFormTitle = document.getElementById('supplier-form-title');
  const supplierIdInput = document.getElementById('supplier-id');
  const saveSupplierBtn = document.getElementById('save-supplier-btn');
  const cancelSupplierEditBtn = document.getElementById('cancel-supplier-edit-btn');
  const suppliersTableBody = document.getElementById('suppliers-table-body');
  const noSuppliersMessage = document.getElementById('no-suppliers-message');
  const supplierDireccionInput = document.getElementById('supplier-direccion');
  const supplierTelefonoInput = document.getElementById('supplier-telefono');
  const supplierEmailInput = document.getElementById('supplier-email');
  const supplierContactoNombreInput = document.getElementById('supplier-contacto-nombre');
  const supplierContactoTelefonoInput = document.getElementById('supplier-contacto-telefono');

  // Referencias a los radio buttons de modo
  const modeExistingProductRadio = document.getElementById('mode-existing-product');
  const modeNewProductRadio = document.getElementById('mode-new-product');


  // Validar que los elementos esenciales existan
  if (!acquisitionTableBody || !btnNuevaAdquisicion || !acquisitionModal || !acquisitionForm || !supplierSelect || !invoiceNumberInput || !dueDateInput || !paymentStatusSelect || !existingProductSection || !productItemIdInput || !productItemQuantityInput || !productItemAcquisitionPriceInput || !addItemToAcquisitionBtn || !productLookupInfo || !newProductSection || !productNewNameInput || !productNewSkuInput || !productNewSellingPriceInput || !productNewInitialStockInput || !productNewCategorySelect || !productNewDescriptionTextarea || !createAndAddNewProductBtn || !acquisitionItemsTableBody || !acquisitionDetailsModal || !closeAcquisitionDetailsModalBtn || !manageSuppliersBtn || !supplierManagementModal || !closeSupplierManagementModalBtn || !supplierForm || !supplierRutInput || !supplierRazonSocialInput || !suppliersTableBody || !noSuppliersMessage || !supplierFormTitle || !supplierIdInput || !saveSupplierBtn || !cancelSupplierEditBtn || !modeExistingProductRadio || !modeNewProductRadio) {
    console.error('Error: Faltan algunos elementos principales del DOM en adquisiciones.html. Asegúrate de que los IDs sean correctos.');
    window.showToast('Error: No se pudo cargar la interfaz de adquisiciones correctamente. Ver consola.', true);
    return;
  }

  // --- FUNCIONES AUXILIARES INTERNAS DEL MÓDULO (no necesitan ser globales) ---

  // Cargar adquisiciones desde la API (llama a la función global renderAcquisitionsTable)
  async function loadAcquisitionsInternal() {
    try {
      if (noAcquisitionsMessage) noAcquisitionsMessage.textContent = 'Cargando adquisiciones...';
      acquisitionTableBody.innerHTML = '';

      const response = await fetch('api/adquisiciones.php?action=list');
      if (!response.ok) throw new Error('Error al cargar listado de adquisiciones.');
      window.adquisitions = await response.json(); // Almacenar globalmente
      window.renderAcquisitionsTable(); // Llamar a la función global para renderizar
    } catch (error) {
      console.error('Error cargando adquisiciones:', error);
      if (noAcquisitionsMessage) noAcquisitionsMessage.textContent = 'Error al cargar adquisiciones.';
      window.showToast(`Error al cargar adquisiciones: ${error.message}`, true);
    }
  }

  // Cargar proveedores en el select de adquisición
  async function loadSuppliersInternal() {
    try {
      const res = await fetch("api/proveedores.php?action=list");
      if (!res.ok) throw new Error("Error al cargar proveedores.");
      const data = await res.json();
      supplierSelect.innerHTML = '<option value="">Seleccione un proveedor</option>';
      data.forEach((prov) => {
        const option = document.createElement("option");
        option.value = prov.id;
        option.textContent = prov.razon_social;
        supplierSelect.appendChild(option);
      });
      window.suppliers = data; // Almacenar proveedores globalmente para el CRUD de proveedores
    } catch (err) {
      console.error("Error al cargar proveedores:", err);
      window.showToast("Error al cargar proveedores.", true);
    }
  }

  /**
   * Carga y renderiza la tabla de proveedores dentro del modal de gestión.
   */
  window.loadAndRenderSuppliersTable = async function() {
    if (!suppliersTableBody || !noSuppliersMessage) {
      console.error('Elementos DOM para la tabla de proveedores no encontrados en loadAndRenderSuppliersTable.');
      return;
    }
    try {
        if (noSuppliersMessage) noSuppliersMessage.textContent = 'Cargando proveedores...';
        suppliersTableBody.innerHTML = '';
        
        const response = await fetch('api/proveedores.php?action=list');
        if (!response.ok) throw new Error('Error al cargar proveedores para gestión.');
        window.suppliers = await response.json(); // Re-almacenar globalmente por si acaso

        window.renderSuppliersTable(); // Renderizar la tabla con la función global
    } catch (error) {
        console.error('Error cargando tabla de proveedores en el modal:', error);
        if (noSuppliersMessage) noSuppliersMessage.textContent = 'Error al cargar proveedores.';
        window.showToast(`Error al cargar proveedores para gestión: ${error.message}`, true);
    }
  }

  /**
   * Realiza una búsqueda del producto por ID y muestra su información.
   */
  async function lookupProductAndDisplayInfo() {
    const productId = parseInt(productItemIdInput.value);
    productLookupInfo.textContent = ''; // Limpiar información anterior
    productLookupInfo.classList.remove('text-red-500', 'text-green-600'); // Limpiar colores

    if (isNaN(productId) || productId <= 0) {
        return; // No hacer nada si el ID no es válido o está vacío
    }

    if (!window.products || !Array.isArray(window.products) || window.products.length === 0) {
        productLookupInfo.textContent = 'Error: Productos del inventario no cargados.';
        productLookupInfo.classList.add('text-red-500');
        console.error('window.products no está cargado o está vacío.');
        return;
    }

    const product = window.products.find(p => p.id == productId);
    if (product) {
        productLookupInfo.textContent = `${product.nombre_producto} (Stock actual: ${product.stock})`;
        productLookupInfo.classList.add('text-green-600');
        // Precargar el precio de adquisición con el precio de venta del producto (puede ser ajustado)
        productItemAcquisitionPriceInput.value = parseFloat(product.precio || 0).toFixed(2);
    } else {
        productLookupInfo.textContent = `Producto con ID ${productId} no encontrado.`;
        productLookupInfo.classList.add('text-red-500');
    }
  }

  /**
   * Carga las categorías en el select del formulario de "Nuevo Producto".
   */
  async function loadCategoriesForNewProduct() {
    if (!window.categories || !Array.isArray(window.categories) || window.categories.length === 0) {
      console.warn('window.categories no está cargado o está vacío. Cargando categorías desde la API...');
      try {
        const response = await fetch('api/productos.php?action=list_categories'); // Asumiendo que esta API existe en tu modulo productos
        if (!response.ok) throw new Error('Error al cargar categorías.');
        window.categories = await response.json(); // Cargar y hacer global si no lo está
      } catch (error) {
        console.error('Error al cargar categorías para el nuevo producto:', error);
        window.showToast('Error al cargar categorías de productos.', true);
        return;
      }
    }

    productNewCategorySelect.innerHTML = '<option value="">Seleccione una categoría</option>';
    window.categories.forEach(category => {
      const option = document.createElement('option');
      option.value = category.id;
      option.textContent = category.name;
      productNewCategorySelect.appendChild(option);
    });
  }

  // Lógica para añadir productos a la adquisición (ENTRADA MANUAL)
  function addProductToCurrentAcquisition() {
    addItemErrorMessage.classList.add('hidden');
    addItemErrorMessage.textContent = '';

    const productId = parseInt(productItemIdInput.value);
    const quantity = parseInt(productItemQuantityInput.value);
    const price = parseFloat(productItemAcquisitionPriceInput.value); // Usa el campo renombrado

    if (isNaN(productId) || productId <= 0) {
        addItemErrorMessage.textContent = 'El ID del producto debe ser un número válido y mayor que 0.';
        addItemErrorMessage.classList.remove('hidden');
        return;
    }
    if (isNaN(quantity) || quantity <= 0) {
        addItemErrorMessage.textContent = 'La cantidad debe ser un número válido y mayor que 0.';
        addItemErrorMessage.classList.remove('hidden');
        return;
    }
    if (isNaN(price) || price < 0) {
        addItemErrorMessage.textContent = 'El precio de adquisición debe ser un número válido y no negativo.';
        addItemErrorMessage.classList.remove('hidden');
        return;
    }

    if (!window.products || window.products.length === 0) {
        addItemErrorMessage.textContent = 'Error: No se han cargado los productos del inventario. Recargue la página.';
        addItemErrorMessage.classList.remove('hidden');
        console.error('window.products no está cargado o está vacío.');
        return;
    }

    const product = window.products.find(p => p.id == productId);
    if (!product) {
        addItemErrorMessage.textContent = `Producto con ID ${productId} no encontrado en el inventario.`;
        addItemErrorMessage.classList.remove('hidden');
        return;
    }

    const existingItemIndex = currentAcquisitionItems.findIndex(item => item.product_id === productId);

    if (existingItemIndex > -1) {
      currentAcquisitionItems[existingItemIndex].cantidad = quantity;
      currentAcquisitionItems[existingItemIndex].precio_unitario = price;
      currentAcquisitionItems[existingItemIndex].total_item = quantity * price;
    } else {
      currentAcquisitionItems.push({
        product_id: productId,
        nombre_producto: product.nombre_producto,
        cantidad: quantity,
        precio_unitario: price,
        total_item: quantity * price
      });
    }

    renderAcquisitionItems(); // Llama a la función local
    productItemIdInput.value = '';
    productItemQuantityInput.value = '1';
    productItemAcquisitionPriceInput.value = '0.00'; // Renombrado
    productLookupInfo.textContent = ''; // Limpiar info después de añadir
    productItemIdInput.focus();
  }

  // Lógica para Crear y Añadir Nuevo Producto a la Adquisición
  async function createAndAddNewProductToAcquisition() {
    addItemErrorMessage.classList.add('hidden');
    addItemErrorMessage.textContent = '';

    const name = productNewNameInput.value.trim();
    const sku = productNewSkuInput.value.trim();
    const sellingPrice = parseFloat(productNewSellingPriceInput.value);
    const initialStock = parseInt(productNewInitialStockInput.value);
    const category_id = productNewCategorySelect.value;
    const description = productNewDescriptionTextarea.value.trim();
    const acquisitionPrice = parseFloat(productItemAcquisitionPriceInput.value); // Usar este para la adquisición

    // Validaciones para el nuevo producto
    if (!name || !sku || isNaN(sellingPrice) || sellingPrice < 0 || isNaN(initialStock) || initialStock <= 0 || !category_id || isNaN(acquisitionPrice) || acquisitionPrice < 0) {
        addItemErrorMessage.textContent = 'Todos los campos de "Nuevo Producto" son obligatorios y deben ser válidos. El precio de adquisición también.';
        addItemErrorMessage.classList.remove('hidden');
        return;
    }
    
    // Validar si el SKU ya existe antes de intentar crear el producto
    const existingProductBySku = window.products.find(p => p.sku === sku);
    if (existingProductBySku) {
        addItemErrorMessage.textContent = `El SKU '${sku}' ya existe para el producto: ${existingProductBySku.nombre_producto}. No se puede crear un nuevo producto con este SKU.`;
        addItemErrorMessage.classList.remove('hidden');
        return;
    }

    // Paso 1: Crear el nuevo producto en el inventario
    try {
        const productPayload = {
            name: name,
            sku: sku,
            price: sellingPrice, // Precio de venta del producto
            stock: initialStock, // Stock inicial del producto (la cantidad adquirida)
            category_id: category_id,
            description: description
        };

        const resProduct = await fetch('api/products.php?action=add', { // Asumiendo api/products.php
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(productPayload)
        });
        const dataProduct = await resProduct.json();

        if (!resProduct.ok) {
            throw new Error(dataProduct.error || 'Error al crear el nuevo producto.');
        }

        const newProductId = dataProduct.id; // Asumiendo que la API devuelve el ID del nuevo producto
        window.showToast(`Producto '${name}' creado con ID ${newProductId}.`);

        // Recargar la lista global de productos para incluir el nuevo
        await window.loadDataFromAPI(); // Esto refresca window.products

        // Paso 2: Añadir el nuevo producto a la lista de ítems de la adquisición
        currentAcquisitionItems.push({
            product_id: newProductId,
            nombre_producto: name, // Usar el nombre que se acaba de crear
            cantidad: initialStock, // La cantidad adquirida es el stock inicial
            precio_unitario: acquisitionPrice, // Precio de adquisición de este lote
            total_item: initialStock * acquisitionPrice
        });

        renderAcquisitionItems(); // Re-renderizar la tabla de ítems de adquisición
        resetNewProductForm(); // Limpiar el formulario de nuevo producto
        modeExistingProductRadio.checked = true; // Volver al modo "existente"
        toggleProductAddMode(); // Actualizar la visibilidad de las secciones
        productItemIdInput.focus(); // Enfocar el campo de ID de producto existente

    } catch (error) {
        console.error('Error al crear o añadir nuevo producto:', error);
        addItemErrorMessage.textContent = `Error: ${error.message}`;
        addItemErrorMessage.classList.remove('hidden');
    }
  }

  // Resetea el formulario de "Nuevo Producto"
  function resetNewProductForm() {
    productNewNameInput.value = '';
    productNewSkuInput.value = '';
    productNewSellingPriceInput.value = '0.00';
    productNewInitialStockInput.value = '1';
    productNewCategorySelect.value = '';
    productNewDescriptionTextarea.value = '';
  }

  // Renderizar la tabla de ítems de adquisición en el formulario
  function renderAcquisitionItems() {
    acquisitionItemsTableBody.innerHTML = '';
    if (currentAcquisitionItems.length === 0) {
      if (noItemsMessageRow) noItemsMessageRow.classList.remove('hidden');
    } else {
      if (noItemsMessageRow) noItemsMessageRow.classList.add('hidden');
      currentAcquisitionItems.forEach((item, index) => {
        const row = document.createElement('tr');
        row.className = 'border-b last:border-b-0';
        row.innerHTML = `
          <td class="p-2">${item.nombre_producto} (ID: ${item.product_id})</td>
          <td class="p-2">
            <input type="number" value="${item.cantidad}" min="1" class="w-full p-1 border rounded-md text-center text-sm acquisition-item-quantity-input" data-index="${index}" />
          </td>
          <td class="p-2">
            <input type="number" value="${item.precio_unitario}" step="0.01" min="0" class="w-full p-1 border rounded-md text-center text-sm acquisition-item-price-input" data-index="${index}" />
          </td>
          <td class="p-2">${window.formatCurrency(item.total_item)}</td>
          <td class="p-2">
            <button class="remove-acquisition-item-btn text-red-500 hover:text-red-700 p-1 rounded-md hover:bg-red-100 transition-colors" data-index="${index}">
              <span class="lucide" data-lucide="x-circle"></span>
            </button>
          </td>
        `;
        acquisitionItemsTableBody.appendChild(row);
      });

      // Adjuntar event listeners a los inputs y botones recién creados
      acquisitionItemsTableBody.querySelectorAll('.acquisition-item-quantity-input').forEach(input => {
          input.addEventListener('change', (e) => {
              const index = e.target.dataset.index;
              window.updateAcquisitionItemQuantity(index, e.target.value);
          });
      });
      acquisitionItemsTableBody.querySelectorAll('.acquisition-item-price-input').forEach(input => {
          input.addEventListener('change', (e) => {
              const index = e.target.dataset.index;
              window.updateAcquisitionItemPrice(index, e.target.value);
          });
      });
      acquisitionItemsTableBody.querySelectorAll('.remove-acquisition-item-btn').forEach(button => {
          button.addEventListener('click', (e) => {
              const index = e.currentTarget.dataset.index;
              window.removeAcquisitionItem(index);
          });
      });
    }
    calculateAcquisitionTotal();
    if (window.lucide) window.lucide.createIcons();
  }

  // Calcula el total de la adquisición
  function calculateAcquisitionTotal() {
    let total = currentAcquisitionItems.reduce((sum, item) => sum + item.total_item, 0);
    acquisitionTotalDisplay.textContent = window.formatCurrency(total);
    acquisitionTotalInput.value = total.toFixed(2);
  }

  // Manejar el envío del formulario de proveedor (Añadir/Editar)
  async function handleSupplierFormSubmit(event) {
      event.preventDefault();

      const supplierDireccionInput = document.getElementById('supplier-direccion');
      const supplierTelefonoInput = document.getElementById('supplier-telefono');
      const supplierEmailInput = document.getElementById('supplier-email');
      const supplierContactoNombreInput = document.getElementById('supplier-contacto-nombre');
      const supplierContactoTelefonoInput = document.getElementById('supplier-contacto-telefono');
      
      const id = supplierIdInput.value;
      const action = currentEditingSupplierId ? 'update' : 'add';
      const url = `api/proveedores.php?action=${action}` + (currentEditingSupplierId ? `&id=${id}` : '');

      const payload = {
          rut: supplierRutInput.value.trim(),
          razon_social: supplierRazonSocialInput.value.trim(),
          direccion: supplierDireccionInput.value.trim(),
          telefono: supplierTelefonoInput.value.trim(),
          email: supplierEmailInput.value.trim(),
          contacto_nombre: supplierContactoNombreInput.value.trim(),
          contacto_telefono: supplierContactoTelefonoInput.value.trim()
      };

      if (!payload.rut || !payload.razon_social) {
          window.showToast('RUT y Razón Social son obligatorios.', true);
          return;
      }

      try {
          const res = await fetch(url, {
              method: 'POST', // Siempre POST para add/update con action param
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify(payload)
          });
          const data = await res.json();

          if (res.ok) {
              window.showToast(data.message || 'Operación de proveedor exitosa.');
              window.cancelSupplierEdit();
              await loadSuppliersInternal(); // Recargar el select de adquisición
              window.loadAndRenderSuppliersTable(); // Recargar la tabla en el modal de gestión
          } else {
              window.showToast(data.error || 'Error al guardar proveedor.', true);
          }
      } catch (error) {
          console.error('Error de red al guardar proveedor:', error);
          window.showToast('Error de conexión al guardar proveedor.', true);
      }
  }

  /**
   * Alterna la visibilidad entre las secciones de "Añadir Producto Existente"
   * y "Crear y Añadir Nuevo Producto".
   */
  function toggleProductAddMode() {
      if (modeExistingProductRadio.checked) {
          existingProductSection.classList.remove('hidden');
          newProductSection.classList.add('hidden');
          // Resetear el formulario de nuevo producto cuando se oculta
          resetNewProductForm();
      } else {
          existingProductSection.classList.add('hidden');
          newProductSection.classList.remove('hidden');
          // Limpiar la info de búsqueda de producto existente cuando se oculta
          productLookupInfo.textContent = '';
          productLookupInfo.classList.remove('text-red-500', 'text-green-600');
          productItemIdInput.value = ''; // Limpiar el ID del producto existente
          productItemAcquisitionPriceInput.value = '0.00'; // Limpiar precio adquisición
          productItemQuantityInput.value = '1'; // Resetear cantidad
          
          // Cargar categorías para el nuevo producto cada vez que se muestre
          loadCategoriesForNewProduct();
      }
      addItemErrorMessage.classList.add('hidden'); // Ocultar mensaje de error al cambiar de modo
  }


  // --- CONFIGURACIÓN DE EVENT LISTENERS ---

  btnNuevaAdquisicion.addEventListener("click", () => {
    acquisitionForm.reset();
    currentAcquisitionItems = [];
    renderAcquisitionItems();
    calculateAcquisitionTotal();
    supplierSelect.value = '';

    // Resetear y mostrar la sección de "Añadir Existente" por defecto
    modeExistingProductRadio.checked = true;
    toggleProductAddMode(); // Llamar para asegurar la visibilidad correcta

    productItemIdInput.value = '';
    productItemQuantityInput.value = '1';
    productItemAcquisitionPriceInput.value = '0.00'; // Renombrado
    addItemErrorMessage.classList.add('hidden');
    productLookupInfo.textContent = ''; // Limpiar info al abrir el modal

    document.getElementById('acquisition-modal-title').textContent = 'Registrar Nueva Adquisición';
    acquisitionModal.classList.remove("hidden");
    acquisitionModal.classList.add("flex");
  });

  closeAcquisitionModalBtn.addEventListener("click", () => {
    acquisitionModal.classList.add("hidden");
    acquisitionModal.classList.remove("flex");
  });
  if (closeAcquisitionDetailsModalBtn) {
    closeAcquisitionDetailsModalBtn.addEventListener("click", () => {
      acquisitionDetailsModal.classList.add('hidden');
      acquisitionDetailsModal.classList.remove('flex');
    });
  }


  if (acquisitionSearchInput) {
    acquisitionSearchInput.addEventListener('input', window.renderAcquisitionsTable);
  }

  // Event listeners para los radio buttons de modo
  modeExistingProductRadio.addEventListener('change', toggleProductAddMode);
  modeNewProductRadio.addEventListener('change', toggleProductAddMode);

  // Event listener para el feedback de producto por ID (modo existente)
  productItemIdInput.addEventListener('input', lookupProductAndDisplayInfo);

  // Botón "Añadir" para ambos modos (la lógica interna lo manejará)
  addItemToAcquisitionBtn.addEventListener('click', () => {
      if (modeExistingProductRadio.checked) {
          addProductToCurrentAcquisition();
      }
      // Si el otro modo está activo, este botón no debería estar visible o tener otro comportamiento.
      // Aquí, este botón solo opera en modo "existing".
  });

  // Botón "Crear Producto y Añadir a Adquisición" (solo para modo nuevo)
  createAndAddNewProductBtn.addEventListener('click', createAndAddNewProductToAcquisition);


  // Permitir añadir producto también con Enter en los campos de entrada existentes
  productItemIdInput.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); addProductToCurrentAcquisition(); } });
  productItemQuantityInput.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); addProductToCurrentAcquisition(); } });
  productItemAcquisitionPriceInput.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); addProductToCurrentAcquisition(); } }); // Renombrado

  // Permitir crear y añadir con Enter en los campos del nuevo producto
  productNewNameInput.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); createAndAddNewProductToAcquisition(); } });
  productNewSkuInput.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); createAndAddNewProductToAcquisition(); } });
  productNewSellingPriceInput.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); createAndAddNewProductToAcquisition(); } });
  productNewInitialStockInput.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); createAndAddNewProductToAcquisition(); } });


  acquisitionForm.addEventListener("submit", async (e) => {
    e.preventDefault();
    
    if (currentAcquisitionItems.length === 0) {
        window.showToast('Debe agregar al menos un producto a la adquisición.', true);
        return;
    }
    if (!supplierSelect.value) {
      window.showToast('Por favor, seleccione un proveedor.', true);
      return;
    }
    if (!invoiceNumberInput.value.trim()) {
      window.showToast('El número de factura es obligatorio.', true);
      return;
    }
    if (!dueDateInput.value) {
      window.showToast('La fecha de vencimiento es obligatoria.', true);
      return;
    }
    const totalAdquisicion = parseFloat(acquisitionTotalInput.value);
    if (isNaN(totalAdquisicion) || totalAdquisicion < 0) {
        window.showToast('El total de la adquisición no es válido.', true);
        return;
    }

    const payload = {
      proveedor_id: supplierSelect.value,
      numero_factura: invoiceNumberInput.value.trim(),
      fecha_vencimiento: dueDateInput.value,
      estado_pago: paymentStatusSelect.value,
      total: totalAdquisicion,
      items: currentAcquisitionItems.map(item => ({
          product_id: item.product_id,
          cantidad: item.cantidad,
          precio_unitario: item.precio_unitario,
          total_item: item.total_item
      }))
    };

    try {
      const res = await fetch("api/adquisiciones.php?action=add", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });
      const data = await res.json();

      if (res.ok) {
        window.showToast(data.message || "Adquisición registrada exitosamente.");
        acquisitionModal.classList.add("hidden");
        acquisitionForm.reset();
        currentAcquisitionItems = [];
        renderAcquisitionItems();
        await loadAcquisitionsInternal();
        await window.loadDataFromAPI(); // Recargar datos globales, incluyendo productos para que los nuevos estén disponibles
      } else {
        window.showToast(data.error || "Error al registrar adquisición. Inténtelo de nuevo.", true);
      }
    } catch (err) {
      console.error("Error de red al registrar adquisición:", err);
      window.showToast("Error de conexión al registrar adquisición.", true);
    }
  });

    if (manageSuppliersBtn) manageSuppliersBtn.addEventListener('click', window.openSupplierManagementModal);
    if (closeSupplierManagementModalBtn) {
      closeSupplierManagementModalBtn.addEventListener('click', () => {
          supplierManagementModal.classList.add('hidden');
          supplierManagementModal.classList.remove('flex');
      });
    }
    if (supplierForm) supplierForm.addEventListener('submit', handleSupplierFormSubmit);
    if (cancelSupplierEditBtn) cancelSupplierEditBtn.addEventListener('click', window.cancelSupplierEdit);


  // --- Carga inicial de datos al iniciar el módulo ---
  await loadSuppliersInternal();
  await loadAcquisitionsInternal();
  await loadCategoriesForNewProduct(); // Cargar categorías al inicio para el formulario de nuevo producto

  // Asegurarse de que los iconos Lucide se creen para toda la página
  if (window.lucide) {
    window.lucide.createIcons();
  }
};
