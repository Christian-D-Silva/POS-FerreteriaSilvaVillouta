// js/dashboard.js
window.initDashboard = async () => {
    console.log('Inicializando Dashboard...');

    const dailySalesElem = document.getElementById('daily-sales');
    const dailyTransactionsElem = document.getElementById('daily-transactions');
    const totalInventoryValueElem = document.getElementById('total-inventory-value');
    const lowStockCountElem = document.getElementById('low-stock-count');
    const lowStockProductsList = document.getElementById('low-stock-products-list');
    const salesChartCanvas = document.getElementById('sales-chart');

    if (!dailySalesElem || !dailyTransactionsElem || !totalInventoryValueElem || !lowStockCountElem || !lowStockProductsList || !salesChartCanvas) {
        console.error("Elementos del dashboard no encontrados. Asegúrate de que dashboard.html esté cargado correctamente.");
        return;
    }

    try {
        // Asegurarse de que los datos globales estén cargados
        if (!window.products || window.products.length === 0 || !window.salesHistory || window.salesHistory.length === 0) {
            await window.loadDataFromAPI(); // Recargar si los datos no están disponibles
        }

        // --- Calcular Métricas del Dashboard ---

        // Ventas de Hoy
        const today = new Date();
        today.setHours(0, 0, 0, 0); // Establecer a inicio del día

        let totalDailySales = 0;
        let dailyTransactions = 0;
        const salesByHour = new Array(24).fill(0); // Para el gráfico de ventas por hora

        // Asegurarse de que salesHistory contenga objetos de venta válidos
        window.salesHistory.forEach(sale => {
            if (sale && sale.sale_date) {
                const saleDate = new Date(sale.sale_date);
                saleDate.setHours(0, 0, 0, 0);

                if (saleDate.getTime() === today.getTime()) {
                    totalDailySales += parseFloat(sale.total_amount);
                    dailyTransactions++;
                    const hour = new Date(sale.sale_date).getHours();
                    salesByHour[hour]++;
                }
            }
        });

        dailySalesElem.textContent = window.formatCurrency(totalDailySales);
        dailyTransactionsElem.textContent = dailyTransactions;

        // Valor Total del Inventario
        let totalInventoryValue = 0;
        window.products.forEach(product => {
            totalInventoryValue += (parseFloat(product.price) * parseInt(product.stock));
        });
        totalInventoryValueElem.textContent = window.formatCurrency(totalInventoryValue);

        // Productos con Bajo Stock
        const lowStockProducts = window.products.filter(product => product.stock <= product.min_stock);
        lowStockCountElem.textContent = lowStockProducts.length;

        lowStockProductsList.innerHTML = ''; // Limpiar lista
        if (lowStockProducts.length > 0) {
            lowStockProducts.forEach(product => {
                const li = document.createElement('li');
                li.className = 'flex justify-between items-center py-2 border-b last:border-b-0';
                li.innerHTML = `
                    <span>${product.name} (SKU: ${product.sku})</span>
                    <span class="text-red-600 font-semibold">Stock: ${product.stock}</span>
                `;
                lowStockProductsList.appendChild(li);
            });
        } else {
            lowStockProductsList.innerHTML = '<li class="py-2 text-gray-500">No hay productos con bajo stock.</li>';
        }

        // --- Gráfico de Ventas (Chart.js) ---
        // Destruir la instancia anterior del gráfico si existe
        if (window.salesChartInstance) {
            window.salesChartInstance.destroy();
        }

        const ctx = salesChartCanvas.getContext('2d');
        window.salesChartInstance = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: Array.from({ length: 24 }, (_, i) => `${i}:00`), // Horas del día
                datasets: [{
                    label: 'Ventas por Hora',
                    data: salesByHour,
                    backgroundColor: 'rgba(75, 192, 192, 0.6)',
                    borderColor: 'rgba(75, 192, 192, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        title: {
                            display: true,
                            text: 'Número de Ventas'
                        }
                    },
                    x: {
                        title: {
                            display: true,
                            text: 'Hora del Día'
                        }
                    }
                },
                plugins: {
                    legend: {
                        display: false
                    },
                    title: {
                        display: true,
                        text: 'Ventas Realizadas Hoy por Hora'
                    }
                }
            }
        });

    } catch (error) {
        console.error('Error al inicializar dashboard:', error);
        window.showToast('Error al cargar datos del dashboard.', true);
    }
};

// Asegurar que Chart.js esté cargado
if (typeof Chart === 'undefined') {
    const script = document.createElement('script');
    script.src = 'https://cdn.jsdelivr.net/npm/chart.js';
    script.onload = () => {
        // Si ya estamos en la página del dashboard y los datos están cargados, inicializar
        if (document.getElementById('dashboard-page-container')) { // Identificador único para dashboard.html
             // Solo si currentUser está presente (estamos loggeados), inicializamos el dashboard
            if (window.currentUser) {
                window.initDashboard();
            }
        }
    };
    document.head.appendChild(script);
} else {
    // Si Chart.js ya está cargado, inicializar si estamos en la página del dashboard
    if (document.getElementById('dashboard-page-container')) { // Identificador único para dashboard.html
        if (window.currentUser) { // Solo si currentUser está presente
            window.initDashboard();
        }
    }
}