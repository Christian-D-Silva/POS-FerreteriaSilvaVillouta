// js/ventas.js

// Variables globales para el estado de ventas que se mantienen fuera de initVentas
// porque otras funciones globales (como searchProducts, addProductToCart, renderCart, etc.)
// también las necesitan y se definen en este archivo.
window.cart = [];
let discountAmount = 0; // Ahora es un monto fijo, no un porcentaje
let selectedClient = null; // Para almacenar el cliente seleccionado en caso de factura


// --- FUNCIONES ESPECÍFICAS DE VENTAS ---

// Función para buscar productos (ahora es global para ser accesible)
window.searchProducts = async (query) => {
    // Estas variables DOM no pueden ser accedidas directamente si se declaran en initVentas
    // La mejor práctica sería pasarlas como argumentos o re-obtenerlas si es estrictamente necesario,
    // pero si initVentas ya las asignó, y estas funciones también las necesitan, se podrían
    // pasar o si son pocas, re-obtener (menos eficiente).
    // Otra opción es que initVentas devuelva un objeto con todas las referencias DOM.
    // Por ahora, las funciones globales que interactúen con el DOM tendrán que obtener sus propias referencias si no están en initVentas.
    const productSearchResults = document.getElementById('product-search-results');

    if (query.length < 2) { // Buscar solo si hay al menos 2 caracteres
        if (productSearchResults) {
            productSearchResults.innerHTML = '';
            productSearchResults.classList.add('hidden');
        }
        return;
    }

    try {
        const response = await fetch(`api/products.php?action=list&search=${query}`);
        const products = await response.json();

        if (productSearchResults) {
            productSearchResults.innerHTML = ''; // Limpiar resultados anteriores
            if (products.length > 0) {
                products.forEach(product => {
                    const productItem = document.createElement('div');
                    productItem.classList.add('p-2', 'cursor-pointer', 'hover:bg-gray-100', 'border-b', 'last:border-b-0');
                    productItem.innerHTML = `
                        <p class="font-semibold">${product.name} (SKU: ${product.sku})</p>
                        <p class="text-sm text-gray-600">Stock: ${product.stock} | Precio: ${window.formatCurrency(product.price)}</p>
                    `;
                    productItem.addEventListener('click', () => {
                        window.addProductToCart(product);
                        productSearchResults.classList.add('hidden'); // Ocultar resultados al seleccionar
                        document.getElementById('product-search-input').value = ''; // Limpiar input de búsqueda
                    });
                    productSearchResults.appendChild(productItem);
                });
                productSearchResults.classList.remove('hidden');
            } else {
                productSearchResults.innerHTML = '<div class="p-2 text-gray-500">No se encontraron productos.</div>';
                productSearchResults.classList.remove('hidden');
            }
        }
    } catch (error) {
        console.error('Error al buscar productos:', error);
        window.showToast('Error al buscar productos.', true);
    }
};

// Función para añadir producto al carrito
window.addProductToCart = (product) => {
    if (product.stock <= 0) {
        window.showToast(`El producto "${product.name}" no tiene stock disponible.`, true);
        return;
    }

    const existingItem = window.cart.find(item => item.id === product.id);

    if (existingItem) {
        if (existingItem.quantity < product.stock) {
            existingItem.quantity++;
            existingItem.subtotal = existingItem.quantity * existingItem.price;
        } else {
            window.showToast(`No hay más stock disponible para "${product.name}".`, true);
            return;
        }
    } else {
        // Asegurarse de que el precio sea numérico
        const price = parseFloat(product.price);
        if (isNaN(price)) {
            console.error('Precio del producto no es un número válido:', product.price);
            window.showToast('Error: El precio del producto no es válido.', true);
            return;
        }
        window.cart.push({
            id: product.id,
            name: product.name,
            sku: product.sku,
            price: price, // Usar el precio convertido
            quantity: 1,
            stock: product.stock,
            subtotal: price // Subtotal inicial
        });
    }
    window.renderCart();
    window.showToast(`"${product.name}" añadido al carrito.`);
};

// Función para eliminar producto del carrito
window.removeProductFromCart = (productId) => {
    window.cart = window.cart.filter(item => item.id !== productId);
    window.renderCart();
    window.showToast('Producto eliminado del carrito.');
};

// Función para actualizar cantidad del producto en el carrito
window.updateCartQuantity = (productId, newQuantity) => {
    const item = window.cart.find(item => item.id === productId);
    if (item) {
        const quantity = parseInt(newQuantity);
        if (isNaN(quantity) || quantity <= 0) {
            window.showToast('La cantidad debe ser un número positivo.', true);
            window.renderCart(); // Volver a renderizar para corregir la entrada si es inválida
            return;
        }
        if (quantity > item.stock) {
            window.showToast(`No hay suficiente stock para "${item.name}". Stock disponible: ${item.stock}`, true);
            item.quantity = item.stock; // Ajustar a la cantidad máxima disponible
        } else {
            item.quantity = quantity;
        }
        item.subtotal = item.quantity * item.price;
        window.renderCart();
    }
};

// Función para renderizar el carrito
window.renderCart = () => {
    const cartTableBody = document.getElementById('cart-table-body');
    const cartTotalElem = document.getElementById('cart-total');
    // const productCountSpan = document.getElementById('product-count-span'); // Se usará si lo tienes en el HTML para el contador de items

    if (!cartTableBody || !cartTotalElem) {
        console.error('Elementos del DOM del carrito no encontrados. `ventas.html` no cargado correctamente.');
        // Esto puede ocurrir si renderCart es llamado antes de que el HTML del módulo esté en el DOM
        return;
    }

    cartTableBody.innerHTML = '';
    let total = 0;

    if (window.cart.length === 0) {
        cartTableBody.innerHTML = `
            <tr>
                <td colspan="5" class="py-4 text-center text-gray-500">El carrito está vacío.</td>
            </tr>
        `;
    } else {
        window.cart.forEach(item => {
            const row = document.createElement('tr');
            row.classList.add('border-b', 'border-gray-200', 'hover:bg-gray-100');
            row.innerHTML = `
                <td class="py-3 px-6 text-left">${item.name}<br><span class="text-xs text-gray-500">SKU: ${item.sku}</span></td>
                <td class="py-3 px-6 text-center">
                    <input type="number" value="${item.quantity}" min="1" max="${item.stock}"
                           class="w-20 p-1 border rounded text-center"
                           onchange="window.updateCartQuantity(${item.id}, this.value)">
                </td>
                <td class="py-3 px-6 text-right">${window.formatCurrency(item.price)}</td>
                <td class="py-3 px-6 text-right">${window.formatCurrency(item.subtotal)}</td>
                <td class="py-3 px-6 text-center">
                    <button onclick="window.removeProductFromCart(${item.id})"
                            class="text-red-500 hover:text-red-700 transition-colors" title="Eliminar">
                        <span data-lucide="trash-2" class="w-5 h-5"></span>
                    </button>
                </td>
            `;
            cartTableBody.appendChild(row);
            total += item.subtotal;
        });
    }

    // Aplicar descuento si existe
    let finalTotal = total - discountAmount;
    if (finalTotal < 0) finalTotal = 0; // Asegurarse de que el total no sea negativo

    cartTotalElem.textContent = window.formatCurrency(finalTotal);

    // if (productCountSpan) {
    //     productCountSpan.textContent = window.cart.length; // Actualizar el contador de productos en el carrito
    // }

    // Re-renderizar iconos Lucide para los botones dentro de la tabla
    if (window.lucide) {
        window.lucide.createIcons();
    }
};

// Función para vaciar el carrito
window.clearCart = () => {
    if (window.cart.length === 0) {
        window.showToast('El carrito ya está vacío.', false);
        return;
    }
    if (confirm('¿Estás seguro de que quieres vaciar el carrito?')) {
        window.cart = [];
        discountAmount = 0; // Resetear descuento al vaciar carrito
        window.renderCart();
        window.showToast('Carrito vaciado.');
    }
};

// Función para abrir modal de descuento
window.openDiscountModal = () => {
    const discountModal = document.getElementById('discount-modal');
    const discountInput = document.getElementById('discount-input');
    if (discountModal && discountInput) {
        discountInput.value = discountAmount; // Mostrar el descuento actual
        discountModal.classList.remove('hidden');
    }
};

// Función para aplicar descuento
window.applyDiscount = () => {
    const discountInput = document.getElementById('discount-input');
    const discountModal = document.getElementById('discount-modal');

    if (discountInput && discountModal) {
        let inputVal = parseFloat(discountInput.value);

        if (isNaN(inputVal) || inputVal < 0) {
            window.showToast('El monto del descuento debe ser un número positivo.', true);
            return;
        }

        // Calcular el total actual sin descuento
        const currentCartTotal = window.cart.reduce((sum, item) => sum + item.subtotal, 0);

        if (inputVal > currentCartTotal) {
            window.showToast(`El descuento no puede ser mayor que el total del carrito (${window.formatCurrency(currentCartTotal)}).`, true);
            discountInput.value = currentCartTotal; // Ajustar al máximo permitido
            return;
        }

        discountAmount = inputVal;
        window.renderCart();
        discountModal.classList.add('hidden');
        window.showToast('Descuento aplicado correctamente.');
    }
};

// Función para cancelar el descuento
window.cancelDiscount = () => {
    const discountModal = document.getElementById('discount-modal');
    if (discountModal) {
        discountModal.classList.add('hidden');
    }
};

// Función para buscar clientes (para el campo de factura)
window.searchClients = async (query) => {
    const clientSearchResults = document.getElementById('client-search-results');
    if (query.length < 2) {
        if (clientSearchResults) {
            clientSearchResults.innerHTML = '';
            clientSearchResults.classList.add('hidden');
        }
        return;
    }
    try {
        const response = await fetch(`api/clients.php?action=search&query=${query}`);
        const clients = await response.json();

        if (clientSearchResults) {
            clientSearchResults.innerHTML = '';
            if (clients.length > 0) {
                clients.forEach(client => {
                    const clientItem = document.createElement('div');
                    clientItem.classList.add('p-2', 'cursor-pointer', 'hover:bg-gray-100', 'border-b', 'last:border-b-0');
                    clientItem.innerHTML = `<p class="font-semibold">${client.razon_social}</p><p class="text-sm text-gray-600">RUT: ${client.rut}</p>`;
                    clientItem.addEventListener('click', () => {
                        selectedClient = client;
                        document.getElementById('selected-client-display').textContent = `Cliente seleccionado: ${client.razon_social} (${client.rut})`;
                        document.getElementById('clear-client-selection-btn').classList.remove('hidden');
                        clientSearchResults.classList.add('hidden');
                        document.getElementById('client-search-input').value = ''; // Limpiar el input de búsqueda
                    });
                    clientSearchResults.appendChild(clientItem);
                });
                clientSearchResults.classList.remove('hidden');
            } else {
                clientSearchResults.innerHTML = '<div class="p-2 text-gray-500">No se encontraron clientes.</div>';
                clientSearchResults.classList.remove('hidden');
            }
        }
    } catch (error) {
        console.error('Error al buscar clientes:', error);
        window.showToast('Error al buscar clientes.', true);
    }
};


// Función para completar la venta
window.completeSale = async () => {

    if (window.cart.length === 0) {
        window.showToast('El carrito está vacío. Añade productos para completar la venta.', true);
        return;
    }

    
    const saleType = document.getElementById('sale-type-select').value;

    if (saleType === 'Factura' && !selectedClient) {
        window.showToast('Para una factura, debes seleccionar un cliente.', true);
        return;
    }

    // Calcular el total final, incluyendo el descuento
    let totalAmount = window.cart.reduce((sum, item) => sum + item.subtotal, 0);
    totalAmount -= discountAmount;
    if (totalAmount < 0) totalAmount = 0;
    const subtotal = window.cart.reduce((acc, item) => acc + item.subtotal, 0);

    const saleData = {
        user_id: window.currentUser ? window.currentUser.id : null, // Asume que currentUser tiene el ID
        client_id: selectedClient ? selectedClient.id : null,
        sale_type: saleType,
        subtotal_amount: subtotal,
        total_amount: totalAmount,
        discount_amount: discountAmount,
        tax_amount: 0,
        

        items: window.cart.map(item => ({
            product_id: item.id,
            quantity: item.quantity,
            price_at_sale: item.price,
            subtotal: item.subtotal
        }))
    };

    try {
        const response = await fetch('api/sales.php?action=create', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(saleData)
        });

        const result = await response.json();

        if (result.success) {
            window.showToast('Venta completada exitosamente.');
            window.cart = []; // Vaciar carrito después de la venta
            discountAmount = 0; // Resetear descuento
            selectedClient = null; // Resetear cliente
            window.renderCart(); // Actualizar la interfaz del carrito
            await window.loadDataFromAPI(); // Recargar datos globales (especialmente historial de ventas y stock)
            // Opcional: Navegar a historial de ventas o mostrar confirmación
            // window.switchPage('historial');
        } else {
            window.showToast(`Error al completar la venta: ${result.error}`, true);
        }
    } catch (error) {
        console.error('Error al enviar la venta:', error);
        window.showToast('Error de conexión al completar la venta.', true);
    }
};


// Función de inicialización principal para el módulo de Ventas
window.initVentas = async () => {
    console.log('Inicializando Módulo de Ventas...');

    // Usamos requestAnimationFrame para asegurar que el DOM esté completamente renderizado
    // antes de intentar obtener los elementos.
    requestAnimationFrame(async () => {
        // 1. Obtener todas las referencias a los elementos DOM localmente dentro de initVentas
        const productSearchInput = document.getElementById('product-search-input');
        const productSearchResults = document.getElementById('product-search-results');
        const cartTableBody = document.getElementById('cart-table-body');
        const cartTotalElem = document.getElementById('cart-total');
        const completeSaleBtn = document.getElementById('complete-sale-btn');
        const discountBtn = document.getElementById('discount-btn');
        const clearCartBtn = document.getElementById('clear-cart-btn');
        const applyDiscountBtn = document.getElementById('apply-discount-btn');
        const cancelDiscountBtn = document.getElementById('cancel-discount-btn');
        const discountInput = document.getElementById('discount-input');
        const discountModal = document.getElementById('discount-modal');
        // const productCountSpan = document.getElementById('product-count-span'); // Comentado si no está en el HTML
        const productCategoryFilter = document.getElementById('product-category-filter-sales'); // Nuevo para filtrar en ventas
        const productListForSales = document.getElementById('product-list-for-sales'); // Contenedor para productos en el grid/lista

        // Nuevos elementos para la gestión de clientes en ventas
        const clientSearchInput = document.getElementById('client-search-input');
        const clientSearchResults = document.getElementById('client-search-results');
        const selectedClientDisplay = document.getElementById('selected-client-display');
        const clearClientSelectionBtn = document.getElementById('clear-client-selection-btn');
        
        const saleTypeSelect = document.getElementById('sale-type-select');


        // Validar que los elementos esenciales existan
        if (!productSearchInput || !cartTableBody || !cartTotalElem || !completeSaleBtn || !clientSearchInput || !saleTypeSelect) {
            console.error('Elementos del DOM del carrito no encontrados. `ventas.html` no cargado correctamente.');
            window.showToast('Error: No se cargó la interfaz de ventas correctamente.', true);
            return;
        }

        // --- ASIGNACIONES DE FUNCIONES AL OBJETO WINDOW (ya están arriba, aquí solo se reafirman) ---
        // Estas funciones ya están definidas globalmente o en el scope de window,
        // por lo que no es necesario re-declararlas aquí. Solo se hace la asignación
        // si se definieran localmente para el módulo y se quisieran exponer.
        // Por ejemplo: window.renderCart = renderCart;
        // Pero como ya son window.renderCart, etc., no es necesario.

        // --- CONFIGURACIÓN DE EVENT LISTENERS ---

        // Búsqueda de productos
        if (productSearchInput) {
            productSearchInput.addEventListener('input', (e) => window.searchProducts(e.target.value));
            productSearchInput.addEventListener('focus', (e) => {
                if (e.target.value.length >= 2) window.searchProducts(e.target.value);
            });
            productSearchInput.addEventListener('blur', () => {
                setTimeout(() => {
                    if (productSearchResults) productSearchResults.classList.add('hidden');
                }, 200); // Pequeño retraso para permitir clicks en resultados
            });
        }

        // Botones del carrito
        if (clearCartBtn) {
            clearCartBtn.addEventListener('click', window.clearCart);
        }
        if (discountBtn) {
            discountBtn.addEventListener('click', window.openDiscountModal);
        }
        if (applyDiscountBtn) {
            applyDiscountBtn.addEventListener('click', window.applyDiscount);
        }
        if (cancelDiscountBtn) {
            cancelDiscountBtn.addEventListener('click', window.cancelDiscount);
        }
        if (completeSaleBtn) {
            completeSaleBtn.addEventListener('click', window.completeSale);
        }

        // Búsqueda de clientes
        if (clientSearchInput) {
            clientSearchInput.addEventListener('input', (e) => window.searchClients(e.target.value));
            clientSearchInput.addEventListener('focus', (e) => {
                if (e.target.value.length >= 2) window.searchClients(e.target.value); // Búsqueda con al menos 2 caracteres
            });
            clientSearchInput.addEventListener('blur', () => {
                setTimeout(() => {
                    if (clientSearchResults) clientSearchResults.classList.add('hidden');
                }, 200);
            });
        }

        // Event listener para limpiar selección de cliente
        if (clearClientSelectionBtn) {
            clearClientSelectionBtn.addEventListener('click', () => {
                selectedClient = null;
                if (selectedClientDisplay) selectedClientDisplay.textContent = '';
                if (clearClientSelectionBtn) clearClientSelectionBtn.classList.add('hidden');
                if (clientSearchInput) clientSearchInput.value = '';
                if (clientSearchResults) clientSearchResults.classList.add('hidden'); // Ocultar resultados al limpiar
            });
        }

        // Asegurarse de que el modal de descuento esté oculto al iniciar
        if (discountModal) {
            discountModal.classList.add('hidden');
        }

        // Renderizar carrito inicial (vacío)
        window.renderCart();

        // Actualizar iconos Lucide para esta sección
        if (window.lucide) {
            window.lucide.createIcons();
        }
    });
};