<?php
// hash_password.php
require_once __DIR__ . '/db_connection.php'; // Ajusta la ruta si es necesario

// Contraseña que quieres usar (¡asegúrate de que sea EXACTAMENTE 'password123' sin espacios ni errores!)
$plain_password = 'password123';
$username_to_update = 'admin';

// Generar el nuevo hash
$new_password_hash = password_hash($plain_password, PASSWORD_BCRYPT);

if ($new_password_hash === false) {
    die("Error al hashear la contraseña. Verifica la configuración de PHP.");
}

try {
    $pdo = get_db_connection();
    $stmt = $pdo->prepare("UPDATE users SET password_hash = ? WHERE username = ?");
    $stmt->execute([$new_password_hash, $username_to_update]);

    if ($stmt->rowCount() > 0) {
        echo "Contraseña para el usuario '" . $username_to_update . "' actualizada con éxito.<br>";
        echo "Nuevo hash: " . $new_password_hash . "<br>";
        echo "Intenta iniciar sesión con: Usuario = '" . $username_to_update . "', Contraseña = '" . $plain_password . "'<br>";
    } else {
        echo "Usuario '" . $username_to_update . "' no encontrado o contraseña ya era la misma.<br>";
    }
} catch (PDOException $e) {
    die("Error de base de datos: " . $e->getMessage());
}
?>