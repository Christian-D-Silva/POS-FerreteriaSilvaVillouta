// js/main.js

document.addEventListener('DOMContentLoaded', () => {
    // Inicialización de iconos Lucide al cargar el DOM
    // Esto asegura que todos los iconos en el HTML inicial se rendericen.
    if (window.lucide) {
        window.lucide.createIcons();
    }

    // --- DATOS GLOBALES (Ahora se cargarán desde la DB, pero se mantienen como "cache" local) ---
    // Inicializar como arrays vacíos
    window.categories = [];
    window.products = [];
    window.salesHistory = []; // Esto se cargará desde la DB
    window.clients = []; // Nuevo para clientes
    window.cart = []; // El carrito sigue siendo local al usuario
    window.currentUser = null; // Información del usuario loggeado
    window.users = []; // Para la gestión de usuarios
    window.roles = []; // Para los roles de usuario

    // Referencias a elementos DOM que podrían existir globalmente en index.html
    const loginPage = document.getElementById('login-page');
    const mainApp = document.getElementById('main-app');
    const loginForm = document.getElementById('login-form');
    const logoutBtn = document.getElementById('logout-btn');
    const mainContentArea = document.getElementById('main-content-area');
    const sidebarNav = document.getElementById('sidebar-nav');
    const currentUserSpan = document.getElementById('current-user-info'); // Para mostrar el usuario loggeado
    const loginErrorMessage = document.getElementById('login-error-message'); // Mensaje de error en el login
    const toast = document.getElementById('toast');
    const toastMessage = document.getElementById('toast-message');

    // Objeto para llevar un registro de los scripts de módulo ya cargados
    const loadedScripts = {};

    // --- FUNCIONES GLOBALES PRINCIPALES ---

    // Función para mostrar mensajes toast
    window.showToast = (message, isError = false) => {
        toastMessage.textContent = message;
        toast.classList.remove('hidden');
        if (isError) {
            toast.classList.remove('bg-green-500');
            toast.classList.add('bg-red-600');
        } else {
            toast.classList.remove('bg-red-600');
            toast.classList.add('bg-green-500');
        }
        setTimeout(() => {
            toast.classList.add('hidden');
        }, 3000);
    };

    // Función para formatear moneda (ej. para Chile)
    window.formatCurrency = (amount) => {
        return new Intl.NumberFormat('es-CL', {
            style: 'currency',
            currency: 'CLP',
            minimumFractionDigits: 0
        }).format(amount);
    };

    // Función para mostrar la página de login
    window.showLoginPage = () => {
        if (mainApp) mainApp.classList.add('hidden');
        if (loginPage) loginPage.classList.remove('hidden');
    };

    // Función para mostrar la aplicación principal
    window.showMainApp = () => {
        if (loginPage) loginPage.classList.add('hidden');
        if (mainApp) mainApp.classList.remove('hidden');
        setupNavigation(); // Configurar los event listeners del menú
        if (window.lucide) { // Volver a crear iconos para el menú (si se generan dinámicamente o si los estados cambian)
            window.lucide.createIcons();
        }
    };

    // Función para configurar los event listeners de navegación
    function setupNavigation() {
        if (sidebarNav) {
            // Eliminar listeners previos para evitar duplicados si se llama varias veces
            sidebarNav.querySelectorAll('button[data-page]').forEach(button => {
                button.removeEventListener('click', handleNavLinkClick);
                button.addEventListener('click', handleNavLinkClick);
            });
        }
    }

    // Manejador de clic para los enlaces de navegación
    async function handleNavLinkClick(event) {
        event.preventDefault(); // Evita la navegación por defecto
        const page = event.target.closest('button').dataset.page; // Obtiene el valor de data-page del botón
        if (page) {
            console.log(`Navegando a: ${page}`); // LOG para depuración
            await window.switchPage(page);
        }
    }

    // Función para cargar datos iniciales de la API
    window.loadDataFromAPI = async () => {
        console.log("Cargando datos iniciales de la API...");
        try {
            const [productsRes, categoriesRes, salesRes, clientsRes, usersRes, rolesRes] = await Promise.all([
                fetch('api/products.php?action=list'),
                fetch('api/products.php?action=list_categories'),
                fetch('api/sales.php?action=list'), // Asumiendo que esto obtiene el historial de ventas
                fetch('api/clients.php?action=list'),
                fetch('api/users.php?action=list'),
                fetch('api/roles.php?action=list') // Correcto
            ]);

            window.products = await productsRes.json();
            window.categories = await categoriesRes.json();
            window.salesHistory = await salesRes.json();
            window.clients = await clientsRes.json();
            window.users = await usersRes.json();
            window.roles = await rolesRes.json();

            console.log('Datos iniciales cargados:', {
                products: window.products.length,
                categories: window.categories.length,
                salesHistory: window.salesHistory.length,
                clients: window.clients.length,
                users: window.users.length,
                roles: window.roles.length
            });

        } catch (error) {
            console.error('Error al cargar datos iniciales de la API:', error);
            window.showToast('Error al cargar datos esenciales. Detalles en consola.', true);
        }
    };

    // Función para cambiar de página y cargar el contenido del módulo
    window.switchPage = async (page) => {
        try {
            // 1. Cargar el HTML del módulo
            const htmlResponse = await fetch(`pages/${page}.html`);
            if (!htmlResponse.ok) {
                // Si la página HTML no se encuentra, muestra un error
                throw new Error(`No se pudo cargar la página pages/${page}.html: ${htmlResponse.status} - ${htmlResponse.statusText}`);
            }
            const html = await htmlResponse.text();
            mainContentArea.innerHTML = html;
            console.log(`Contenido de pages/${page}.html cargado.`);

            // 2. Cargar el script JS del módulo, si no ha sido cargado ya
            // Mapeo de nombres de data-page a nombres de archivo JS y funciones de inicialización
            const moduleMap = {
                'dashboard': { script: 'dashboard.js', initFunc: 'initDashboard' },
                'products': { script: 'productos.js', initFunc: 'initProductos' }, // data-page 'products' -> productos.js -> initProductos()
                'clients': { script: 'clients.js', initFunc: 'initClientes' },   // data-page 'clients' -> clients.js -> initClientes()
                'sales': { script: 'ventas.js', initFunc: 'initVentas' },       // data-page 'sales' -> ventas.js -> initVentas()
                'historial': { script: 'historial.js', initFunc: 'initHistorial' },
                'users': { script: 'users.js', initFunc: 'initUsers' } // Asumiendo que tienes un users.js
            };

            const moduleInfo = moduleMap[page];

            if (!moduleInfo) {
                console.warn(`No hay información de módulo para la página: ${page}`);
                window.showToast(`Módulo "${page}" no configurado.`, true);
                return;
            }

            const scriptPath = `js/${moduleInfo.script}`;
            let scriptLoadedPromise;

            if (!loadedScripts[scriptPath]) {
                console.log(`Cargando script dinámicamente: ${scriptPath}`);
                scriptLoadedPromise = new Promise((resolve, reject) => {
                    const script = document.createElement('script');
                    script.src = scriptPath;
                    script.onload = () => {
                        console.log(`Script ${scriptPath} cargado exitosamente.`);
                        loadedScripts[scriptPath] = true; // Marcar como cargado
                        resolve();
                    };
                    script.onerror = (e) => {
                        console.error(`Error al cargar el script ${scriptPath}:`, e);
                        window.showToast(`Error al cargar el script del módulo ${page}.`, true);
                        reject(e);
                    };
                    document.body.appendChild(script); // Añadir al body para que se ejecute
                });
                await scriptLoadedPromise; // Esperar a que el script se cargue
            } else {
                console.log(`Script ${scriptPath} ya cargado.`);
            }

            // 3. Llamar a la función de inicialización del módulo
            const initFunctionName = moduleInfo.initFunc;
            if (window[initFunctionName] && typeof window[initFunctionName] === 'function') {
                console.log(`Llamando a ${initFunctionName} para la página ${page}...`);
                await window[initFunctionName](); // Llama a la función de inicialización del módulo
            } else {
                console.warn(`No se encontró la función de inicialización '${initFunctionName}' o no es una función para la página: ${page}`);
                window.showToast(`Advertencia: No se encontró la función de inicialización para el módulo ${page}.`, false);
            }

            // Actualizar iconos Lucide para el nuevo contenido cargado
            if (window.lucide) {
                window.lucide.createIcons();
            }

        } catch (error) {
            console.error(`Error al cargar la página ${page}:`, error);
            window.showToast(`Error al cargar la página ${page}: ${error.message}`, true);
        }
    };

    // --- MANEJO DEL LOGIN ---
    loginForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        // Asegurarse de que el mensaje de error esté oculto al intentar un nuevo login
        if (loginErrorMessage) {
            loginErrorMessage.classList.add('hidden');
            loginErrorMessage.textContent = '';
        }

        const username = document.getElementById('username').value; // Usar getElementById para consistencia
        const password = document.getElementById('password').value; // Usar getElementById para consistencia

        try {
            const response = await fetch('api/auth.php?action=login', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ username, password })
            });

            const data = await response.json();

            // **CORRECCIÓN AQUÍ: Verificar response.ok y data.logged_in**
            if (response.ok && data.logged_in) {
                window.currentUser = data.user;
                // Asegurarse de que currentUserSpan existe antes de usarlo
                const currentUserSpan = document.getElementById('current-user-info');
                if (currentUserSpan) currentUserSpan.textContent = `Bienvenido, ${window.currentUser.full_name || window.currentUser.username} (${window.currentUser.role_name || window.currentUser.role})`;

                window.showToast(data.message || '¡Inicio de sesión exitoso!');
                window.showMainApp(); // Mostrar la aplicación principal
                await window.loadDataFromAPI(); // Cargar datos iniciales después del login
                window.switchPage('dashboard'); // Cargar dashboard por defecto después del login
            } else {
                // Mostrar mensaje de error del backend o uno genérico
                if (loginErrorMessage) {
                    loginErrorMessage.textContent = data.error || 'Credenciales incorrectas. Verifique su usuario y contraseña.';
                    loginErrorMessage.classList.remove('hidden');
                } else {
                    window.showToast(data.error || 'Inicio de sesión fallido.', true);
                }
            }
        } catch (error) {
            console.error('Error en el fetch de login:', error);
            if (loginErrorMessage) {
                loginErrorMessage.textContent = 'Error de conexión. Inténtelo de nuevo.';
                loginErrorMessage.classList.remove('hidden');
            } else {
                window.showToast('Error de conexión al iniciar sesión.', true);
            }
        }
    });

    // --- MANEJO DEL LOGOUT ---
    // --- MANEJO DEL LOGOUT ---
// Asegurarse de que 'logoutBtn' esté declarado y referenciado ANTES de este bloque.

    logoutBtn.addEventListener('click', async () => {
        try {
            const response = await fetch('api/auth.php?action=logout', {
                method: 'POST'
            });
            const data = await response.json();

            // **CORRECCIÓN AQUÍ: Verificar response.ok**
            // auth.php devuelve 200 OK y un mensaje. No necesita `data.success`
            if (response.ok) {
                window.currentUser = null;
                window.categories = [];
                window.products = [];
                window.salesHistory = [];
                window.clients = [];
                window.cart = [];
                window.users = [];
                window.roles = [];

                window.showToast(data.message || 'Sesión cerrada exitosamente.');

                window.location.href = '/'; // O la URL de tu index.html, e.g., '/index.html'

            } else {
                // Manejar errores si el servidor no responde con 200 OK
                window.showToast(data.error || 'Error al cerrar sesión.', true);
            }
        } catch (error) {
            console.error('Error al cerrar sesión:', error);
            window.showToast('Error de conexión al cerrar sesión.', true);
        }
    });

    // --- VERIFICACIÓN DE ESTADO DE LOGIN AL CARGAR LA PÁGINA ---
    window.checkLoginStatus = async () => {
        try {
            const response = await fetch('api/auth.php?action=status'); // Endpoint correcto

            const data = await response.json();

            // **CORRECCIÓN AQUÍ: Usar data.authenticated**
            // También podemos verificar response.ok para mayor robustez
            if (response.ok && data.authenticated) { // Verifica HTTP 200 y que el backend confirme autenticación

                window.currentUser = {
                    id: data.user_id, // Si tu API devuelve user_id
                    username: data.username,
                    role: data.role // El nombre del rol o ID, según lo que devuelva tu auth.php
                    // full_name y role_name NO vienen de la acción 'status' en auth.php,
                    // por lo que deben ser 'null' o 'undefined' a menos que ajustes tu auth.php
                    // para devolverlos.
                };

                const currentUserSpan = document.getElementById('current-user-info'); // Asegúrate de que esta variable está declarada
                if (currentUserSpan) {
                    currentUserSpan.textContent = `Bienvenido, ${data.username || 'Usuario'} (${data.role || 'Rol Desconocido'})`;
                }

                window.showMainApp(); // Mostrar la app si ya está loggeado
                await window.loadDataFromAPI(); // Cargar datos iniciales
                window.switchPage('dashboard'); // Cargar dashboard por defecto
            } else {
                // Si response.ok es false (ej. 401), o data.authenticated es false, mostrar login.
                window.showLoginPage(); // Mostrar login si no está loggeado
            }
        } catch (error) {
            console.error('Error de red o parseo JSON al verificar estado de login:', error);
            // Mostrar un mensaje de tostada genérico para errores de red
            window.showToast('No se pudo verificar la sesión. Intente recargar.', true);
            window.showLoginPage(); // Por seguridad, mostrar login en caso de error
        }
    };

    // Ejecutar la verificación de login al cargar el DOM
    window.checkLoginStatus();
});