// Referencias a elementos del DOM
const reportStartDateInput = document.getElementById('report-start-date');
const reportEndDateInput = document.getElementById('report-end-date');
const reportSellerFilter = document.getElementById('report-seller-filter');
const generateReportBtn = document.getElementById('generate-report-btn');
const reportResultsDiv = document.getElementById('report-results');
const reportTotalSales = document.getElementById('report-total-sales');
const reportTotalBoletas = document.getElementById('report-total-boletas');
const reportTotalFacturas = document.getElementById('report-total-facturas');
const reportSellerName = document.getElementById('report-seller-name');
const reportSalesDetailBody = document.getElementById('report-sales-detail-body');

// Variable global para almacenar todos los usuarios (vendedores)
window.allUsers = [];

// --- Funciones ---
window.populateSellersFilter = async () => {
    if (!reportSellerFilter) return;

    try {
        const response = await fetch('api/users.php?action=list'); // Necesitaremos un endpoint para listar usuarios
        if (!response.ok) throw new Error('Error al cargar vendedores.');
        window.allUsers = await response.json();

        reportSellerFilter.innerHTML = '<option value="all">Todos los Vendedores</option>';
        window.allUsers.forEach(user => {
            const option = document.createElement('option');
            option.value = user.id;
            option.textContent = user.full_name;
            reportSellerFilter.appendChild(option);
        });
    } catch (error) {
        console.error('Error al poblar filtro de vendedores:', error);
        window.showToast(`Error al cargar vendedores: ${error.message}`, true);
    }
};

window.generateSalesReport = async () => {
    const startDate = reportStartDateInput.value;
    const endDate = reportEndDateInput.value;
    const sellerId = reportSellerFilter.value;

    if (!startDate || !endDate) {
        window.showToast('Por favor, seleccione un rango de fechas para el reporte.', true);
        return;
    }

    if (new Date(startDate) > new Date(endDate)) {
        window.showToast('La fecha de inicio no puede ser posterior a la fecha de fin.', true);
        return;
    }

    try {
        let url = `api/reports.php?start_date=<span class="math-inline">\{startDate\}&end\_date\=</span>{endDate}`;
        if (sellerId !== 'all') {
            url += `&user_id=${sellerId}`;
        }

        const response = await fetch(url);
        if (!response.ok) {
            const errorData = await response.json();
            throw new Error(errorData.error || 'Error al generar el reporte.');
        }

        const reportData = await response.json();
        console.log('Datos de reporte:', reportData);

        // Mostrar resultados
        reportResultsDiv.classList.remove('hidden');
        reportTotalSales.textContent = window.formatCurrency(reportData.total_sales || 0);
        reportTotalBoletas.textContent = reportData.boleta_count || 0;
        reportTotalFacturas.textContent = reportData.factura_count || 0;

        const selectedSellerName = reportSellerFilter.value === 'all' 
                                   ? 'Todos' 
                                   : (window.allUsers.find(u => u.id == reportSellerFilter.value)?.full_name || 'Desconocido');
        reportSellerName.textContent = selectedSellerName;

        // Llenar tabla de detalles de ventas
        reportSalesDetailBody.innerHTML = '';
        if (reportData.sales_details && reportData.sales_details.length > 0) {
            reportData.sales_details.forEach(sale => {
                const row = reportSalesDetailBody.insertRow();
                const saleDate = new Date(sale.sale_date);
                const clientName = sale.client_name || 'N/A';
                const sellerName = sale.user_name || 'N/A'; // Ya viene con el nombre del usuario

                row.innerHTML = `
                    <td class="p-3"><span class="math-inline">\{sale\.id\}</td\>
<td class="p-3">{saleDate.toLocaleDateString('es-CL')} saleDate.toLocaleTimeString( 
′
 es−CL 
′
 ,hour: 
′
 2−digit 
′
 ,minute: 
′
 2−digit 
′
 )</td><tdclass="p−3">{sale.document_type}</td>
<td class="p-3">clientName</td><tdclass="p−3">{sellerName}</td>
<td class="p-3">${window.formatCurrency(sale.total_amount)}</td>
`;
});
} else {
reportSalesDetailBody.innerHTML = '<tr><td colspan="6" class="p-4 text-center text-gray-500">No hay ventas en este período o con este filtro.</td></tr>';
}

        window.showToast('Reporte generado exitosamente.');

    } catch (error) {
        console.error('Error al generar reporte:', error);
        window.showToast(`Error al generar reporte: ${error.message}`, true);
    }
};

// --- Inicialización de la página de Reportes ---
window.initReportsPage = async () => {
    // Asegurarse de que los elementos existan
    if (!reportStartDateInput || !reportEndDateInput || !reportSellerFilter || !generateReportBtn) {
        console.warn('Algunos elementos de la página de reportes no se encontraron en el DOM.');
        return;
    }

    // Poblar el filtro de vendedores
    await window.populateSellersFilter();

    // Event Listeners
    if (!generateReportBtn._hasClickListener) { // Prevenir doble listener
        generateReportBtn.addEventListener('click', window.generateSalesReport);
        generateReportBtn._hasClickListener = true;
    }

    // Limpiar resultados al cargar la página
    reportResultsDiv.classList.add('hidden');
};