<?php
// api/products.php
require_once __DIR__ . '/../db_connection.php';
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
header('Content-Type: application/json');

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if (!isset($_SESSION['user_id'])) {
    http_response_code(401); // Unauthorized
    echo json_encode(['error' => 'Acceso no autorizado.']);
    exit();
}

$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? '';

// Eliminamos: $conn = get_db_connection(); // Esto era problemático fuera de un try-catch

switch ($method) {
    case 'GET':
        try {
            $pdo = get_db_connection(); // Obtener la conexión PDO dentro del try-catch
            if ($action === 'list') {
                $stmt = $pdo->query("SELECT p.*, pc.name as category_name FROM products p LEFT JOIN product_categories pc ON p.category_id = pc.id ORDER BY p.name ASC");
                $products = $stmt->fetchAll(PDO::FETCH_ASSOC);
                echo json_encode($products);
            } elseif ($action === 'list_categories') {
                $stmt = $pdo->query("SELECT id, name FROM product_categories ORDER BY name ASC");
                $categories = $stmt->fetchAll(PDO::FETCH_ASSOC);
                echo json_encode($categories);
            } else {
                http_response_code(400);
                echo json_encode(['error' => 'Acción GET no válida.']);
            }
        } catch (PDOException $e) {
            http_response_code(500);
            echo json_encode(['error' => 'Error de base de datos en GET (productos): ' . $e->getMessage()]);
        }
        break;

    case 'POST':
        $input = json_decode(file_get_contents('php://input'), true);

        // --- INICIO DE DEPURACIÓN CRÍTICA ---
        error_log("DEBUG: Contenido de \$input para POST (add/update/add_category): " . json_encode($input));
        error_log("DEBUG: Valor de category_id en \$input: " . ($input['category_id'] ?? 'NO_SET_IN_INPUT'));
        // --- FIN DE DEPURACIÓN CRÍTICA ---

        if ($action === 'add') {
            // Check for required fields
            $name = $input['name'] ?? '';
            $sku = $input['sku'] ?? '';
            $price = $input['price'] ?? '';
            $stock = $input['stock'] ?? '';
            $category_id = $input['category_id'] ?? null; // Mantén este null, es mejor que '' para números
            $description = $input['description'] ?? '';

            // --- INICIO DE DEPURACIÓN ADICIONAL PARA CADA VARIABLE ---
            error_log("DEBUG: \$name = " . $name);
            error_log("DEBUG: \$sku = " . $sku);
            error_log("DEBUG: \$price = " . $price);
            error_log("DEBUG: \$stock = " . $stock);
            error_log("DEBUG: \$category_id = " . ($category_id === null ? 'null' : $category_id));
            // --- FIN DE DEPURACIÓN ADICIONAL ---

            if (empty($name) || empty($sku) || empty($price) || !isset($stock) || empty($category_id)) {
                // --- DEBUG: Agregamos qué campo está fallando ---
                $missing_fields = [];
                if (empty($name)) $missing_fields[] = 'name';
                if (empty($sku)) $missing_fields[] = 'sku';
                if (empty($price)) $missing_fields[] = 'price';
                if (!isset($stock)) $missing_fields[] = 'stock (not set)'; // !isset() para 0
                if (empty($category_id)) $missing_fields[] = 'category_id';
                error_log("DEBUG: Faltan/campos vacíos detectados: " . implode(', ', $missing_fields));
                // --- FIN DEBUG ---

                http_response_code(400);
                echo json_encode(['error' => 'Nombre, SKU, Precio, Stock y Categoría son campos obligatorios.']);
                exit();
            }

            try {
                $pdo = get_db_connection();
                // Check if SKU already exists
                $stmt_check_sku = $pdo->prepare("SELECT COUNT(*) FROM products WHERE sku = ?");
                $stmt_check_sku->execute([$sku]);
                if ($stmt_check_sku->fetchColumn() > 0) {
                    http_response_code(409); // Conflict
                    echo json_encode(['error' => 'El SKU ya existe.']);
                    exit();
                }

                $stmt = $pdo->prepare("INSERT INTO products (name, sku, price, stock, category_id, description) VALUES (?, ?, ?, ?, ?, ?)");
                $stmt->execute([$name, $sku, $price, $stock, $category_id, $description]);

                if ($stmt->rowCount() > 0) {
                    echo json_encode(['message' => 'Producto agregado exitosamente.', 'productId' => $pdo->lastInsertId()]);
                } else {
                    http_response_code(500);
                    echo json_encode(['error' => 'Error al agregar el producto.']);
                }
            } catch (PDOException $e) {
                http_response_code(500);
                echo json_encode(['error' => 'Error de base de datos al agregar producto: ' . $e->getMessage()]);
            }
        } elseif ($action === 'update') {
            // ... (UPDATE logic) ...
        } elseif ($action === 'add_category') {
            // ... (ADD CATEGORY logic) ...
        }
        break;

    case 'PUT': // Actualizar producto o categoría
        parse_str($_SERVER['QUERY_STRING'], $query);
        $action = $query['action'] ?? null;
        $id = $query['id'] ?? null;
        $data = json_decode(file_get_contents('php://input'), true);

        if (!$id) {
            http_response_code(400);
            echo json_encode(['error' => 'ID no proporcionado.']);
            exit();
        }

        try {
            $pdo = get_db_connection();

            if ($action === 'update') {
                if (!isset($data['name'], $data['sku'], $data['price'], $data['stock'], $data['category_id'])) {
                    http_response_code(400);
                    echo json_encode(['error' => 'Datos de producto incompletos.']);
                    exit();
                }

                // Verificar si SKU ya existe para otro producto
                $stmt = $pdo->prepare("SELECT COUNT(*) FROM products WHERE sku = ? AND id != ?");
                $stmt->execute([$data['sku'], $id]);
                if ($stmt->fetchColumn() > 0) {
                    http_response_code(409);
                    echo json_encode(['error' => 'El SKU ya está registrado para otro producto.']);
                    exit();
                }

                $stmt = $pdo->prepare("UPDATE products SET name = ?, sku = ?, price = ?, stock = ?, category_id = ?, description = ? WHERE id = ?");
                $stmt->execute([
                    $data['name'],
                    $data['sku'],
                    $data['price'],
                    $data['stock'],
                    $data['category_id'],
                    $data['description'] ?? null,
                    $id
                ]);

                if ($stmt->rowCount() > 0) {
                    http_response_code(200);
                    echo json_encode(['message' => 'Producto actualizado exitosamente.']);
                } else {
                    // Esto puede ser por ID no encontrado o por datos idénticos
                    // Por eso conviene revisar si el ID existe
                    $check = $pdo->prepare("SELECT id FROM products WHERE id = ?");
                    $check->execute([$id]);
                    if ($check->fetch()) {
                        http_response_code(200); // Aceptamos como válido, aunque no cambió nada
                        echo json_encode(['message' => 'Producto encontrado pero sin cambios.']);
                    } else {
                        http_response_code(404);
                        echo json_encode(['error' => 'Producto no encontrado.']);
                    }
                }

            } elseif ($action === 'update_category') {
                if (!isset($data['name'])) {
                    http_response_code(400);
                    echo json_encode(['error' => 'Nombre de categoría no proporcionado.']);
                    exit();
                }

                $stmt = $pdo->prepare("UPDATE product_categories SET name = ? WHERE id = ?");
                $stmt->execute([$data['name'], $id]);

                if ($stmt->rowCount() > 0) {
                    http_response_code(200);
                    echo json_encode(['message' => 'Categoría actualizada exitosamente.']);
                } else {
                    $check = $pdo->prepare("SELECT id FROM product_categories WHERE id = ?");
                    $check->execute([$id]);
                    if ($check->fetch()) {
                        http_response_code(200);
                        echo json_encode(['message' => 'Categoría encontrada pero sin cambios.']);
                    } else {
                        http_response_code(404);
                        echo json_encode(['error' => 'Categoría no encontrada.']);
                    }
                }

            } else {
                http_response_code(400);
                echo json_encode(['error' => 'Acción PUT no válida.']);
            }

        } catch (PDOException $e) {
            http_response_code(500);
            echo json_encode(['error' => 'Error de base de datos en PUT: ' . $e->getMessage()]);
        }
        break;


    case 'DELETE': // Eliminar producto o categoría
        parse_str($_SERVER['QUERY_STRING'], $query);
        $action = $query['action'] ?? null;
        $id = $query['id'] ?? null;

        if (!$id) {
            http_response_code(400);
            echo json_encode(['error' => 'ID no proporcionado.']);
            exit();
        }

        try {
            $pdo = get_db_connection();

            if ($action === 'delete') {
                // Eliminar producto
                $stmt = $pdo->prepare("DELETE FROM products WHERE id = ?");
                $stmt->execute([$id]);
                if ($stmt->rowCount() > 0) {
                    http_response_code(200);
                    echo json_encode(['message' => 'Producto eliminado exitosamente.']);
                } else {
                    http_response_code(404);
                    echo json_encode(['error' => 'Producto no encontrado.']);
                }

            } elseif ($action === 'delete_category') {
                // Verificar si la categoría tiene productos asociados
                $stmt_check = $pdo->prepare("SELECT COUNT(*) FROM products WHERE category_id = ?");
                $stmt_check->execute([$id]);
                $count = $stmt_check->fetchColumn();

                if ($count > 0) {
                    http_response_code(409); // Conflict
                    echo json_encode(['error' => 'No se puede eliminar la categoría porque tiene productos asociados.']);
                    exit();
                }

                // Eliminar categoría
                $stmt = $pdo->prepare("DELETE FROM product_categories WHERE id = ?");
                $stmt->execute([$id]);
                if ($stmt->rowCount() > 0) {
                    http_response_code(200);
                    echo json_encode(['message' => 'Categoría eliminada exitosamente.']);
                } else {
                    http_response_code(404);
                    echo json_encode(['error' => 'Categoría no encontrada.']);
                }

            } else {
                http_response_code(400);
                echo json_encode(['error' => 'Acción DELETE no válida.']);
            }

        } catch (PDOException $e) {
            http_response_code(500);
            echo json_encode(['error' => 'Error de base de datos: ' . $e->getMessage()]);
        }
        break;


    default:
        http_response_code(405); // Method Not Allowed
        echo json_encode(['error' => 'Método no permitido.']);
        break;
}
?>