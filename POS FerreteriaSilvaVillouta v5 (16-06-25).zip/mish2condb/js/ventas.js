// js/sales.js (VERSIÓN FINAL SIN MÉTODO DE PAGO NI IVA)

// Variables globales para el módulo de Ventas
let currentCart = []; // El carrito de compras actual
let selectedClientForSale = null; // Cliente seleccionado para la venta
let discountAmount = 0; // Monto de descuento aplicado a la venta

// --- REFERENCIAS A ELEMENTOS DEL DOM (Se inicializan en initVentas) ---
// Declaradas aquí para que sean accesibles en todo el script
let productSearchInput;
let productCategoryFilter;
let productsListBody;
let noProductsMessage;
let cartItemsBody;
let emptyCartMessage;
let cartSubtotalAmount;
let cartDiscountAmount;
let cartTotalAmount;
let clientSelect;
let documentTypeSelect;
let applyDiscountBtn;
let clearCartBtn;
let processSaleBtn;
let discountModal;
let closeDiscountModalBtn;
let discountInput;
let saveDiscountBtn; // Este ID se usa en el HTML del modal
let confirmSaleModal;
let closeConfirmSaleModalBtn;
let cancelConfirmSaleBtn;
let finalizeSaleBtn;

/**
 * Inicializa el módulo de Ventas, obteniendo referencias a los elementos DOM
 * y adjuntando todos los event listeners. Se llama desde main.js.
 */
window.initVentas = () => {
    console.log('Inicializando Módulo de Ventas...');

    // Usamos requestAnimationFrame para asegurarnos de que el DOM esté completamente cargado y renderizado
    // antes de intentar obtener las referencias a los elementos.
    requestAnimationFrame(() => {
        // Obtener referencias a los elementos DOM
        productSearchInput = document.getElementById('product-search-input');
        productCategoryFilter = document.getElementById('product-category-filter');
        productsListBody = document.getElementById('products-list-body');
        noProductsMessage = document.getElementById('no-products-message');
        cartItemsBody = document.getElementById('cart-items-body');
        emptyCartMessage = document.getElementById('empty-cart-message');
        cartSubtotalAmount = document.getElementById('cart-subtotal-amount');
        cartDiscountAmount = document.getElementById('cart-discount-amount');
        // cartTaxAmount (Eliminado ya que no se usa el IVA)
        cartTotalAmount = document.getElementById('cart-total-amount');
        clientSelect = document.getElementById('client-select');
        documentTypeSelect = document.getElementById('document-type-select');
        // paymentMethodSelect (Eliminado ya que no se usa el método de pago)
        applyDiscountBtn = document.getElementById('apply-discount-btn');
        clearCartBtn = document.getElementById('clear-cart-btn');
        processSaleBtn = document.getElementById('process-sale-btn');
        discountModal = document.getElementById('discount-modal');
        closeDiscountModalBtn = document.getElementById('close-discount-modal-btn');
        discountInput = document.getElementById('discount-input');
        // saveDiscountBtn apunta al botón "Aplicar Descuento" dentro del modal de descuento.
        saveDiscountBtn = discountModal ? discountModal.querySelector('#apply-discount-btn') : null;
        confirmSaleModal = document.getElementById('confirm-sale-modal');
        closeConfirmSaleModalBtn = document.getElementById('close-confirm-sale-modal-btn');
        cancelConfirmSaleBtn = document.getElementById('cancel-confirm-sale-btn');
        finalizeSaleBtn = document.getElementById('finalize-sale-btn');


        // --- VALIDACIÓN DE ELEMENTOS CRÍTICOS DEL DOM ---
        // Si alguno de estos elementos vitales no se encuentra, mostramos un error y salimos.
        if (!productSearchInput || !productsListBody || !cartItemsBody || !cartTotalAmount || !processSaleBtn) {
            console.error('Elementos del DOM del módulo de Ventas no encontrados. `sales.html` no cargado correctamente o IDs incorrectos.');
            window.showToast('Error al iniciar módulo de ventas. Algunos elementos no se encontraron.', true);
            return;
        }
        console.log('Todos los elementos DOM del módulo de Ventas encontrados y referenciados.');


        // --- CONFIGURACIÓN INICIAL ---
        currentCart = []; // Asegurar que el carrito esté vacío al iniciar el módulo
        discountAmount = 0;
        renderCart(); // Renderizar el carrito vacío
        renderProductsList(); // Cargar y renderizar la lista de productos
        // Asegúrate de que `window.populateCategories` exista en `main.js` o en un script cargado antes
        if (typeof window.populateCategories === 'function') {
            window.populateCategories(null, productCategoryFilter); // Usar la función global para popular el filtro de categoría
        } else {
            console.warn('`window.populateCategories` no está definida. Las categorías de productos podrían no cargarse.');
        }
        populateClients(); // Cargar y popular el selector de clientes
        setupModalListeners(); // Configurar los listeners de los modales

        // --- EVENT LISTENERS ---
        productSearchInput.addEventListener('input', renderProductsList);
        if (productCategoryFilter) {
            productCategoryFilter.addEventListener('change', renderProductsList);
        }
        if (productsListBody) {
            productsListBody.addEventListener('click', (e) => {
                const addBtn = e.target.closest('.add-to-cart-btn');
                if (addBtn) {
                    const productId = parseInt(addBtn.dataset.productId);
                    addProductToCart(productId);
                }
            });
        }
        if (cartItemsBody) {
            cartItemsBody.addEventListener('click', (e) => {
                const removeBtn = e.target.closest('.remove-from-cart-btn');
                const updateBtn = e.target.closest('.update-cart-qty-btn');
                if (removeBtn) {
                    const productId = parseInt(removeBtn.dataset.productId);
                    removeProductFromCart(productId);
                } else if (updateBtn) {
                    const productId = parseInt(updateBtn.dataset.productId);
                    const newQty = parseInt(updateBtn.previousElementSibling.value); // Asumiendo que el input está antes del botón
                    updateCartItemQuantity(productId, newQty);
                }
            });
        }
        if (processSaleBtn) {
            processSaleBtn.addEventListener('click', openConfirmSaleModal);
        }
        if (clearCartBtn) {
            clearCartBtn.addEventListener('click', clearCart);
        }
        if (applyDiscountBtn) {
            applyDiscountBtn.addEventListener('click', openDiscountModal);
        }
    });
};

// --- FUNCIONES DE LÓGICA DE NEGOCIO ---

/**
 * Renderiza la lista de productos disponibles para la venta, aplicando filtros de búsqueda y categoría.
 */
function renderProductsList() {
    productsListBody.innerHTML = '';
    const searchTerm = productSearchInput.value.toLowerCase().trim();
    const categoryFilter = productCategoryFilter ? productCategoryFilter.value : 'all';

    const filteredProducts = window.products.filter(product => {
        const matchesSearch = product.name.toLowerCase().includes(searchTerm) ||
                              product.sku.toLowerCase().includes(searchTerm) ||
                              (product.id && product.id.toString().includes(searchTerm));
        const matchesCategory = categoryFilter === 'all' || product.category_id == categoryFilter;
        return matchesSearch && matchesCategory;
    });

    if (filteredProducts.length === 0) {
        noProductsMessage.classList.remove('hidden');
        return;
    } else {
        noProductsMessage.classList.add('hidden');
    }

    filteredProducts.forEach(product => {
        const row = document.createElement('tr');
        row.className = 'hover:bg-slate-50 transition-colors duration-150';
        row.innerHTML = `
            <td class="py-3 px-4 flex items-center space-x-3">
                <span class="font-semibold text-slate-800">${product.name}</span>
                <span class="text-sm text-slate-500">(${product.sku})</span>
            </td>
            <td class="py-3 px-4 text-center">
                <span class="${product.stock <= 10 ? 'text-red-500 font-bold' : 'text-slate-600'}">${product.stock}</span>
            </td>
            <td class="py-3 px-4 text-right font-medium text-slate-700">
                ${window.formatCurrency(product.sale_price)}
            </td>
            <td class="py-3 px-4 text-center">
                <button class="add-to-cart-btn bg-blue-500 text-white px-3 py-1 rounded-lg hover:bg-blue-600 transition-colors duration-200 text-sm"
                        data-product-id="${product.id}"
                        ${product.stock <= 0 ? 'disabled' : ''}>
                    ${product.stock <= 0 ? 'Sin Stock' : 'Añadir'}
                </button>
            </td>
        `;
        productsListBody.appendChild(row);
    });
};

/**
 * Añade un producto al carrito o incrementa su cantidad.
 * @param {number} productId - El ID del producto.
 */
function addProductToCart(productId) {
    const product = window.products.find(p => p.id === productId);
    if (!product) {
        window.showToast('Producto no encontrado.', true);
        return;
    }

    const cartItem = currentCart.find(item => item.product_id === productId);

    if (cartItem) {
        if (cartItem.quantity < product.stock) {
            cartItem.quantity++;
            window.showToast(`Cantidad de ${product.name} actualizada en el carrito.`);
        } else {
            window.showToast(`No hay suficiente stock de ${product.name}.`, true);
        }
    } else {
        if (product.stock > 0) {
            currentCart.push({
                product_id: product.id,
                name: product.name,
                sku: product.sku,
                price_at_sale: product.sale_price,
                quantity: 1
            });
            window.showToast(`${product.name} añadido al carrito.`);
        } else {
            window.showToast(`${product.name} está sin stock.`, true);
        }
    }
    renderCart();
};

/**
 * Actualiza la cantidad de un ítem en el carrito.
 * @param {number} productId - El ID del producto.
 * @param {number} newQuantity - La nueva cantidad.
 */
function updateCartItemQuantity(productId, newQuantity) {
    const product = window.products.find(p => p.id === productId);
    const cartItem = currentCart.find(item => item.product_id === productId);

    if (!cartItem || !product) {
        window.showToast('Error: Producto no encontrado en el carrito.', true);
        return;
    }

    if (newQuantity <= 0) {
        removeProductFromCart(productId);
        return;
    }

    if (newQuantity > product.stock) {
        window.showToast(`No hay suficiente stock de ${product.name}. Stock disponible: ${product.stock}`, true);
        cartItem.quantity = product.stock; // Ajustar a la cantidad máxima disponible
    } else {
        cartItem.quantity = newQuantity;
        window.showToast(`Cantidad de ${product.name} actualizada a ${newQuantity}.`);
    }
    renderCart();
}

/**
 * Elimina un producto del carrito.
 * @param {number} productId - El ID del producto a eliminar.
 */
function removeProductFromCart(productId) {
    currentCart = currentCart.filter(item => item.product_id !== productId);
    window.showToast('Producto eliminado del carrito.');
    renderCart();
};

/**
 * Vacía todo el carrito de compras.
 */
function clearCart() {
    currentCart = [];
    discountAmount = 0; // Resetear descuento al limpiar el carrito
    window.showToast('Carrito vaciado.');
    renderCart();
};

/**
 * Renderiza los ítems del carrito y actualiza los totales.
 */
function renderCart() {
    cartItemsBody.innerHTML = '';
    let subtotal = 0;

    if (currentCart.length === 0) {
        emptyCartMessage.classList.remove('hidden');
        processSaleBtn.disabled = true; // Deshabilitar botón si carrito está vacío
        clearCartBtn.disabled = true;
        applyDiscountBtn.disabled = true;
    } else {
        emptyCartMessage.classList.add('hidden');
        processSaleBtn.disabled = false; // Habilitar si hay ítems
        clearCartBtn.disabled = false;
        applyDiscountBtn.disabled = false;
        currentCart.forEach(item => {
            const itemSubtotal = item.quantity * item.price_at_sale;
            subtotal += itemSubtotal;

            const row = document.createElement('tr');
            row.className = 'hover:bg-slate-50 transition-colors duration-150';
            row.innerHTML = `
                <td class="py-2 px-3 text-sm font-semibold text-slate-800">${item.name}</td>
                <td class="py-2 px-3 text-center">
                    <input type="number" value="${item.quantity}" min="1"
                           class="w-16 p-1 border border-slate-300 rounded text-center text-sm"
                           data-product-id="${item.product_id}" />
                    <button class="update-cart-qty-btn bg-slate-200 text-slate-700 ml-1 px-2 py-1 rounded-md text-xs hover:bg-slate-300"
                            data-product-id="${item.product_id}">
                        Actualizar
                    </button>
                </td>
                <td class="py-2 px-3 text-right text-sm font-medium text-slate-700">
                    ${window.formatCurrency(itemSubtotal)}
                </td>
                <td class="py-2 px-3 text-center">
                    <button class="remove-from-cart-btn text-red-500 hover:text-red-700 transition-colors duration-200" data-product-id="${item.product_id}">
                        <svg class="w-5 h-5 inline-block" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path></svg>
                    </button>
                </td>
            `;
            cartItemsBody.appendChild(row);
        });
    }

    // No se calcula IVA
    const total = subtotal - discountAmount; 
    
    cartSubtotalAmount.textContent = window.formatCurrency(subtotal);
    cartDiscountAmount.textContent = window.formatCurrency(discountAmount);
    // cartTaxAmount (Eliminado del HTML y JS)
    cartTotalAmount.textContent = window.formatCurrency(total < 0 ? 0 : total); // Asegurar que el total no sea negativo
};

/**
 * Carga los clientes desde la API y los popula en el selector de clientes.
 */
async function populateClients() {
    if (!clientSelect) return; // Asegurar que el elemento exista
    clientSelect.innerHTML = '<option value="">Seleccionar Cliente (Opcional)</option>'; // Opción por defecto
    if (window.clients && Array.isArray(window.clients)) {
        window.clients.forEach(client => {
            const option = document.createElement('option');
            option.value = client.id;
            option.textContent = client.razon_social;
            clientSelect.appendChild(option);
        });
    } else {
        console.warn('window.clients no está cargado o no es un array.');
    }
};

/**
 * Configura los listeners para los modales de descuento y confirmación.
 */
function setupModalListeners() {
    // Modal de Descuento
    if (applyDiscountBtn) applyDiscountBtn.addEventListener('click', openDiscountModal);
    if (closeDiscountModalBtn) closeDiscountModalBtn.addEventListener('click', closeDiscountModal);
    if (discountModal && discountModal.querySelector('#cancel-discount-btn')) { // Botón cancelar dentro del modal
        discountModal.querySelector('#cancel-discount-btn').addEventListener('click', closeDiscountModal);
    }
    if (saveDiscountBtn) saveDiscountBtn.addEventListener('click', applyDiscount);

    // Modal de Confirmación de Venta
    if (processSaleBtn) processSaleBtn.addEventListener('click', openConfirmSaleModal);
    if (closeConfirmSaleModalBtn) closeConfirmSaleModalBtn.addEventListener('click', closeConfirmSaleModal);
    if (cancelConfirmSaleBtn) cancelConfirmSaleBtn.addEventListener('click', closeConfirmSaleModal);
    if (finalizeSaleBtn) finalizeSaleBtn.addEventListener('click', finalizeSale);
}

/**
 * Abre el modal de descuento.
 */
function openDiscountModal() {
    if (discountModal) {
        discountInput.value = discountAmount; // Precargar el descuento actual
        discountModal.classList.remove('hidden');
        discountModal.classList.add('flex'); // Asegurarse de que sea visible
        // Animación
        const modalContent = document.getElementById('discount-modal-content');
        if (modalContent) {
            modalContent.classList.remove('scale-95', 'opacity-0');
            modalContent.classList.add('scale-100', 'opacity-100');
        }
    }
}

/**
 * Cierra el modal de descuento.
 */
function closeDiscountModal() {
    if (discountModal) {
        const modalContent = document.getElementById('discount-modal-content');
        if (modalContent) {
            modalContent.classList.remove('scale-100', 'opacity-100');
            modalContent.classList.add('scale-95', 'opacity-0');
            setTimeout(() => {
                discountModal.classList.add('hidden');
                discountModal.classList.remove('flex');
            }, 300); // Duración de la transición
        }
    }
}

/**
 * Aplica el descuento ingresado.
 */
function applyDiscount() {
    const inputDiscount = parseFloat(discountInput.value) || 0;
    let currentSubtotal = currentCart.reduce((sum, item) => sum + (item.quantity * item.price_at_sale), 0);

    if (inputDiscount < 0) {
        window.showToast('El descuento no puede ser negativo.', true);
        return;
    }
    if (inputDiscount > currentSubtotal) {
        window.showToast('El descuento no puede ser mayor que el subtotal.', true);
        discountAmount = currentSubtotal; // Limitar el descuento al subtotal
    } else {
        discountAmount = inputDiscount;
    }
    window.showToast(`Descuento de ${window.formatCurrency(discountAmount)} aplicado.`);
    renderCart();
    closeDiscountModal();
}

/**
 * Abre el modal de confirmación de venta con el resumen.
 */
function openConfirmSaleModal() {
    if (!confirmSaleModal || currentCart.length === 0) {
        window.showToast('No hay ítems en el carrito para procesar la venta.', true);
        return;
    }

    // Actualizar los detalles en el modal de confirmación
    document.getElementById('confirm-client-name').textContent = clientSelect.options[clientSelect.selectedIndex].text || 'Consumidor Final';
    document.getElementById('confirm-document-type').textContent = documentTypeSelect.value;
    // payment_method eliminado

    const confirmItemsBody = document.getElementById('confirm-items-body');
    confirmItemsBody.innerHTML = '';
    let confirmSubtotal = 0;
    currentCart.forEach(item => {
        const itemTotal = item.quantity * item.price_at_sale;
        confirmSubtotal += itemTotal;
        const row = document.createElement('tr');
        row.innerHTML = `
            <td class="py-2 px-3">${item.name} (${item.sku})</td>
            <td class="py-2 px-3 text-center">${item.quantity}</td>
            <td class="py-2 px-3 text-right">${window.formatCurrency(item.price_at_sale)}</td>
            <td class="py-2 px-3 text-right">${window.formatCurrency(itemTotal)}</td>
        `;
        confirmItemsBody.appendChild(row);
    });

    // No se calcula IVA
    let confirmTotal = confirmSubtotal - discountAmount; 
    if (confirmTotal < 0) confirmTotal = 0;

    document.getElementById('confirm-subtotal-amount').textContent = window.formatCurrency(confirmSubtotal);
    document.getElementById('confirm-discount-amount').textContent = window.formatCurrency(discountAmount);
    // confirm-tax-amount eliminado
    document.getElementById('confirm-total-amount').textContent = window.formatCurrency(confirmTotal);

    confirmSaleModal.classList.remove('hidden');
    confirmSaleModal.classList.add('flex');
    const modalContent = document.getElementById('confirm-sale-modal-content');
    if (modalContent) {
        modalContent.classList.remove('scale-95', 'opacity-0');
        modalContent.classList.add('scale-100', 'opacity-100');
    }
}

/**
 * Cierra el modal de confirmación de venta.
 */
function closeConfirmSaleModal() {
    if (confirmSaleModal) {
        const modalContent = document.getElementById('confirm-sale-modal-content');
        if (modalContent) {
            modalContent.classList.remove('scale-100', 'opacity-100');
            modalContent.classList.add('scale-95', 'opacity-0');
            setTimeout(() => {
                confirmSaleModal.classList.add('hidden');
                confirmSaleModal.classList.remove('flex');
            }, 300); // Duración de la transición
        }
    }
}

/**
 * Finaliza la venta, enviando los datos a la API.
 */
async function finalizeSale() {
    if (currentCart.length === 0) {
        window.showToast('El carrito está vacío. No se puede finalizar la venta.', true);
        return;
    }

    const totalAmount = parseFloat(cartTotalAmount.textContent.replace(/[$.]/g, '').replace(',', '.')); // Convertir a número flotante
    const subtotalAmount = parseFloat(cartSubtotalAmount.textContent.replace(/[$.]/g, '').replace(',', '.'));
    // taxAmount eliminado

    const saleData = {
        client_id: clientSelect.value ? parseInt(clientSelect.value) : null,
        user_id: window.currentUser ? window.currentUser.id : null, 
        subtotal_amount: subtotalAmount,
        total_amount: totalAmount,
        discount_amount: discountAmount,
        tax_amount: 0, // Siempre 0 si no hay IVA
        document_type: documentTypeSelect.value,
        // document_number no existe en tu DB, por lo que no se envía
        // payment_method no existe en tu DB, por lo que no se envía
        items: currentCart.map(item => ({
            product_id: item.product_id,
            quantity: item.quantity,
            price_at_sale: item.price_at_sale,
            item_total: item.quantity * item.price_at_sale
        }))
    };

    try {
        const response = await fetch('/api/sales.php?action=register', { 
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(saleData)
        });

        const result = await response.json();

        if (response.ok && result.success) {
            window.showToast('Venta registrada exitosamente!');
            clearCart();
            closeConfirmSaleModal();
            await window.loadDataFromAPI(); // Recargar todos los datos (incluyendo productos para stock actualizado)
            renderProductsList(); // Volver a renderizar la lista de productos para reflejar el stock
        } else {
            window.showToast(result.error || 'Error al registrar la venta. Inténtelo de nuevo.', true);
            console.error('Error al registrar venta:', result.error);
        }
    } catch (error) {
        console.error('Error de red al finalizar venta:', error);
        window.showToast('Error de conexión al registrar venta.', true);
    }
}
