// js/productos.js (VERSIÓN FINAL CON REFERENCIAS DOM MOVIDAS Y RBAC)

// --- NUEVA FUNCIÓN: POPULATE CATEGORIES ---
// Ahora acepta los elementos select como parámetros para mayor robustez
window.populateCategories = (productCategorySelect, filterCategorySelect) => {
    // Asegurarse de que window.categories esté disponible y sea un array
    if (!window.categories || !Array.isArray(window.categories)) {
        console.error('Error: window.categories no está cargado o no es un array.');
        return;
    }

    // Llenar el select del filtro de categorías
    if (filterCategorySelect) {
        // Limpiar opciones existentes, manteniendo la opción "Todas las categorías"
        filterCategorySelect.innerHTML = '<option value="all">Todas las categorías</option>';
        window.categories.forEach(category => {
            const option = document.createElement('option');
            option.value = category.id;
            option.textContent = category.name;
            filterCategorySelect.appendChild(option);
        });
    }

    // Llenar el select de categorías en el modal de producto
    if (productCategorySelect) {
        // Limpiar opciones existentes
        productCategorySelect.innerHTML = '<option value="">Selecciona una categoría</option>'; // Opción por defecto
        window.categories.forEach(category => {
            const option = document.createElement('option');
            option.value = category.id;
            option.textContent = category.name;
            productCategorySelect.appendChild(option);
        });
    }
};

/**
 * Renderiza la tabla de productos.
 * @param {HTMLElement} productTableBody - El tbody de la tabla de productos.
 * @param {Array} productsToRender - Los productos a mostrar.
 */
window.renderProductTable = function(productTableBody, productsToRender) {
    productTableBody.innerHTML = ''; // Limpiar la tabla antes de renderizar
    const noProductsMessage = document.getElementById('no-products-message');
    
    // Aplicar filtros de búsqueda y categoría
    const searchTerm = (document.getElementById('product-table-search')?.value || '').toLowerCase();
    const categoryFilter = document.getElementById('product-category-filter')?.value || 'all';

    const filteredProducts = (productsToRender || window.products).filter(product => {
        const matchesSearch = product.nombre_producto.toLowerCase().includes(searchTerm) ||
                              product.sku.toLowerCase().includes(searchTerm) ||
                              (product.id && product.id.toString().includes(searchTerm));
        const matchesCategory = categoryFilter === 'all' || product.category_id == categoryFilter;
        return matchesSearch && matchesCategory;
    });

    if (filteredProducts.length === 0) {
        if (noProductsMessage) {
            noProductsMessage.textContent = window.products && window.products.length > 0 ? 'No se encontraron productos que coincidan con los filtros.' : 'No hay productos registrados.';
            // Asegurarse de que el mensaje de "No hay productos" siempre se muestre cuando la tabla está vacía
            const colspan = productTableBody.closest('table').querySelector('thead tr').children.length;
            productTableBody.innerHTML = `<tr><td colspan="${colspan}" class="p-4 text-center text-gray-500">${noProductsMessage.textContent}</td></tr>`;
        }
        return; // Salir si no hay productos
    } else {
        if (noProductsMessage) {
            // No se oculta el mensaje de "no products" aquí, se sobrescribe el tbody
        }
    }

    // Obtener el rol del usuario actual para controlar la visibilidad de las acciones
    const currentUserRole = window.currentUser ? window.currentUser.role_name : null;
    const canEditOrDelete = currentUserRole === 'Administrador' || currentUserRole === 'Bodeguero';

    filteredProducts.forEach(product => {
        const row = document.createElement('tr');
        row.className = 'hover:bg-gray-50';
        row.innerHTML = `
            <td class="p-3">${product.id}</td>
            <td class="p-3">${product.sku}</td>
            <td class="p-3">${product.nombre_producto}</td>
            <td class="p-3">${window.formatCurrency(product.precio)}</td>
            <td class="p-3">${product.stock}</td>
            <td class="p-3">${product.category_name || 'Sin Categoría'}</td>
            <td class="p-3">${product.descripcion || 'N/A'}</td>
            <td class="p-3">
                <div class="flex items-center space-x-2">
                    ${canEditOrDelete ? `
                    <button class="edit-product-btn text-yellow-600 hover:text-yellow-800 p-1 rounded-md hover:bg-yellow-100 transition-colors" data-product-id="${product.id}" title="Editar Producto">
                        <span class="lucide" data-lucide="edit"></span>
                    </button>
                    <button class="delete-product-btn text-red-600 hover:text-red-800 p-1 rounded-md hover:bg-red-100 transition-colors" data-product-id="${product.id}" title="Eliminar Producto">
                        <span class="lucide" data-lucide="trash-2"></span>
                    </button>
                    ` : '<span>N/A</span>'}
                </div>
            </td>
        `;
        productTableBody.appendChild(row);
    });

    // Adjuntar event listeners a los botones de Editar y Eliminar SOLO SI son visibles
    if (canEditOrDelete) {
        productTableBody.querySelectorAll('.edit-product-btn').forEach(button => {
            button.addEventListener('click', (event) => {
                const id = event.currentTarget.dataset.productId;
                window.openProductModal(window.products.find(p => p.id == id));
            });
        });

        productTableBody.querySelectorAll('.delete-product-btn').forEach(button => {
            button.addEventListener('click', (event) => {
                const id = event.currentTarget.dataset.productId;
                window.deleteProduct(id);
            });
        });
    }

    if (window.lucide) {
        window.lucide.createIcons();
    }
};

/**
 * Abre el modal de producto para añadir o editar.
 * @param {Object} [product=null] - Objeto producto si es para edición, null para añadir.
 */
window.openProductModal = function(product = null) {
    const productModal = document.getElementById('product-modal');
    const productForm = document.getElementById('product-form');
    const productModalTitle = document.getElementById('product-modal-title');
    const productIdInput = document.getElementById('product-id');
    const productNameInput = document.getElementById('product-name');
    const productSkuInput = document.getElementById('product-sku');
    const productPriceInput = document.getElementById('product-price');
    const productStockInput = document.getElementById('product-stock');
    const productCategorySelect = document.getElementById('product-category');
    const productDescriptionInput = document.getElementById('product-description');
    
    productForm.reset();
    productModal.classList.remove('hidden');
    productModal.classList.add('flex');

    if (product) {
        productIdInput.value = product.id;
        productModalTitle.textContent = 'Editar Producto';
        productNameInput.value = product.nombre_producto || '';
        productSkuInput.value = product.sku || '';
        productPriceInput.value = product.precio || 0;
        productStockInput.value = product.stock || 0;
        productCategorySelect.value = product.category_id || '';
        productDescriptionInput.value = product.descripcion || '';
    } else {
        productIdInput.value = '';
        productModalTitle.textContent = 'Añadir Nuevo Producto';
    }
    window.populateCategories(productCategorySelect, null); // Solo el select del modal
    if (window.lucide) {
        window.lucide.createIcons();
    }
};

/**
 * Maneja el envío del formulario de producto (añadir o actualizar).
 */
window.handleProductFormSubmit = async function(event) {
    event.preventDefault();
    const productModal = document.getElementById('product-modal');
    const productId = document.getElementById('product-id').value;
    const isEditing = productId !== '';
    const action = isEditing ? 'update' : 'add';
    const url = `api/products.php?action=${action}` + (isEditing ? `&id=${productId}` : '');

    const payload = {
        name: document.getElementById('product-name').value.trim(),
        sku: document.getElementById('product-sku').value.trim(),
        price: parseFloat(document.getElementById('product-price').value),
        stock: parseInt(document.getElementById('product-stock').value),
        category_id: document.getElementById('product-category').value,
        description: document.getElementById('product-description').value.trim()
    };

    if (!payload.name || !payload.sku || isNaN(payload.price) || payload.price < 0 || isNaN(payload.stock) || payload.stock < 0 || !payload.category_id) {
        window.showToast('Por favor, rellena todos los campos obligatorios y asegúrate de que el precio y el stock sean válidos.', true);
        return;
    }

    try {
        const res = await fetch(url, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });
        const data = await res.json();

        if (res.ok) {
            window.showToast(data.message || (isEditing ? 'Producto actualizado exitosamente!' : 'Producto añadido exitosamente!'));
            productModal.classList.add('hidden');
            document.getElementById('product-form').reset();
            await window.loadDataFromAPI(); // Recargar todos los datos globales, incluyendo productos y categorías
            window.renderProductTable(document.getElementById('product-table-body')); // Re-renderizar la tabla de productos
        } else {
            window.showToast(data.error || 'Error al guardar producto.', true);
        }
    } catch (err) {
        console.error('Error de red al guardar producto:', err);
        window.showToast('Error de conexión al guardar producto.', true);
    }
};

/**
 * Elimina un producto de la base de datos.
 * @param {number} id - ID del producto a eliminar.
 */
window.deleteProduct = async function(id) {
    // Reemplazar confirm() con un modal personalizado para mejor UX
    if (!confirm('¿Está seguro de que desea eliminar este producto? Esta acción es irreversible.')) {
        return;
    }
    try {
        const res = await fetch(`api/products.php?action=delete&id=${id}`, {
            method: 'DELETE'
        });
        const data = await res.json();
        if (res.ok) {
            window.showToast(data.message || 'Producto eliminado exitosamente.');
            await window.loadDataFromAPI(); // Recargar productos y categorías
            window.renderProductTable(document.getElementById('product-table-body')); // Re-renderizar la tabla
        } else {
            window.showToast(data.error || 'Error al eliminar producto.', true);
        }
    } catch (error) {
        console.error('Error de red al eliminar producto:', error);
        window.showToast('Error de conexión al eliminar producto.', true);
    }
};

/**
 * Añade una nueva categoría de producto.
 * @param {string} categoryName - Nombre de la nueva categoría.
 */
window.addCategory = async function(categoryName) {
    try {
        const res = await fetch('api/products.php?action=add_category', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ name: categoryName })
        });
        const data = await res.json();
        if (res.ok) {
            window.showToast(data.message || 'Categoría añadida exitosamente.');
            document.getElementById('new-category-name').value = ''; // Limpiar input
            await window.loadDataFromAPI(); // Recargar categorías globales
            window.populateCategories(
                document.getElementById('product-category'),
                document.getElementById('product-category-filter')
            );
        } else {
            window.showToast(data.error || 'Error al añadir categoría.', true);
        }
    } catch (error) {
        console.error('Error de red al añadir categoría:', error);
        window.showToast('Error de conexión al añadir categoría.', true);
    }
};

// Función de inicialización para el módulo de Productos
window.initProductos = async () => {
    console.log('--- Iniciando initProductos ---');

    // Referencias a elementos DOM
    const productTableBody = document.getElementById('product-table-body');
    const productTableSearch = document.getElementById('product-table-search');
    const productCategoryFilter = document.getElementById('product-category-filter');
    const addProductBtn = document.getElementById('add-product-btn');
    const addCategoryBtn = document.getElementById('add-category-btn');
    const newCategoryNameInput = document.getElementById('new-category-name');
    const manageCategoriesSection = document.getElementById('manage-categories-section'); // Contenedor de la sección de categorías
    const productModal = document.getElementById('product-modal');
    const closeProductModalBtn = document.getElementById('close-product-modal-btn');
    const productForm = document.getElementById('product-form');
    const productCategorySelect = document.getElementById('product-category'); // Select de categoría en el modal de producto

    // Validar que los elementos esenciales existan
    if (!productTableBody || !productTableSearch || !productCategoryFilter || !addProductBtn || !productModal || !closeProductModalBtn || !productForm || !productCategorySelect || !addCategoryBtn || !newCategoryNameInput || !manageCategoriesSection) {
        console.error('Error: Algunos elementos principales del DOM de productos no se encontraron. Asegúrate de que los IDs sean correctos.');
        window.showToast('Error: No se pudo cargar la interfaz de productos correctamente.', true);
        return;
    }

    // --- Control de Acceso por Roles (RBAC) ---
    const currentUserRole = window.currentUser ? window.currentUser.role_name : null;

    // Ocultar botón "Añadir Producto" y sección de categorías si es "Vendedor"
    if (currentUserRole === 'Vendedor') {
        addProductBtn.classList.add('hidden');
        manageCategoriesSection.classList.add('hidden');
        // Los botones de editar/eliminar en la tabla se controlan en renderProductTable
    } else {
        addProductBtn.classList.remove('hidden');
        manageCategoriesSection.classList.remove('hidden');
    }

    // --- CONFIGURACIÓN DE EVENT LISTENERS ---
    
    // Abrir/Cerrar modal de producto
    addProductBtn.addEventListener('click', () => window.openProductModal());
    closeProductModalBtn.addEventListener('click', () => productModal.classList.add('hidden'));

    // Envío del formulario de producto
    productForm.addEventListener('submit', (e) => window.handleProductFormSubmit(e));

    // Event listeners para búsqueda y filtro de categoría
    productTableSearch.addEventListener('input', () => window.renderProductTable(productTableBody));
    productCategoryFilter.addEventListener('change', () => window.renderProductTable(productTableBody));
// js/products.js (VERSIÓN FINAL CON REFERENCIAS DOM MOVIDAS Y RBAC)

// --- NUEVA FUNCIÓN: POPULATE CATEGORIES ---
// Ahora acepta los elementos select como parámetros para mayor robustez
window.populateCategories = (productCategorySelect, filterCategorySelect) => {
    // Asegurarse de que window.categories esté disponible y sea un array
    if (!window.categories || !Array.isArray(window.categories)) {
        console.error('Error: window.categories no está cargado o no es un array.');
        return;
    }

    // Llenar el select del filtro de categorías
    if (filterCategorySelect) {
        // Limpiar opciones existentes, manteniendo la opción "Todas las categorías"
        filterCategorySelect.innerHTML = '<option value="all">Todas las categorías</option>';
        window.categories.forEach(category => {
            const option = document.createElement('option');
            option.value = category.id;
            option.textContent = category.name;
            filterCategorySelect.appendChild(option);
        });
    }

    // Llenar el select de categorías en el modal de producto
    if (productCategorySelect) {
        // Limpiar opciones existentes
        productCategorySelect.innerHTML = '<option value="">Selecciona una categoría</option>'; // Opción por defecto
        window.categories.forEach(category => {
            const option = document.createElement('option');
            option.value = category.id;
            option.textContent = category.name;
            productCategorySelect.appendChild(option);
        });
    }
};

/**
 * Renderiza la tabla de productos.
 * @param {HTMLElement} productTableBody - El tbody de la tabla de productos.
 * @param {Array} productsToRender - Los productos a mostrar. Si no se provee, usa window.products.
 */
window.renderProductTable = function(productTableBody, productsToRender) {
    productTableBody.innerHTML = ''; // Limpiar la tabla antes de renderizar
    const noProductsMessage = document.getElementById('no-products-message');
    
    // Aplicar filtros de búsqueda y categoría
    const searchTerm = (document.getElementById('product-table-search')?.value || '').toLowerCase();
    const categoryFilter = document.getElementById('product-category-filter')?.value || 'all';

    const filteredProducts = (productsToRender || window.products).filter(product => {
        const matchesSearch = (product.name && product.name.toLowerCase().includes(searchTerm)) || // Cambiado de 'nombre_producto' a 'name'
                              (product.sku && product.sku.toLowerCase().includes(searchTerm)) ||
                              (product.id && product.id.toString().includes(searchTerm));
        const matchesCategory = categoryFilter === 'all' || product.category_id == categoryFilter;
        return matchesSearch && matchesCategory;
    });

    if (filteredProducts.length === 0) {
        if (noProductsMessage) {
            noProductsMessage.textContent = (window.products && window.products.length > 0) ? 'No se encontraron productos que coincidan con los filtros.' : 'No hay productos registrados.';
            // Asegurarse de que el mensaje de "No hay productos" siempre se muestre cuando la tabla está vacía
            const colspanElement = productTableBody.closest('table')?.querySelector('thead tr');
            const colspan = colspanElement ? colspanElement.children.length : 8; // Default a 8 si no encuentra el thead
            productTableBody.innerHTML = `<tr><td colspan="${colspan}" class="p-4 text-center text-gray-500">${noProductsMessage.textContent}</td></tr>`;
        }
        return; // Salir si no hay productos
    } else {
        if (noProductsMessage) {
            // No se oculta el mensaje de "no products" aquí, se sobrescribe el tbody
        }
    }

    // Obtener el rol del usuario actual para controlar la visibilidad de las acciones
    const currentUserRole = window.currentUser ? window.currentUser.role_name : null;
    const canEditOrDelete = currentUserRole === 'Administrador' || currentUserRole === 'Bodeguero';

    filteredProducts.forEach(product => {
        const row = document.createElement('tr');
        row.className = 'hover:bg-gray-50';
        row.innerHTML = `
            <td class="p-3">${product.id}</td>
            <td class="p-3">${product.sku}</td>
            <td class="p-3">${product.name}</td> <!-- Usar 'name' en lugar de 'nombre_producto' -->
            <td class="p-3">${window.formatCurrency(product.price)}</td> <!-- Usar 'price' en lugar de 'precio' -->
            <td class="p-3">${product.stock}</td>
            <td class="p-3">${product.category_name || 'Sin Categoría'}</td>
            <td class="p-3">${product.description || 'N/A'}</td> <!-- Usar 'description' en lugar de 'descripcion' -->
            <td class="p-3">
                <div class="flex items-center space-x-2">
                    ${canEditOrDelete ? `
                    <button class="edit-product-btn text-yellow-600 hover:text-yellow-800 p-1 rounded-md hover:bg-yellow-100 transition-colors" data-product-id="${product.id}" title="Editar Producto">
                        <span class="lucide" data-lucide="edit"></span>
                    </button>
                    <button class="delete-product-btn text-red-600 hover:text-red-800 p-1 rounded-md hover:bg-red-100 transition-colors" data-product-id="${product.id}" title="Eliminar Producto">
                        <span class="lucide" data-lucide="trash-2"></span>
                    </button>
                    ` : '<span class="text-slate-500 text-sm">Sin acciones</span>'}
                </div>
            </td>
        `;
        productTableBody.appendChild(row);
    });

    // Adjuntar event listeners a los botones de Editar y Eliminar SOLO SI son visibles
    if (canEditOrDelete) {
        productTableBody.querySelectorAll('.edit-product-btn').forEach(button => {
            button.addEventListener('click', (event) => {
                const id = event.currentTarget.dataset.productId;
                window.openProductModal(window.products.find(p => p.id == id));
            });
        });

        productTableBody.querySelectorAll('.delete-product-btn').forEach(button => {
            button.addEventListener('click', (event) => {
                const id = event.currentTarget.dataset.productId;
                window.deleteProduct(id);
            });
        });
    }

    if (window.lucide) {
        window.lucide.createIcons();
    }
};

/**
 * 
 * @param {Object} [product=null]
 */
window.openProductModal = function(product = null) {
    const productModal = document.getElementById('product-modal');
    const productForm = document.getElementById('product-form');
    const productModalTitle = document.getElementById('product-modal-title');
    const productIdInput = document.getElementById('product-id');
    const productNameInput = document.getElementById('product-name');
    const productSkuInput = document.getElementById('product-sku');
    const productPriceInput = document.getElementById('product-price');
    const productStockInput = document.getElementById('product-stock');
    const productCategorySelect = document.getElementById('product-category');
    const productDescriptionInput = document.getElementById('product-description');
    
    productForm.reset();
    productModal.classList.remove('hidden');
    productModal.classList.add('flex');

    if (product) {
        productIdInput.value = product.id;
        productModalTitle.textContent = 'Editar Producto';
        productNameInput.value = product.name || ''; 
        productSkuInput.value = product.sku || '';
        productPriceInput.value = product.price || 0; 
        productStockInput.value = product.stock || 0;
        productCategorySelect.value = product.category_id || '';
        productDescriptionInput.value = product.description || ''; 
    } else {
        productIdInput.value = '';
        productModalTitle.textContent = 'Añadir Nuevo Producto';
    }
    window.populateCategories(productCategorySelect, null);
    if (window.lucide) {
        window.lucide.createIcons();
    }
};

/**
 * Maneja el envío del formulario de producto (añadir o actualizar).
 */
window.handleProductFormSubmit = async function(event) {
    event.preventDefault();
    const productModal = document.getElementById('product-modal');
    const productId = document.getElementById('product-id').value;
    const isEditing = productId !== '';
    const action = isEditing ? 'update' : 'add';
    const url = `api/products.php?action=${action}` + (isEditing ? `&id=${productId}` : '');

    const payload = {
        name: document.getElementById('product-name').value.trim(),
        sku: document.getElementById('product-sku').value.trim(),
        price: parseFloat(document.getElementById('product-price').value),
        stock: parseInt(document.getElementById('product-stock').value),
        category_id: document.getElementById('product-category').value,
        description: document.getElementById('product-description').value.trim()
    };

    if (!payload.name || !payload.sku || isNaN(payload.price) || payload.price < 0 || isNaN(payload.stock) || payload.stock < 0 || !payload.category_id) {
        window.showToast('Por favor, rellena todos los campos obligatorios y asegúrate de que el precio y el stock sean válidos.', true);
        return;
    }

    try {
        const res = await fetch(url, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });
        const data = await res.json();

        if (res.ok) {
            window.showToast(data.message || (isEditing ? 'Producto actualizado exitosamente!' : 'Producto añadido exitosamente!'));
            productModal.classList.add('hidden');
            productModal.classList.remove('flex'); // Asegurarse de remover flex
            document.getElementById('product-form').reset();
            await window.loadDataFromAPI(); // Recargar todos los datos globales, incluyendo productos y categorías
            window.renderProductTable(document.getElementById('product-table-body')); // Re-renderizar la tabla de productos
        } else {
            window.showToast(data.error || 'Error al guardar producto.', true);
        }
    } catch (err) {
        console.error('Error de red al guardar producto:', err);
        window.showToast('Error de conexión al guardar producto.', true);
    }
};

/**
 * Elimina un producto de la base de datos.
 * @param {number} id - ID del producto a eliminar.
 */
window.deleteProduct = async function(id) {
    // Reemplazar confirm() con un modal personalizado para mejor UX
    if (!confirm('¿Está seguro de que desea eliminar este producto? Esta acción es irreversible.')) {
        return;
    }
    try {
        const res = await fetch(`api/products.php?action=delete&id=${id}`, {
            method: 'DELETE'
        });
        const data = await res.json();
        if (res.ok) {
            window.showToast(data.message || 'Producto eliminado exitosamente.');
            await window.loadDataFromAPI(); // Recargar productos y categorías
            window.renderProductTable(document.getElementById('product-table-body')); // Re-renderizar la tabla
        } else {
            window.showToast(data.error || 'Error al eliminar producto.', true);
        }
    } catch (error) {
        console.error('Error de red al eliminar producto:', error);
        window.showToast('Error de conexión al eliminar producto.', true);
    }
};

/**
 * Añade una nueva categoría de producto.
 * @param {string} categoryName - Nombre de la nueva categoría.
 */
window.addCategory = async function(categoryName) {
    try {
        const res = await fetch('api/products.php?action=add_category', { // Acción 'add_category' en products.php
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ name: categoryName })
        });
        const data = await res.json();
        if (res.ok) {
            window.showToast(data.message || 'Categoría añadida exitosamente.');
            document.getElementById('new-category-name').value = ''; // Limpiar input
            await window.loadDataFromAPI(); // Recargar categorías globales
            window.populateCategories(
                document.getElementById('product-category'),
                document.getElementById('product-category-filter')
            );
        } else {
            window.showToast(data.error || 'Error al añadir categoría.', true);
        }
    } catch (error) {
        console.error('Error de red al añadir categoría:', error);
        window.showToast('Error de conexión al añadir categoría.', true);
    }
};

/**
 * Inicializa el módulo de Productos, configura listeners y carga datos.
 */
window.initProductos = async () => {
    console.log('--- Iniciando initProductos ---');

    // Referencias a elementos DOM
    const productTableBody = document.getElementById('product-table-body');
    const productTableSearch = document.getElementById('product-table-search');
    const productCategoryFilter = document.getElementById('product-category-filter');
    const addProductBtn = document.getElementById('add-product-btn');
    const addCategoryBtn = document.getElementById('add-category-btn');
    const newCategoryNameInput = document.getElementById('new-category-name');
    const manageCategoriesSection = document.getElementById('manage-categories-section'); // Contenedor de la sección de categorías
    const productModal = document.getElementById('product-modal');
    const closeProductModalBtn = document.getElementById('close-product-modal-btn');
    const productForm = document.getElementById('product-form');
    const productCategorySelect = document.getElementById('product-category'); // Select de categoría en el modal de producto

    // Validar que los elementos esenciales existan
    if (!productTableBody || !productTableSearch || !productCategoryFilter || !addProductBtn || !productModal || !closeProductModalBtn || !productForm || !productCategorySelect || !addCategoryBtn || !newCategoryNameInput || !manageCategoriesSection) {
        console.error('Error: Algunos elementos principales del DOM de productos no se encontraron. Asegúrate de que los IDs sean correctos.');
        window.showToast('Error: No se pudo cargar la interfaz de productos correctamente.', true);
        return;
    }

    // --- Control de Acceso por Roles (RBAC) ---
    const currentUserRole = window.currentUser ? window.currentUser.role_name : null;

    // Ocultar botón "Añadir Producto" y sección de categorías si es "Vendedor"
    // Los vendedores solo pueden ver productos, no gestionarlos
    if (currentUserRole === 'Vendedor') {
        addProductBtn.classList.add('hidden');
        manageCategoriesSection.classList.add('hidden');
        // Los botones de editar/eliminar en la tabla se controlan en renderProductTable
    } else {
        addProductBtn.classList.remove('hidden');
        manageCategoriesSection.classList.remove('hidden');
    }

    // --- CONFIGURACIÓN DE EVENT LISTENERS ---
    
    // Abrir/Cerrar modal de producto
    addProductBtn.addEventListener('click', () => window.openProductModal());
    closeProductModalBtn.addEventListener('click', () => {
        productModal.classList.add('hidden');
        productModal.classList.remove('flex'); // Asegurarse de remover flex
    });

    // Envío del formulario de producto
    productForm.addEventListener('submit', (e) => window.handleProductFormSubmit(e));

    // Event listeners para búsqueda y filtro de categoría
    productTableSearch.addEventListener('input', () => window.renderProductTable(productTableBody));
    productCategoryFilter.addEventListener('change', () => window.renderProductTable(productTableBody));

    // Añadir categoría
    addCategoryBtn.addEventListener('click', () => {
        const categoryName = newCategoryNameInput.value.trim();
        if (categoryName) {
            window.addCategory(categoryName);
        } else {
            window.showToast('El nombre de la categoría no puede estar vacío.', true);
        }
    });

    // Cargar y renderizar productos y categorías al iniciar el módulo
    await window.loadDataFromAPI(); // Asegura que window.products y window.categories estén cargados
    window.populateCategories(productCategorySelect, productCategoryFilter);
    window.renderProductTable(productTableBody); // Pasa el tbody para renderizar
    
    // Actualizar iconos Lucide para esta sección
    if (window.lucide) {
        window.lucide.createIcons();
    }
};

    // Añadir categoría
    addCategoryBtn.addEventListener('click', () => {
        const categoryName = newCategoryNameInput.value.trim();
        if (categoryName) {
            window.addCategory(categoryName);
        } else {
            window.showToast('El nombre de la categoría no puede estar vacío.', true);
        }
    });

    // Cargar y renderizar productos y categorías al iniciar el módulo
    await window.loadDataFromAPI(); // Asegura que window.products y window.categories estén cargados
    window.populateCategories(productCategorySelect, productCategoryFilter);
    window.renderProductTable(productTableBody); // Pasa el tbody para renderizar
    
    // Actualizar iconos Lucide para esta sección
    if (window.lucide) {
        window.lucide.createIcons();
    }
};
