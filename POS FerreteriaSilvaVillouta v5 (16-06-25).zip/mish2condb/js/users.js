// js/users.js

// Envuelve todo el código del módulo en una función anónima de ejecución inmediata (IIFE)
// Esto crea un scope privado para todas las variables declaradas con let/const dentro de ella,
// evitando problemas de redeclaración al cargar el script múltiples veces.
(() => {
    // Variable global para almacenar el ID del usuario que se está editando
    let currentEditingUserId = null;

    // --- Referencias a elementos del DOM (se inicializan en initUsers) ---
    // Elementos de la tabla principal
    let usersTableBody;
    let userSearchInput;
    let noUsersMessage;
    let addUserBtn;

    // Elementos del modal de usuario (Add/Edit)
    let userModal;
    let closeModalBtn; // Botón de cancelar/cerrar
    let userModalTitle;
    let userForm;
    let userIdInput; // Hidden input for user ID
    let usernameInput;
    let fullNameInput;
    let emailInput;
    let passwordInput; // Changed from passwordFields to direct input
    let userRoleSelect;
    let userFormErrorMessage;
    let cancelUserBtn; // This is the same as closeModalBtn by default in HTML
    let saveUserBtn;

    /**
     * Función de inicialización principal para el módulo de Usuarios.
     * Esta función se ejecuta cuando la página de usuarios es cargada.
     */
    window.initUsers = async () => {
        console.log('--- Iniciando initUsers ---');

        // 1. Obtener todas las referencias a los elementos DOM localmente
        usersTableBody = document.getElementById('user-table-body');
        userSearchInput = document.getElementById('user-search-input');
        noUsersMessage = document.getElementById('no-users-message');
        addUserBtn = document.getElementById('add-user-btn');
        userModal = document.getElementById('user-modal');
        closeModalBtn = userModal ? userModal.querySelector('#close-user-modal-btn') : null; // Close X button
        userModalTitle = document.getElementById('user-modal-title');
        userForm = document.getElementById('user-form');
        userIdInput = document.getElementById('user-id'); // Hidden input
        usernameInput = document.getElementById('user-username'); // Corrected ID from 'username' to 'user-username'
        fullNameInput = document.getElementById('user-full-name'); // Corrected ID from 'full-name' to 'user-full-name'
        emailInput = document.getElementById('user-email'); // Corrected ID from 'email' to 'user-email'
        passwordInput = document.getElementById('user-password'); // Corrected ID from 'password' to 'user-password'
        userRoleSelect = document.getElementById('user-role');
        userFormErrorMessage = document.getElementById('user-form-error-message');
        cancelUserBtn = document.getElementById('cancel-user-btn'); // Cancel button in the form
        saveUserBtn = document.getElementById('save-user-btn');


        // --- Validar que los elementos principales existan ---
        const essentialElements = [
            usersTableBody, userSearchInput, noUsersMessage, addUserBtn,
            userModal, closeModalBtn, userModalTitle, userForm, userIdInput,
            usernameInput, fullNameInput, emailInput, passwordInput,
            userRoleSelect, userFormErrorMessage, cancelUserBtn, saveUserBtn
        ];

        const missingElementNames = [];
        essentialElements.forEach(element => {
            if (element === null) {
                // Aquí podrías intentar inferir el ID si la variable que lo apunta es nombrada por su ID
                // Pero un mensaje general sigue siendo útil.
                missingElementNames.push(`Elemento DOM (ID: ${element ? element.id : 'desconocido'})`);
            }
        });

        if (missingElementNames.length > 0) {
            console.error('Error: Faltan algunos elementos principales del DOM de usuarios. Asegúrate de que los IDs sean correctos. Elementos faltantes:', missingElementNames.join(', '));
            window.showToast('Error al iniciar módulo de usuarios. Faltan elementos clave.', true);
            return; // Detener la ejecución si faltan elementos críticos
        }
        console.log('✅ Todos los elementos DOM de usuarios encontrados y referenciados.');


        // --- FUNCIONES INTERNAS DEL MÓDULO DE USUARIOS ---

        /**
         * Carga los roles de usuario desde la API y popula el selector de roles.
         */
        async function loadRoles() {
            try {
                const response = await fetch('/api/roles.php?action=list');
                if (response.ok) {
                    const roles = await response.json();
                    if (userRoleSelect) {
                        userRoleSelect.innerHTML = '<option value="">Selecciona un Rol</option>';
                        roles.forEach(role => {
                            const option = document.createElement('option');
                            option.value = role.id;
                            option.textContent = role.name;
                            userRoleSelect.appendChild(option);
                        });
                    }
                } else {
                    console.error('Error al cargar roles:', response.status, await response.json());
                    window.showToast('Error al cargar roles de usuario.', true);
                }
            } catch (error) {
                console.error('Error de red al cargar roles:', error);
                window.showToast('Error de conexión al cargar roles de usuario.', true);
            }
        }

        /**
         * Renderiza la tabla de usuarios con los datos cargados, aplicando filtro de búsqueda.
         */
        window.renderUsersTable = () => { // Se expone globalmente para ser llamada desde main.js
            if (!usersTableBody || !noUsersMessage) {
                console.error('Elementos DOM para la tabla de usuarios no encontrados en renderUsersTable.');
                return;
            }

            usersTableBody.innerHTML = '';
            const searchTerm = userSearchInput.value.toLowerCase().trim();

            // Asumimos que window.users ya está cargado por main.js
            const filteredUsers = window.users ? window.users.filter(user => {
                const matchesUsername = user.username.toLowerCase().includes(searchTerm);
                const matchesFullName = user.full_name ? user.full_name.toLowerCase().includes(searchTerm) : false;
                const matchesEmail = user.email ? user.email.toLowerCase().includes(searchTerm) : false;
                const matchesRole = user.role_name ? user.role_name.toLowerCase().includes(searchTerm) : false;
                return matchesUsername || matchesFullName || matchesEmail || matchesRole;
            }) : [];


            if (filteredUsers.length === 0) {
                noUsersMessage.classList.remove('hidden');
            } else {
                noUsersMessage.classList.add('hidden');
                filteredUsers.forEach(user => {
                    const row = document.createElement('tr');
                    row.className = 'hover:bg-slate-50 transition-colors duration-150';
                    row.innerHTML = `
                        <td class="py-3 px-4 text-sm font-medium text-slate-800">${user.username}</td>
                        <td class="py-3 px-4 text-sm text-slate-700">${user.full_name || 'N/A'}</td>
                        <td class="py-3 px-4 text-sm text-slate-700">${user.email || 'N/A'}</td>
                        <td class="py-3 px-4 text-sm">
                            <span class="px-2 py-1 rounded-full text-xs font-semibold bg-purple-100 text-purple-700">
                                ${user.role_name || 'Sin Rol'}
                            </span>
                        </td>
                        <td class="py-3 px-4 text-center">
                            <button class="edit-user-btn text-blue-600 hover:text-blue-800 mr-2" data-id="${user.id}" title="Editar Usuario">
                                <svg class="w-5 h-5 inline-block" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-7-6l2-2m0 0l5 5m-5-5H11a2 2 0 00-2 2v2"></path></svg>
                            </button>
                            <button class="delete-user-btn text-red-600 hover:text-red-800" data-id="${user.id}" title="Eliminar Usuario">
                                <svg class="w-5 h-5 inline-block" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path></svg>
                            </button>
                        </td>
                    `;
                    usersTableBody.appendChild(row);
                });
            }
            if (window.lucide) {
                window.lucide.createIcons(); // Recargar iconos después de renderizar tabla
            }
        };

        /**
         * Abre el modal para añadir o editar un usuario.
         * @param {object} user - Objeto de usuario si se está editando, null si es nuevo.
         */
        const openUserModal = (user = null) => {
            userForm.reset();
            userFormErrorMessage.classList.add('hidden');
            passwordInput.setAttribute('required', 'required'); // Contraseña es requerida para nuevos usuarios
            currentEditingUserId = null; // Reiniciar para nueva creación

            if (user) {
                userModalTitle.textContent = 'Editar Usuario';
                currentEditingUserId = user.id;
                userIdInput.value = user.id; // Set hidden ID field
                usernameInput.value = user.username;
                fullNameInput.value = user.full_name || '';
                emailInput.value = user.email || '';
                userRoleSelect.value = user.role_id;
                passwordInput.removeAttribute('required'); // No requerir contraseña en edición
                passwordInput.placeholder = 'Dejar en blanco para mantener contraseña actual';
            } else {
                userModalTitle.textContent = 'Añadir Nuevo Usuario';
                passwordInput.placeholder = '';
            }

            userModal.classList.remove('hidden');
            userModal.classList.add('flex');
            const modalContent = document.getElementById('user-modal-content');
            if (modalContent) {
                modalContent.classList.remove('scale-95', 'opacity-0');
                modalContent.classList.add('scale-100', 'opacity-100');
            }
        };

        /**
         * Cierra el modal de usuario.
         */
        const closeUserModal = () => {
            if (userModal) {
                const modalContent = document.getElementById('user-modal-content');
                if (modalContent) {
                    modalContent.classList.remove('scale-100', 'opacity-100');
                    modalContent.classList.add('scale-95', 'opacity-0');
                    setTimeout(() => {
                        userModal.classList.add('hidden');
                        userModal.classList.remove('flex');
                    }, 300);
                }
            }
        };

        /**
         * Maneja el envío del formulario de usuario (añadir/editar).
         */
        const handleUserFormSubmit = async (event) => {
            event.preventDefault();
            userFormErrorMessage.classList.add('hidden');

            const userData = {
                username: usernameInput.value.trim(),
                full_name: fullNameInput.value.trim(),
                email: emailInput.value.trim(),
                role_id: parseInt(userRoleSelect.value)
            };

            // Solo añadir la contraseña si no está vacía (para edición) o si es un nuevo usuario
            if (passwordInput.value.length > 0) {
                userData.password = passwordInput.value;
            } else if (!currentEditingUserId) { // Si es un nuevo usuario y la contraseña está vacía
                userFormErrorMessage.textContent = 'La contraseña es obligatoria para nuevos usuarios.';
                userFormErrorMessage.classList.remove('hidden');
                return;
            }

            if (!userData.username || !userData.full_name || !userData.email || !userData.role_id) {
                userFormErrorMessage.textContent = 'Todos los campos marcados con * son obligatorios.';
                userFormErrorMessage.classList.remove('hidden');
                return;
            }

            let url = '/api/users.php?action=register';
            let method = 'POST';

            if (currentEditingUserId) {
                url = `/api/users.php?action=update&id=${currentEditingUserId}`;
                // En PHP, para simular PUT con FormData, se usa POST y se añade un campo _method
                method = 'POST';
                userData.id = currentEditingUserId; // Asegurar que el ID se envíe en el body para PUT
            }

            try {
                const fetchOptions = {
                    method: method,
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(userData)
                };

                const response = await fetch(url, fetchOptions);
                const data = await response.json();

                if (response.ok && data.success) {
                    window.showToast(data.message || 'Usuario guardado exitosamente.');
                    closeUserModal();
                    await window.loadDataFromAPI(); // Recargar datos globales para refrescar la lista de usuarios
                    window.renderUsersTable(); // Re-renderizar la tabla de usuarios
                } else {
                    userFormErrorMessage.textContent = data.error || 'Error al guardar usuario. Inténtelo de nuevo.';
                    userFormErrorMessage.classList.remove('hidden');
                    window.showToast(data.error || 'Error al guardar usuario.', true);
                }
            } catch (err) {
                console.error("Error de red al guardar usuario:", err);
                userFormErrorMessage.textContent = "Error de conexión al guardar usuario.";
                userFormErrorMessage.classList.remove('hidden');
                window.showToast("Error de conexión al guardar usuario.", true);
            }
        };

        /**
         * Maneja la eliminación de un usuario.
         * @param {number} userId - ID del usuario a eliminar.
         */
        const handleDeleteUser = async (userId) => {
            // Impedir que un usuario se elimine a sí mismo
            if (window.currentUser && window.currentUser.id === userId) {
                window.showToast('No puedes eliminar tu propia cuenta de usuario.', true);
                return;
            }

            // Usar una confirmación personalizada en lugar de alert/confirm
            const confirmDelete = window.confirm('¿Estás seguro de que deseas eliminar este usuario? Esta acción es irreversible.');
            if (!confirmDelete) {
                return;
            }

            try {
                const response = await fetch(`/api/users.php?action=delete&id=${userId}`, {
                    method: 'DELETE',
                });
                const data = await response.json();

                if (response.ok && data.message) {
                    window.showToast(data.message || 'Usuario eliminado exitosamente.');
                    await window.loadDataFromAPI(); // Recargar datos globales para refrescar la lista de usuarios
                    window.renderUsersTable(); // Re-renderizar la tabla de usuarios
                } else {
                    window.showToast(data.error || 'Error al eliminar usuario.', true);
                }
            } catch (error) {
                console.error('Error de red al eliminar usuario:', error);
                window.showToast('Error de conexión al eliminar usuario.', true);
            }
        };

        // --- Event Listeners ---
        if (addUserBtn) addUserBtn.addEventListener('click', () => openUserModal());
        if (closeModalBtn) closeModalBtn.addEventListener('click', closeUserModal);
        if (cancelUserBtn) cancelUserBtn.addEventListener('click', closeUserModal); // Ensure this is also wired up
        if (userForm) userForm.addEventListener('submit', handleUserFormSubmit);

        // Delegación de eventos para los botones de editar/eliminar en la tabla
        if (usersTableBody) {
            usersTableBody.addEventListener('click', (e) => {
                const editBtn = e.target.closest('.edit-user-btn');
                const deleteBtn = e.target.closest('.delete-user-btn');
                if (editBtn) {
                    const userId = parseInt(editBtn.dataset.id);
                    const user = window.users.find(u => u.id === userId);
                    if (user) openUserModal(user);
                } else if (deleteBtn) {
                    const userId = parseInt(deleteBtn.dataset.id);
                    handleDeleteUser(userId);
                }
            });
        }

        // Event listener para búsqueda/filtrado de usuarios
        if (userSearchInput) {
            userSearchInput.addEventListener('input', window.renderUsersTable);
        }

        // --- Carga inicial de datos al iniciar el módulo ---
        await loadRoles(); // Cargar los roles disponibles
        window.renderUsersTable(); // Renderizar la tabla de usuarios
    };
})(); // Fin del IIFE
