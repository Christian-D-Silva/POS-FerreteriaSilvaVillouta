// js/main.js

document.addEventListener('DOMContentLoaded', () => {
    // Inicialización de iconos Lucide al cargar el DOM
    // Esto asegura que todos los iconos en el HTML inicial se rendericen.
    if (window.lucide) {
        window.lucide.createIcons();
    }

    // --- DATOS GLOBALES (Ahora se cargarán desde la DB, pero se mantienen como "cache" local) ---
    // Inicializar como arrays vacíos
    window.categories = [];
    window.products = [];
    window.salesHistory = []; // Esto se cargará desde la DB
    window.clients = []; // Nuevo para clientes
    window.cart = []; // El carrito sigue siendo local al usuario
    window.currentUser = null; // Información del usuario loggeado
    window.users = []; // Para la gestión de usuarios
    window.roles = []; // Para los roles de usuario
    window.adquisitions = []; // Nuevo para adquisiciones
    window.suppliers = []; // Nuevo para proveedores

    // Referencias a elementos DOM que podrían existir globalmente en index.html
    const loginPage = document.getElementById('login-page');
    const mainApp = document.getElementById('main-app');
    const loginForm = document.getElementById('login-form');
    const logoutBtn = document.getElementById('logout-btn');
    const mainContentArea = document.getElementById('main-content-area');
    const sidebarNav = document.getElementById('sidebar-nav');
    const currentUserSpan = document.getElementById('current-user-info'); // Para mostrar el usuario loggeado
    const loginErrorMessage = document.getElementById('login-error-message'); // Mensaje de error de login
    const toastContainer = document.getElementById('toast'); // Referencia al toast existente en index.html

    // --- FUNCIONES DE UTILIDAD ---

    /**
     * Muestra un mensaje de "toast" (notificación temporal).
     * @param {string} message - El mensaje a mostrar.
     * @param {boolean} isError - Si es true, el toast será rojo (error), de lo contrario verde (éxito/info).
     */
    window.showToast = (message, isError = false) => {
        if (!toastContainer) {
            console.error('Toast container not found!');
            return;
        }

        toastContainer.textContent = message;
        // Reinicia las clases de animación
        toastContainer.classList.remove('bg-green-500', 'bg-red-500', 'hidden', 'animate-slideIn', 'opacity-0', 'opacity-100');
        // Agrega las clases de color y animación
        toastContainer.classList.add(isError ? 'bg-red-500' : 'bg-green-500');
        
        // Mostrar el toast quitando 'hidden' y añadiendo la animación
        toastContainer.classList.remove('hidden');
        toastContainer.classList.add('animate-slideIn', 'opacity-100'); // Asegura que opacity-100 esté presente para la animación CSS

        setTimeout(() => {
            // Remueve la clase de animación para que se pueda volver a aplicar
            toastContainer.classList.remove('animate-slideIn', 'opacity-100');
            // Oculta el toast
            toastContainer.classList.add('hidden', 'opacity-0'); // Oculta y asegura opacidad 0 para la próxima aparición
        }, 3000); // Se muestra por 3 segundos (la duración de la animación en CSS)
    };

    /**
     * Formatea un número como moneda chilena (CLP).
     * @param {number} amount - El monto a formatear.
     * @returns {string} El monto formateado como CLP.
     */
    window.formatCurrency = (amount) => {
        return new Intl.NumberFormat('es-CL', {
            style: 'currency',
            currency: 'CLP',
            minimumFractionDigits: 0, // CLP no usa decimales
            maximumFractionDigits: 0
        }).format(amount);
    };


    /**
     * Alterna la visibilidad de la página de login y la aplicación principal.
     */
    window.showLoginPage = () => {
        if (loginPage) loginPage.classList.remove('hidden');
        if (mainApp) mainApp.classList.add('hidden');
        // Limpiar formulario y mensajes de error al mostrar el login
        if (loginForm) loginForm.reset();
        if (loginErrorMessage) loginErrorMessage.classList.add('hidden');
    };

    window.showMainApp = () => {
        if (loginPage) loginPage.classList.add('hidden');
        if (mainApp) mainApp.classList.remove('hidden');
    };

    /**
     * Carga contenido HTML dinámicamente en el área principal de la aplicación.
     * @param {string} pageName - El nombre del archivo HTML a cargar (ej. 'dashboard').
     */
    window.loadPage = async (pageName) => {
        console.log(`DEBUG: Intentando cargar /pages/${pageName}.html`); // Nuevo log de depuración
        try {
            const response = await fetch(`/pages/${pageName}.html`); 
            if (!response.ok) {
                // Si la respuesta no es OK (ej. 404), lanzar un error con el status
                console.error(`ERROR: Fallo al cargar /pages/${pageName}.html - Status: ${response.status}`);
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            const html = await response.text();
            if (mainContentArea) {
                mainContentArea.innerHTML = html;
                console.log(`Contenido de pages/${pageName}.html cargado y renderizado en DOM.`); // Debug log
                
                // Usamos requestAnimationFrame para asegurar que el DOM esté completamente renderizado
                // antes de intentar obtener los elementos e inicializar el módulo.
                requestAnimationFrame(() => {
                    // Mapeo de nombres de página a funciones de inicialización
                    const initFunctions = {
                        'dashboard': window.initDashboard,
                        'products': window.initProductos, // Asegúrate que estas funciones existan globalmente
                        'sales': window.initVentas,       // en sus respectivos archivos JS.
                        'clients': window.initClientes,
                        'adquisitions': window.initAdquisiciones,
                        'historial': window.initHistorial,
                        'users': window.initUsers
                    };

                    const initFunc = initFunctions[pageName];
                    if (typeof initFunc === 'function') {
                        console.log(`DEBUG: Llamando a ${initFunc.name || 'función anónima'} para la página ${pageName}...`);
                        initFunc(); // Llamar a la función de inicialización del módulo
                    } else {
                        console.warn(`WARNING: No se encontró función de inicialización para la página ${pageName}. Asegúrate de que el script JS correspondiente esté cargado y defina 'window.init${pageName.charAt(0).toUpperCase() + pageName.slice(1)}'.`);
                    }
                    // Después de cargar e inicializar la página, crear los iconos de Lucide
                    if (window.lucide) {
                        window.lucide.createIcons();
                    }
                });
            }
        } catch (error) {
            console.error(`CRITICAL ERROR: Error al cargar la página ${pageName}:`, error);
            mainContentArea.innerHTML = `<div class="text-center text-red-600 py-16">
                                            <p class="text-2xl font-bold">Error al cargar el contenido.</p>
                                            <p class="text-lg">Por favor, inténtalo de nuevo más tarde o verifica la ruta del archivo: <code>/pages/${pageName}.html</code></p>
                                            <p class="text-sm">Detalle técnico: ${error.message}</p>
                                          </div>`;
            window.showToast(`Error al cargar la página ${pageName}.`, true);
        }
    };

    /**
     * Función para cambiar de página desde la barra lateral.
     * Añade o remueve la clase 'active' para resaltado visual.
     * @param {string} page - El nombre de la página a la que cambiar.
     */
    window.switchPage = (page) => {
        console.log(`DEBUG: Solicitando cambio a la página: ${page}`);
        window.loadPage(page);

        // Actualizar estado activo en la barra lateral
        document.querySelectorAll('.nav-link').forEach(link => {
            link.classList.remove('bg-blue-700', 'text-white'); // Quitar estilo activo
            link.classList.add('text-slate-200', 'hover:bg-slate-700'); // Añadir estilo inactivo
        });

        // Añadir la clase 'active' al enlace clickeado
        const activeLink = document.querySelector(`.nav-link[data-page="${page}"]`);
        if (activeLink) {
            activeLink.classList.remove('text-slate-200', 'hover:bg-slate-700');
            activeLink.classList.add('bg-blue-700', 'text-white'); // Añadir estilo activo
        }
    };


    // --- GESTIÓN DE DATOS (Carga inicial desde la API) ---

    /**
     * Carga todos los datos maestros desde la API al inicio de la aplicación.
     */
    window.loadDataFromAPI = async () => {
        console.log('DEBUG: Iniciando carga de datos desde API...');
        try {
            // Cargar categorías
            const categoriesResponse = await fetch('/api/products.php?action=list_categories');
            if (categoriesResponse.ok) {
                window.categories = await categoriesResponse.json();
                console.log('Categorías cargadas:', window.categories);
            } else {
                console.error('ERROR al cargar categorías:', categoriesResponse.status, await categoriesResponse.json());
            }

            // Cargar productos
            const productsResponse = await fetch('/api/products.php?action=list');
            if (productsResponse.ok) {
                window.products = await productsResponse.json();
                console.log('Productos cargados:', window.products);
            } else {
                console.error('ERROR al cargar productos:', productsResponse.status, await productsResponse.json());
            }

            // Cargar clientes
            const clientsResponse = await fetch('/api/clients.php?action=list');
            if (clientsResponse.ok) {
                window.clients = await clientsResponse.json();
                console.log('Clientes cargados:', window.clients);
            } else {
                console.error('ERROR al cargar clientes:', clientsResponse.status, await clientsResponse.json());
            }

            // Cargar usuarios (solo si el usuario actual es admin, lo manejaremos en el backend también)
            const usersResponse = await fetch('/api/users.php?action=list');
            if (usersResponse.ok) {
                window.users = await usersResponse.json();
                console.log('Usuarios cargados (si es admin):', window.users);
            } else {
                console.error('ERROR al cargar usuarios:', usersResponse.status, await usersResponse.json());
            }

            // Cargar roles (solo si el usuario actual es admin)
            const rolesResponse = await fetch('/api/roles.php?action=list');
            if (rolesResponse.ok) {
                window.roles = await rolesResponse.json();
                console.log('Roles cargados (si es admin):', window.roles);
            } else {
                console.error('ERROR al cargar roles:', rolesResponse.status, await rolesResponse.json());
            }

            // Cargar adquisiciones
            const acquisitionsResponse = await fetch('/api/adquisiciones.php?action=list');
            if (acquisitionsResponse.ok) {
                window.adquisitions = await acquisitionsResponse.json();
                console.log('Adquisiciones cargadas:', window.adquisitions);
            } else {
                console.error('ERROR al cargar adquisiciones:', acquisitionsResponse.status, await acquisitionsResponse.json());
            }

            // Cargar proveedores
            const suppliersResponse = await fetch('/api/proveedores.php?action=list');
            if (suppliersResponse.ok) {
                window.suppliers = await suppliersResponse.json();
                console.log('Proveedores cargados:', window.suppliers);
            } else {
                console.error('ERROR al cargar proveedores:', suppliersResponse.status, await suppliersResponse.json());
            }

            // Cargar historial de ventas (CORREGIDO: action=list)
            const salesHistoryResponse = await fetch('/api/sales.php?action=list');
            if (salesHistoryResponse.ok) {
                window.salesHistory = await salesHistoryResponse.json();
                console.log('Historial de ventas cargado:', window.salesHistory);
            } else {
                console.error('ERROR al cargar historial de ventas:', salesHistoryResponse.status, await salesHistoryResponse.json());
            }

            console.log('DEBUG: Carga de datos de API completada.');

        } catch (error) {
            console.error('CRITICAL ERROR: Error de red al cargar datos de la API:', error);
            window.showToast('Error de conexión. No se pudieron cargar todos los datos.', true);
        }
    };


    // --- GESTIÓN DE AUTENTICACIÓN ---

    /**
     * Maneja el envío del formulario de login.
     */
    if (loginForm) {
        loginForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const username = loginForm.username.value;
            const password = loginForm.password.value;
            console.log('DEBUG: Intentando iniciar sesión para usuario:', username);

            try {
                const response = await fetch('/api/auth.php?action=login', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({ username, password }),
                });

                const data = await response.json();
                console.log('DEBUG: Respuesta de login recibida:', data);

                if (response.ok && data.authenticated) {
                    window.currentUser = {
                        id: data.user.id, 
                        username: data.user.username,
                        fullName: data.user.full_name,
                        roleId: data.user.role_id,
                        roleName: data.user.role_name
                    };
                    window.showMainApp();
                    await window.loadDataFromAPI(); // Cargar datos iniciales
                    window.switchPage('dashboard'); // Cargar dashboard por defecto
                    if (currentUserSpan) { 
                        currentUserSpan.textContent = `Bienvenido, ${window.currentUser.fullName || window.currentUser.username} (${window.currentUser.roleName || 'Rol Desconocido'})`;
                    }
                    window.showToast('Inicio de sesión exitoso!');
                    if (loginErrorMessage) loginErrorMessage.classList.add('hidden'); // Ocultar mensaje de error
                } else {
                    console.error('ERROR: Fallo de autenticación:', data.error);
                    if (loginErrorMessage) {
                        loginErrorMessage.textContent = data.error || 'Credenciales incorrectas.';
                        loginErrorMessage.classList.remove('hidden');
                    }
                    window.showToast(data.error || 'Fallo en el inicio de sesión.', true);
                }
            } catch (error) {
                console.error('CRITICAL ERROR: Error de red o parseo JSON al iniciar sesión:', error);
                if (loginErrorMessage) {
                    loginErrorMessage.textContent = 'Error de conexión. Inténtelo de nuevo.';
                    loginErrorMessage.classList.remove('hidden');
                }
                window.showToast('Error de conexión. Inténtelo de nuevo.', true);
            }
        });
    }

    /**
     * Maneja el logout del usuario.
     */
    if (logoutBtn) {
        logoutBtn.addEventListener('click', async () => {
            console.log('DEBUG: Intentando cerrar sesión.');
            try {
                const response = await fetch('/api/auth.php?action=logout', {
                    method: 'POST',
                });
                const data = await response.json();
                console.log('DEBUG: Respuesta de logout recibida:', data);
                if (response.ok && data.message) { 
                    window.currentUser = null;
                    window.cart = []; // Vaciar carrito al cerrar sesión
                    window.showLoginPage();
                    window.showToast('Sesión cerrada exitosamente.', false);
                } else {
                    console.error('ERROR: Fallo al cerrar sesión:', data.error);
                    window.showToast(data.error || 'Error al cerrar sesión.', true);
                }
            } catch (error) {
                console.error('CRITICAL ERROR: Error de red o parseo JSON al cerrar sesión:', error);
                window.showToast('Error de conexión al cerrar sesión.', true);
            }
        });
    }

    /**
     * Verifica el estado de login al cargar la aplicación.
     */
    window.checkLoginStatus = async () => {
        console.log('DEBUG: Verificando estado de login...');
        try {
            const response = await fetch('/api/auth.php?action=status');
            const data = await response.json();
            console.log('DEBUG: Respuesta de estado de login:', data);

            if (response.ok && data.logged_in) {
                // Si ya está loggeado, actualizamos la información global del usuario
                window.currentUser = {
                    id: data.user_id,
                    username: data.username,
                    fullName: data.full_name || data.username, 
                    roleId: data.role_id,
                    roleName: data.role_name || 'Desconocido' 
                };

                if (currentUserSpan) {
                    currentUserSpan.textContent = `Bienvenido, ${window.currentUser.fullName} (${window.currentUser.roleName})`;
                }
                console.log('DEBUG: Usuario autenticado. Mostrando aplicación principal.');
                window.showMainApp(); // Mostrar la app si ya está loggeado
                await window.loadDataFromAPI(); // Cargar datos iniciales
                window.switchPage('dashboard'); // Cargar dashboard por defecto
            } else {
                console.log('DEBUG: Usuario no autenticado. Mostrando página de login.');
                window.showLoginPage(); // Mostrar login si no está loggeado
            }
        } catch (error) {
            console.error('CRITICAL ERROR: Error de red o parseo JSON al verificar estado de login:', error);
            window.showToast('No se pudo verificar la sesión. Intente recargar.', true);
            window.showLoginPage(); // Por seguridad, mostrar login en caso de error
        }
    };

    // --- MANEJADORES DE EVENTOS ---
    // Navegación por la barra lateral
    if (sidebarNav) {
        sidebarNav.addEventListener('click', (e) => {
            const targetButton = e.target.closest('.nav-link');
            if (targetButton) {
                const page = targetButton.dataset.page;
                console.log(`DEBUG: Clic en botón de navegación para la página: ${page}`); // Log de depuración
                window.switchPage(page);
            }
        });
    }

    // Ejecutar la verificación de login al cargar el DOM
    window.checkLoginStatus();
});
