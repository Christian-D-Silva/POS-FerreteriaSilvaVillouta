// js/historial.js

// Envuelve todo el código del módulo en una función anónima de ejecución inmediata (IIFE)
// Esto crea un scope privado para todas las variables declaradas con let/const dentro de ella,
// evitando problemas de redeclaración al cargar el script múltiples veces.
(() => {
    // Referencias a elementos del DOM (se inicializan en initHistorial)
    let salesHistorySearchInput;
    let salesHistoryDocumentTypeFilter;
    let salesHistoryTableBody;
    let noSalesMessage;

    // Detalles del modal
    let saleDetailsModal;
    let closeSaleDetailsModalBtn;
    let detailSaleIdSpan;
    let detailSaleDateSpan;
    let detailClientNameSpan;
    let detailDocumentTypeSpan;
    let detailDocumentNumberSpan;
    let detailUserNameSpan;
    let detailProductsListBody;
    let detailSaleSubtotalSpan;
    let detailSaleDiscountSpan;
    let detailSaleTotalSpan;

    /**
     * Inicializa el módulo de Historial de Ventas, obteniendo referencias a los elementos DOM
     * y adjuntando todos los event listeners. Se llama desde main.js.
     * Esta función se expone globalmente.
     */
    window.initHistorial = async () => {
        console.log('Inicializando Módulo de Historial de Ventas...');

        // Obtener referencias a los elementos del DOM
        salesHistorySearchInput = document.getElementById('sales-history-search-input');
        salesHistoryDocumentTypeFilter = document.getElementById('sales-history-document-type-filter');
        salesHistoryTableBody = document.getElementById('sales-history-table-body');
        noSalesMessage = document.getElementById('no-sales-message');

        saleDetailsModal = document.getElementById('sale-details-modal');
        closeSaleDetailsModalBtn = document.getElementById('close-sale-details-modal-btn');
        detailSaleIdSpan = document.getElementById('detail-sale-id');
        detailSaleDateSpan = document.getElementById('detail-sale-date');
        detailClientNameSpan = document.getElementById('detail-client-name');
        detailDocumentTypeSpan = document.getElementById('detail-document-type');
        detailDocumentNumberSpan = document.getElementById('detail-document-number');
        detailUserNameSpan = document.getElementById('detail-user-name');
        detailProductsListBody = document.getElementById('detail-products-list');
        detailSaleSubtotalSpan = document.getElementById('detail-sale-subtotal');
        detailSaleDiscountSpan = document.getElementById('detail-sale-discount');
        detailSaleTotalSpan = document.getElementById('detail-sale-total');

        // --- Validar que los elementos principales existan ---
        const essentialElements = [
            salesHistorySearchInput, salesHistoryTableBody, noSalesMessage,
            saleDetailsModal, closeSaleDetailsModalBtn, detailSaleIdSpan,
            detailSaleDateSpan, detailClientNameSpan, detailDocumentTypeSpan,
            detailUserNameSpan, detailProductsListBody, detailSaleSubtotalSpan,
            detailSaleTotalSpan, detailSaleDiscountSpan,
            salesHistoryDocumentTypeFilter
        ];

        const missingElementNames = [];
        essentialElements.forEach((el, index) => {
            if (el === null) {
                // Para una depuración más específica, podríamos mapear los IDs aquí
                // Por ahora, un mensaje genérico es suficiente ya que el nombre de la variable
                // interna no ayuda si el ID no está en el HTML.
                missingElementNames.push(`Elemento DOM [${index}] no encontrado`); 
            }
        });

        if (missingElementNames.length > 0) {
            console.error('Faltan referencias a elementos del DOM en historial.js. Asegúrate de que historial.html esté cargado correctamente y los IDs sean correctos. Elementos faltantes:', missingElementNames.join(', '));
            window.showToast('Error al iniciar módulo de historial. Faltan elementos clave.', true);
            return; // Detener la inicialización si faltan elementos críticos
        }
        console.log('✅ Todos los elementos DOM para el historial de ventas encontrados.');

        // --- CONFIGURACIÓN INICIAL Y LISTENERS ---
        renderSalesHistoryTable(); // Renderizar la tabla por primera vez

        // Event Listeners para filtros
        salesHistorySearchInput.addEventListener('input', renderSalesHistoryTable);
        salesHistoryDocumentTypeFilter.addEventListener('change', renderSalesHistoryTable);

        // Event listener para abrir detalles de venta
        salesHistoryTableBody.addEventListener('click', (e) => {
            const viewBtn = e.target.closest('.view-sale-details-btn');
            if (viewBtn) {
                const saleId = parseInt(viewBtn.dataset.id);
                openSaleDetailsModal(saleId);
            }
        });

        // Event listener para cerrar el modal de detalles
        closeSaleDetailsModalBtn.addEventListener('click', closeSaleDetailsModal);

        // Actualizar iconos Lucide para esta sección (Asegúrate de que Lucide se cargue en index.html)
        if (window.lucide) {
            window.lucide.createIcons();
        }
    };

    /**
     * Renderiza la tabla de historial de ventas, aplicando filtros de búsqueda y tipo de documento.
     */
    function renderSalesHistoryTable() {
        if (!salesHistoryTableBody || !noSalesMessage) {
            console.error('Elementos DOM para la tabla de historial no encontrados en renderSalesHistoryTable.');
            return;
        }

        salesHistoryTableBody.innerHTML = '';
        const searchTerm = salesHistorySearchInput.value.toLowerCase().trim();
        const documentTypeFilter = salesHistoryDocumentTypeFilter.value;

        const filteredSales = window.salesHistory.filter(sale => {
            const matchesSearch = (sale.id && sale.id.toString().includes(searchTerm)) ||
                                  (sale.client_name && sale.client_name.toLowerCase().includes(searchTerm)) ||
                                  (sale.user_name && sale.user_name.toLowerCase().includes(searchTerm)) ||
                                  (sale.document_number && sale.document_number.toLowerCase().includes(searchTerm)); 
            const matchesDocumentType = documentTypeFilter === 'all' || sale.document_type === documentTypeFilter;
            return matchesSearch && matchesDocumentType;
        });

        if (filteredSales.length === 0) {
            noSalesMessage.classList.remove('hidden');
        } else {
            noSalesMessage.classList.add('hidden');
            filteredSales.forEach(sale => {
                const row = document.createElement('tr');
                row.className = 'hover:bg-slate-50 transition-colors duration-150';
                row.innerHTML = `
                    <td class="py-3 px-4 text-sm font-medium text-slate-800">#${sale.id}</td>
                    <td class="py-3 px-4 text-sm text-slate-700">${new Date(sale.sale_date).toLocaleDateString()}</td>
                    <td class="py-3 px-4 text-sm text-slate-700">${sale.client_name || 'Consumidor Final'}</td>
                    <td class="py-3 px-4 text-sm text-slate-700">${sale.document_type || 'N/A'}</td>
                    <td class="py-3 px-4 text-sm text-right font-semibold text-green-600">${window.formatCurrency(sale.total_amount)}</td>
                    <td class="py-3 px-4 text-sm text-slate-600">${sale.user_name || 'Desconocido'}</td>
                    <td class="py-3 px-4 text-center">
                        <button class="view-sale-details-btn text-blue-600 hover:text-blue-800 transition-colors duration-200"
                                data-id="${sale.id}" title="Ver Detalles">
                            <svg class="w-5 h-5 inline-block" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"></path><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"></path></svg>
                        </button>
                    </td>
                `;
                salesHistoryTableBody.appendChild(row);
            });
        }
        if (window.lucide) {
            window.lucide.createIcons(); // Recargar iconos después de renderizar tabla
        }
    }

    /**
     * Abre el modal de detalles de venta con la información de una venta específica.
     * @param {number} saleId - El ID de la venta a mostrar.
     */
    async function openSaleDetailsModal(saleId) {
        try {
            const response = await fetch(`/api/sales.php?action=details&id=${saleId}`);
            if (!response.ok) {
                throw new Error(`Error al obtener detalles de venta: ${response.status}`);
            }
            const sale = await response.json();

            if (!sale) {
                window.showToast('Detalles de venta no encontrados.', true);
                return;
            }

            // Rellenar el modal con los datos de la venta
            detailSaleIdSpan.textContent = `#${sale.id}`;
            detailSaleDateSpan.textContent = new Date(sale.sale_date).toLocaleDateString();
            detailClientNameSpan.textContent = sale.client_name || 'Consumidor Final';
            detailDocumentTypeSpan.textContent = sale.document_type || 'N/A';
            detailDocumentNumberSpan.textContent = sale.document_number || 'N/A'; // Asegurarse de que la API lo devuelva
            detailUserNameSpan.textContent = sale.user_name || 'Desconocido';
            detailSaleSubtotalSpan.textContent = window.formatCurrency(sale.subtotal_amount);
            detailSaleDiscountSpan.textContent = window.formatCurrency(sale.discount_amount);
            detailSaleTotalSpan.textContent = window.formatCurrency(sale.total_amount);

            // Rellenar la tabla de productos de la venta
            detailProductsListBody.innerHTML = '';
            if (sale.items && Array.isArray(sale.items) && sale.items.length > 0) {
                sale.items.forEach(item => {
                    const row = document.createElement('tr');
                    row.innerHTML = `
                        <td class="py-2 px-3 text-sm">${item.product_name} (SKU: ${item.product_sku})</td>
                        <td class="py-2 px-3 text-center text-sm">${item.quantity}</td>
                        <td class="py-2 px-3 text-right text-sm">${window.formatCurrency(item.price_at_sale)}</td>
                        <td class="py-2 px-3 text-right text-sm font-medium">${window.formatCurrency(item.item_total)}</td>
                    `;
                    detailProductsListBody.appendChild(row);
                });
            } else {
                detailProductsListBody.innerHTML = '<tr><td colspan="4" class="text-center py-3 text-slate-500">No hay productos en esta venta.</td></tr>';
            }

            // Mostrar el modal
            saleDetailsModal.classList.remove('hidden');
            saleDetailsModal.classList.add('flex');
            const modalContent = document.getElementById('sale-details-modal-content');
            if (modalContent) {
                modalContent.classList.remove('scale-95', 'opacity-0');
                modalContent.classList.add('scale-100', 'opacity-100');
            }

        } catch (error) {
            console.error('Error al abrir modal de detalles de venta:', error);
            window.showToast('Error al cargar detalles de venta.', true);
        }
    }

    /**
     * Cierra el modal de detalles de venta.
     */
    function closeSaleDetailsModal() {
        if (saleDetailsModal) {
            const modalContent = document.getElementById('sale-details-modal-content');
            if (modalContent) {
                modalContent.classList.remove('scale-100', 'opacity-100');
                modalContent.classList.add('scale-95', 'opacity-0');
                setTimeout(() => {
                    saleDetailsModal.classList.add('hidden');
                    saleDetailsModal.classList.remove('flex');
                }, 300); // Duración de la transición
            }
        }
    }
})(); // Fin del IIFE
