// js/adquisiciones.js

// Variables globales para el estado del módulo de Adquisiciones
let currentAcquisitionItems = []; // Array para almacenar los productos añadidos a la adquisición
let currentEditingAcquisitionId = null; // Para futura edición (no implementado en este set)
let currentEditingSupplierId = null; // Para la edición de proveedores

// --- Referencias a elementos DOM (se inicializan en initAdquisiciones) ---
let addAcquisitionBtn;
let acquisitionSearchInput;
let acquisitionTableBody;
let noAcquisitionsMessage;
let manageSuppliersBtn;

// Acquisition Modal elements
let acquisitionModal;
let acquisitionModalTitle;
let closeAcquisitionModalBtn;
let acquisitionForm;
let acquisitionSupplierSelect;
let acquisitionInvoiceNumberInput;
let acquisitionPurchaseDateInput;
let acquisitionDueDateInput;
let acquisitionPaymentStatusSelect;
let acquisitionInvoiceFileInput;
let currentInvoiceFileLink;
let addAcquisitionProductSelect;
let addAcquisitionQtyInput;
let addAcquisitionCostInput;
let addProductToAcquisitionBtn;
let acquisitionItemsList;
let noAcquisitionItemsMessage;
let acquisitionTotalAmountSpan;
let acquisitionFormErrorMessage;
let cancelAcquisitionBtn;
let saveAcquisitionBtn;

// Acquisition Details Modal elements
let acquisitionDetailsModal;
let closeAcquisitionDetailsModalBtn;
let detailInvoiceNumberSpan;
let detailSupplierNameSpan;
let detailPurchaseDateSpan;
let detailDueDateSpan;
let detailPaymentStatusSpan;
let detailUserNameSpan;
let detailInvoiceFileRow;
let detailInvoiceFileLink;
let detailAcquisitionProductsList;
let detailAcquisitionTotalSpan;
let editAcquisitionBtn;
let deleteAcquisitionBtn;

// Supplier Management Modal elements
let supplierManagementModal;
let closeSupplierManagementModalBtn;
let addSupplierBtn;
let supplierTableBody;
let noSuppliersMessage;

// Supplier Modal elements
let supplierModal;
let supplierModalTitle;
let closeSupplierModalBtn;
let supplierForm;
let supplierRazonSocialInput;
let supplierRutInput;
let supplierDireccionInput;
let supplierTelefonoInput;
let supplierEmailInput;
let supplierContactoNombreInput;
let supplierContactoTelefonoInput;
let supplierFormErrorMessage;
let cancelSupplierEditBtn;
let saveSupplierBtn;


/**
 * Inicializa el módulo de Adquisiciones, obteniendo referencias a los elementos DOM
 * y adjuntando todos los event listeners. Se llama desde main.js.
 */
window.initAdquisiciones = async () => {
    console.log('Inicializando Módulo de Adquisiciones...');

    // Usamos requestAnimationFrame para asegurarnos de que el DOM esté completamente cargado y renderizado
    requestAnimationFrame(async () => {
        // --- Obtener referencias a los elementos DOM principales ---
        addAcquisitionBtn = document.getElementById('add-acquisition-btn');
        acquisitionSearchInput = document.getElementById('acquisition-search-input');
        acquisitionTableBody = document.getElementById('acquisition-table-body');
        noAcquisitionsMessage = document.getElementById('no-acquisitions-message');
        manageSuppliersBtn = document.getElementById('manage-suppliers-btn');

        // Acquisition Modal
        acquisitionModal = document.getElementById('acquisition-modal');
        acquisitionModalTitle = document.getElementById('acquisition-modal-title');
        closeAcquisitionModalBtn = document.getElementById('close-acquisition-modal-btn');
        acquisitionForm = document.getElementById('acquisition-form');
        acquisitionSupplierSelect = document.getElementById('acquisition-supplier');
        acquisitionInvoiceNumberInput = document.getElementById('acquisition-invoice-number');
        acquisitionPurchaseDateInput = document.getElementById('acquisition-purchase-date');
        acquisitionDueDateInput = document.getElementById('acquisition-due-date');
        acquisitionPaymentStatusSelect = document.getElementById('acquisition-payment-status');
        acquisitionInvoiceFileInput = document.getElementById('acquisition-invoice-file');
        currentInvoiceFileLink = document.getElementById('current-invoice-file');
        addAcquisitionProductSelect = document.getElementById('add-acquisition-product');
        addAcquisitionQtyInput = document.getElementById('add-acquisition-qty');
        addAcquisitionCostInput = document.getElementById('add-acquisition-cost');
        addProductToAcquisitionBtn = document.getElementById('add-product-to-acquisition-btn');
        acquisitionItemsList = document.getElementById('acquisition-items-list');
        noAcquisitionItemsMessage = document.getElementById('no-acquisition-items-message');
        acquisitionTotalAmountSpan = document.getElementById('acquisition-total-amount');
        acquisitionFormErrorMessage = document.getElementById('acquisition-form-error-message');
        cancelAcquisitionBtn = document.getElementById('cancel-acquisition-btn');
        saveAcquisitionBtn = document.getElementById('save-acquisition-btn');

        // Acquisition Details Modal
        acquisitionDetailsModal = document.getElementById('acquisition-details-modal');
        closeAcquisitionDetailsModalBtn = document.getElementById('close-acquisition-details-modal-btn');
        detailInvoiceNumberSpan = document.getElementById('detail-invoice-number');
        detailSupplierNameSpan = document.getElementById('detail-supplier-name');
        detailPurchaseDateSpan = document.getElementById('detail-purchase-date');
        detailDueDateSpan = document.getElementById('detail-due-date');
        detailPaymentStatusSpan = document.getElementById('detail-payment-status');
        detailUserNameSpan = document.getElementById('detail-user-name');
        detailInvoiceFileRow = document.getElementById('detail-invoice-file-row');
        detailInvoiceFileLink = document.getElementById('detail-invoice-file-link');
        detailAcquisitionProductsList = document.getElementById('detail-acquisition-products-list');
        detailAcquisitionTotalSpan = document.getElementById('detail-acquisition-total');
        editAcquisitionBtn = document.getElementById('edit-acquisition-btn');
        deleteAcquisitionBtn = document.getElementById('delete-acquisition-btn');

        // Supplier Management Modal
        supplierManagementModal = document.getElementById('supplier-management-modal');
        closeSupplierManagementModalBtn = document.getElementById('close-supplier-management-modal-btn');
        addSupplierBtn = document.getElementById('add-supplier-btn');
        supplierTableBody = document.getElementById('supplier-table-body');
        noSuppliersMessage = document.getElementById('no-suppliers-message');

        // Supplier Modal
        supplierModal = document.getElementById('supplier-modal');
        supplierModalTitle = document.getElementById('supplier-modal-title');
        closeSupplierModalBtn = document.getElementById('close-supplier-modal-btn');
        supplierForm = document.getElementById('supplier-form');
        supplierRazonSocialInput = document.getElementById('supplier-razon-social');
        supplierRutInput = document.getElementById('supplier-rut');
        supplierDireccionInput = document.getElementById('supplier-direccion');
        supplierTelefonoInput = document.getElementById('supplier-telefono');
        supplierEmailInput = document.getElementById('supplier-email');
        supplierContactoNombreInput = document.getElementById('supplier-contacto-nombre');
        supplierContactoTelefonoInput = document.getElementById('supplier-contacto-telefono');
        supplierFormErrorMessage = document.getElementById('supplier-form-error-message');
        cancelSupplierEditBtn = document.getElementById('cancel-supplier-edit-btn');
        saveSupplierBtn = document.getElementById('save-supplier-btn');


        // --- Validar que los elementos principales existan ---
        const essentialElements = [
            addAcquisitionBtn, acquisitionSearchInput, acquisitionTableBody, noAcquisitionsMessage, manageSuppliersBtn,
            acquisitionModal, acquisitionForm, acquisitionSupplierSelect, acquisitionPurchaseDateInput,
            addAcquisitionProductSelect, addAcquisitionQtyInput, addAcquisitionCostInput, addProductToAcquisitionBtn,
            acquisitionItemsList, acquisitionTotalAmountSpan, saveAcquisitionBtn,
            acquisitionDetailsModal, detailAcquisitionTotalSpan,
            supplierManagementModal, supplierTableBody, supplierModal, supplierForm
        ];

        const allElementsFound = essentialElements.every(el => el !== null);

        if (!allElementsFound) {
            // Identificar qué elementos específicos faltan para un mensaje más útil
            const missingElements = essentialElements.map((el, index) => {
                const id = el ? el.id : `Elemento #${index} (ID no disponible)`;
                return el === null ? id : null;
            }).filter(id => id !== null);

            console.error('Error: Faltan algunos elementos principales del DOM en adquisitions.html. Asegúrate de que los IDs sean correctos. Elementos faltantes:', missingElements);
            window.showToast('Error al iniciar módulo de adquisiciones. Ver consola para detalles.', true);
            return; // Detener la inicialización si faltan elementos críticos
        }
        console.log('✅ Módulo de adquisiciones inicializado correctamente.');


        // --- FUNCIONES INTERNAS ---

        /**
         * Renderiza la tabla principal de adquisiciones, aplicando filtros si existen.
         * Los eventos para los botones de acción se adjuntan programáticamente.
         */
        window.renderAcquisitionsTable = function() { // Se define en window para ser global si es necesario
            if (!acquisitionTableBody || !noAcquisitionsMessage) {
                console.error('Elementos DOM para la tabla de adquisiciones no encontrados en renderAcquisitionsTable.');
                return;
            }

            acquisitionTableBody.innerHTML = '';
            const searchTerm = (acquisitionSearchInput ? acquisitionSearchInput.value.toLowerCase().trim() : '');

            const filteredAcquisitions = window.adquisitions ? window.adquisitions.filter(acq => {
                const matchesInvoice = acq.numero_factura ? acq.numero_factura.toLowerCase().includes(searchTerm) : false;
                const matchesSupplier = acq.proveedor_nombre ? acq.proveedor_nombre.toLowerCase().includes(searchTerm) : false;
                const matchesUser = acq.usuario_nombre ? acq.usuario_nombre.toLowerCase().includes(searchTerm) : false;
                return matchesInvoice || matchesSupplier || matchesUser;
            }) : [];

            if (filteredAcquisitions.length === 0) {
                noAcquisitionsMessage.classList.remove('hidden');
            } else {
                noAcquisitionsMessage.classList.add('hidden');
                filteredAcquisitions.forEach(acq => {
                    const row = document.createElement('tr');
                    row.className = 'hover:bg-slate-50 transition-colors duration-150';
                    row.innerHTML = `
                        <td class="py-3 px-4 text-sm font-medium text-slate-800">${acq.numero_factura || 'N/A'}</td>
                        <td class="py-3 px-4 text-sm text-slate-700">${acq.proveedor_nombre || 'Desconocido'}</td>
                        <td class="py-3 px-4 text-sm text-slate-700">${new Date(acq.fecha_compra).toLocaleDateString()}</td>
                        <td class="py-3 px-4 text-sm text-right font-semibold text-emerald-600">${window.formatCurrency(acq.total)}</td>
                        <td class="py-3 px-4 text-sm">
                            <span class="px-2 py-1 rounded-full text-xs font-semibold ${acq.estado_pago === 'Pagada' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}">
                                ${acq.estado_pago}
                            </span>
                        </td>
                        <td class="py-3 px-4 text-sm text-slate-600">${acq.usuario_nombre || 'Desconocido'}</td>
                        <td class="py-3 px-4 text-center">
                            <button class="view-acquisition-btn text-blue-600 hover:text-blue-800 transition-colors duration-200"
                                    data-id="${acq.id}" title="Ver Detalles">
                                <svg class="w-5 h-5 inline-block" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"></path><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"></path></svg>
                            </button>
                        </td>
                    `;
                    acquisitionTableBody.appendChild(row);
                });
            }
            if (window.lucide) {
                window.lucide.createIcons(); // Recargar iconos después de renderizar tabla
            }
        };

        /**
         * Carga los proveedores desde la API y popula los selectores.
         */
        window.loadSuppliersInternal = async () => {
            try {
                const response = await fetch('/api/proveedores.php?action=list');
                if (response.ok) {
                    window.suppliers = await response.json();
                    populateSupplierSelects(); // Llenar selectores del modal de adquisición
                    window.renderSuppliersTable(); // Renderizar tabla de proveedores en el modal de gestión
                } else {
                    console.error('Error al cargar proveedores:', response.status, await response.json());
                    window.showToast('Error al cargar proveedores.', true);
                }
            } catch (error) {
                console.error('Error de red al cargar proveedores:', error);
                window.showToast('Error de conexión al cargar proveedores.', true);
            }
        };

        /**
         * Carga las adquisiciones desde la API.
         */
        const loadAcquisitionsInternal = async () => {
            try {
                const response = await fetch('/api/adquisiciones.php?action=list');
                if (response.ok) {
                    window.adquisitions = await response.json();
                    window.renderAcquisitionsTable();
                } else {
                    console.error('Error al cargar adquisiciones:', response.status, await response.json());
                    window.showToast('Error al cargar adquisiciones.', true);
                }
            } catch (error) {
                console.error('Error de red al cargar adquisiciones:', error);
                window.showToast('Error de conexión al cargar adquisiciones.', true);
            }
        };

        /**
         * Popula los selectores de proveedor.
         */
        const populateSupplierSelects = () => {
            if (acquisitionSupplierSelect) {
                acquisitionSupplierSelect.innerHTML = '<option value="">Selecciona un Proveedor</option>';
                window.suppliers.forEach(supplier => {
                    const option = document.createElement('option');
                    option.value = supplier.id;
                    option.textContent = supplier.razon_social;
                    acquisitionSupplierSelect.appendChild(option);
                });
            }
        };

        /**
         * Carga los productos y los popula en el selector del modal de adquisición.
         */
        const loadCategoriesForNewProduct = async () => { // Renombrado para ser más descriptivo
            if (addAcquisitionProductSelect) {
                addAcquisitionProductSelect.innerHTML = '<option value="">Selecciona un Producto</option>';
                // Asumiendo que window.products ya está cargado por main.js loadDataFromAPI
                if (window.products && Array.isArray(window.products)) {
                    window.products.forEach(product => {
                        const option = document.createElement('option');
                        option.value = product.id;
                        option.textContent = `${product.name} (SKU: ${product.sku})`;
                        addAcquisitionProductSelect.appendChild(option);
                    });
                } else {
                    console.warn('window.products no está cargado o no es un array en adquisiciones.js.');
                    window.showToast('No se pudieron cargar los productos para adquisiciones.', true);
                }
            }
        };

        /**
         * Renderiza los ítems de la adquisición actual en el modal.
         */
        const renderAcquisitionItems = () => {
            if (!acquisitionItemsList || !noAcquisitionItemsMessage || !acquisitionTotalAmountSpan) {
                console.error('Elementos DOM para ítems de adquisición no encontrados en renderAcquisitionItems.');
                return;
            }

            acquisitionItemsList.innerHTML = '';
            let total = 0;

            if (currentAcquisitionItems.length === 0) {
                noAcquisitionItemsMessage.classList.remove('hidden');
            } else {
                noAcquisitionItemsMessage.classList.add('hidden');
                currentAcquisitionItems.forEach(item => {
                    const itemTotal = item.quantity * item.cost_at_acquisition;
                    total += itemTotal;
                    const row = document.createElement('tr');
                    row.className = 'hover:bg-slate-50 transition-colors duration-150';
                    row.innerHTML = `
                        <td class="py-2 px-3 text-sm font-semibold text-slate-800">${item.product_name}</td>
                        <td class="py-2 px-3 text-center text-sm">${item.quantity}</td>
                        <td class="py-2 px-3 text-right text-sm">${window.formatCurrency(item.cost_at_acquisition)}</td>
                        <td class="py-2 px-3 text-right text-sm font-medium">${window.formatCurrency(itemTotal)}</td>
                        <td class="py-2 px-3 text-center">
                            <button class="remove-acquisition-item-btn text-red-500 hover:text-red-700 transition-colors duration-200" data-product-id="${item.product_id}">
                                <svg class="w-5 h-5 inline-block" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path></svg>
                            </button>
                        </td>
                    `;
                    acquisitionItemsList.appendChild(row);
                });
            }
            acquisitionTotalAmountSpan.textContent = window.formatCurrency(total);
            if (window.lucide) { window.lucide.createIcons(); }
        };

        /**
         * Añade un producto a la lista de ítems de la adquisición.
         */
        const addProductToAcquisition = () => {
            const productId = parseInt(addAcquisitionProductSelect.value);
            const quantity = parseInt(addAcquisitionQtyInput.value);
            const cost = parseFloat(addAcquisitionCostInput.value);

            if (!productId || isNaN(quantity) || quantity <= 0 || isNaN(cost) || cost <= 0) {
                window.showToast('Por favor, selecciona un producto, cantidad y costo válidos.', true);
                return;
            }

            const product = window.products.find(p => p.id === productId);
            if (!product) {
                window.showToast('Producto no encontrado en el inventario.', true);
                return;
            }

            const existingItemIndex = currentAcquisitionItems.findIndex(item => item.product_id === productId);

            if (existingItemIndex > -1) {
                currentAcquisitionItems[existingItemIndex].quantity += quantity;
                currentAcquisitionItems[existingItemIndex].cost_at_acquisition = cost; // Actualizar costo al agregar de nuevo
            } else {
                currentAcquisitionItems.push({
                    product_id: productId,
                    product_name: product.name,
                    quantity: quantity,
                    cost_at_acquisition: cost
                });
            }

            // Limpiar campos de adición
            addAcquisitionProductSelect.value = '';
            addAcquisitionQtyInput.value = '1';
            addAcquisitionCostInput.value = '';

            renderAcquisitionItems();
            window.showToast('Producto añadido a la adquisición.');
        };

        /**
         * Elimina un producto de la lista de ítems de la adquisición.
         */
        const removeAcquisitionItem = (productId) => {
            currentAcquisitionItems = currentAcquisitionItems.filter(item => item.product_id !== productId);
            renderAcquisitionItems();
            window.showToast('Producto eliminado de la adquisición.');
        };

        /**
         * Abre el modal para registrar/editar una adquisición.
         */
        window.openAcquisitionModal = (acquisition = null) => {
            currentAcquisitionItems = []; // Limpiar ítems del modal
            currentEditingAcquisitionId = null;
            acquisitionForm.reset();
            acquisitionFormErrorMessage.classList.add('hidden');
            currentInvoiceFileLink.parentNode.classList.add('hidden'); // Ocultar archivo actual

            if (acquisition) {
                acquisitionModalTitle.textContent = 'Editar Adquisición';
                currentEditingAcquisitionId = acquisition.id;
                acquisitionSupplierSelect.value = acquisition.proveedor_id;
                acquisitionInvoiceNumberInput.value = acquisition.numero_factura;
                acquisitionPurchaseDateInput.value = new Date(acquisition.fecha_compra).toISOString().split('T')[0];
                if (acquisition.fecha_vencimiento) {
                    acquisitionDueDateInput.value = new Date(acquisition.fecha_vencimiento).toISOString().split('T')[0];
                }
                acquisitionPaymentStatusSelect.value = acquisition.estado_pago;

                if (acquisition.archivo_factura) {
                    currentInvoiceFileLink.href = acquisition.archivo_factura;
                    currentInvoiceFileLink.textContent = `Ver Archivo (${acquisition.archivo_factura.split('/').pop()})`;
                    currentInvoiceFileLink.parentNode.classList.remove('hidden');
                }

                // Cargar ítems existentes de la adquisición (asumiendo que están en acquisition.items)
                if (acquisition.items && Array.isArray(acquisition.items)) {
                    currentAcquisitionItems = acquisition.items.map(item => ({
                        product_id: item.product_id,
                        product_name: item.product_name,
                        quantity: item.quantity,
                        cost_at_acquisition: parseFloat(item.cost_at_acquisition)
                    }));
                }
            } else {
                acquisitionModalTitle.textContent = 'Registrar Nueva Adquisición';
            }
            renderAcquisitionItems();
            acquisitionModal.classList.remove('hidden');
            acquisitionModal.classList.add('flex');
            const modalContent = document.getElementById('acquisition-modal-content');
            if (modalContent) {
                modalContent.classList.remove('scale-95', 'opacity-0');
                modalContent.classList.add('scale-100', 'opacity-100');
            }
        };

        /**
         * Cierra el modal de adquisición.
         */
        const closeAcquisitionModal = () => {
            if (acquisitionModal) {
                const modalContent = document.getElementById('acquisition-modal-content');
                if (modalContent) {
                    modalContent.classList.remove('scale-100', 'opacity-100');
                    modalContent.classList.add('scale-95', 'opacity-0');
                    setTimeout(() => {
                        acquisitionModal.classList.add('hidden');
                        acquisitionModal.classList.remove('flex');
                    }, 300); // Duración de la transición
                }
            }
        };

        /**
         * Maneja el envío del formulario de adquisición.
         */
        const handleAcquisitionFormSubmit = async (event) => {
            event.preventDefault();
            acquisitionFormErrorMessage.classList.add('hidden');

            const formData = new FormData(acquisitionForm);
            const acquisitionData = Object.fromEntries(formData.entries());

            acquisitionData.total = parseFloat(acquisitionTotalAmountSpan.textContent.replace(/[$.]/g, '').replace(',', '.'));
            acquisitionData.user_id = window.currentUser ? window.currentUser.id : null; // Asegúrate de tener el user_id
            acquisitionData.items = currentAcquisitionItems;

            if (currentAcquisitionItems.length === 0) {
                acquisitionFormErrorMessage.textContent = 'Debe añadir al menos un producto a la adquisición.';
                acquisitionFormErrorMessage.classList.remove('hidden');
                return;
            }
            if (acquisitionData.total <= 0) {
                acquisitionFormErrorMessage.textContent = 'El total de la adquisición debe ser mayor a cero.';
                acquisitionFormErrorMessage.classList.remove('hidden');
                return;
            }

            // Eliminar archivo_factura si no se seleccionó uno nuevo y no hay uno actual
            if (acquisitionInvoiceFileInput && acquisitionInvoiceFileInput.files.length === 0 && !acquisitionData.archivo_factura_current) {
                delete acquisitionData.archivo_factura;
            }

            let url = '/api/adquisiciones.php?action=register';
            let method = 'POST';

            // if (currentEditingAcquisitionId) { // Lógica para edición (no implementada completamente en backend)
            //     url = `/api/adquisiciones.php?action=update&id=${currentEditingAcquisitionId}`;
            //     method = 'POST'; // PHP no maneja PUT directo con form-data fácilmente, usar POST y _method
            //     formData.append('_method', 'PUT');
            // }

            try {
                const fetchOptions = {
                    method: method,
                    body: JSON.stringify(acquisitionData), // Envía como JSON
                    headers: {
                        'Content-Type': 'application/json' // Especifica el tipo de contenido JSON
                    }
                };

                const response = await fetch(url, fetchOptions);
                const data = await response.json();

                if (response.ok && data.success) {
                    window.showToast(data.message || 'Adquisición registrada exitosamente.');
                    closeAcquisitionModal();
                    currentAcquisitionItems = []; // Limpiar ítems del carrito
                    renderAcquisitionItems(); // Renderizar carrito vacío
                    await loadAcquisitionsInternal(); // Recargar la tabla de adquisiciones
                    await window.loadDataFromAPI(); // Recargar datos globales, incluyendo productos para que los nuevos estén disponibles
                } else {
                    acquisitionFormErrorMessage.textContent = data.error || "Error al registrar adquisición. Inténtelo de nuevo.";
                    acquisitionFormErrorMessage.classList.remove('hidden');
                    window.showToast(data.error || "Error al registrar adquisición. Inténtelo de nuevo.", true);
                }
            } catch (err) {
                console.error("Error de red al registrar adquisición:", err);
                acquisitionFormErrorMessage.textContent = "Error de conexión al registrar adquisición.";
                acquisitionFormErrorMessage.classList.remove('hidden');
                window.showToast("Error de conexión al registrar adquisición.", true);
            }
        };

        /**
         * Abre el modal de detalles de adquisición.
         */
        const openAcquisitionDetailsModal = async (acquisitionId) => {
            try {
                const response = await fetch(`/api/adquisiciones.php?action=details&id=${acquisitionId}`);
                if (!response.ok) {
                    throw new Error(`Error al obtener detalles: ${response.status}`);
                }
                const acquisition = await response.json();

                if (!acquisition) {
                    window.showToast('Detalles de adquisición no encontrados.', true);
                    return;
                }

                detailInvoiceNumberSpan.textContent = acquisition.numero_factura || 'N/A';
                detailSupplierNameSpan.textContent = acquisition.proveedor_nombre || 'Desconocido';
                detailPurchaseDateSpan.textContent = new Date(acquisition.fecha_compra).toLocaleDateString();
                detailDueDateSpan.textContent = acquisition.fecha_vencimiento ? new Date(acquisition.fecha_vencimiento).toLocaleDateString() : 'N/A';
                detailPaymentStatusSpan.textContent = acquisition.estado_pago;
                detailPaymentStatusSpan.className = `font-bold ${acquisition.estado_pago === 'Pagada' ? 'text-green-600' : 'text-red-600'}`;
                detailUserNameSpan.textContent = acquisition.usuario_nombre || 'Desconocido';
                detailAcquisitionTotalSpan.textContent = window.formatCurrency(acquisition.total);

                if (acquisition.archivo_factura) {
                    detailInvoiceFileLink.href = acquisition.archivo_factura;
                    detailInvoiceFileLink.textContent = `Ver Archivo (${acquisition.archivo_factura.split('/').pop()})`;
                    detailInvoiceFileRow.classList.remove('hidden');
                } else {
                    detailInvoiceFileRow.classList.add('hidden');
                }

                detailAcquisitionProductsList.innerHTML = '';
                if (acquisition.items && Array.isArray(acquisition.items)) {
                    acquisition.items.forEach(item => {
                        const row = document.createElement('tr');
                        row.innerHTML = `
                            <td class="py-2 px-3 text-sm">${item.product_name} (SKU: ${item.product_sku})</td>
                            <td class="py-2 px-3 text-center text-sm">${item.quantity}</td>
                            <td class="py-2 px-3 text-right text-sm">${window.formatCurrency(item.cost_at_acquisition)}</td>
                            <td class="py-2 px-3 text-right text-sm font-medium">${window.formatCurrency(item.item_total)}</td>
                        `;
                        detailAcquisitionProductsList.appendChild(row);
                    });
                } else {
                    detailAcquisitionProductsList.innerHTML = '<tr><td colspan="4" class="text-center py-3 text-slate-500">No hay productos en esta adquisición.</td></tr>';
                }

                // Configurar botones de acción del modal de detalles
                editAcquisitionBtn.onclick = () => window.openAcquisitionModal(acquisition); // Pasar la adquisición para editar
                deleteAcquisitionBtn.onclick = () => handleDeleteAcquisition(acquisition.id);

                acquisitionDetailsModal.classList.remove('hidden');
                acquisitionDetailsModal.classList.add('flex');
                const modalContent = document.getElementById('acquisition-details-modal-content');
                if (modalContent) {
                    modalContent.classList.remove('scale-95', 'opacity-0');
                    modalContent.classList.add('scale-100', 'opacity-100');
                }

            } catch (error) {
                console.error('Error al abrir detalles de adquisición:', error);
                window.showToast('Error al cargar detalles de adquisición.', true);
            }
        };

        /**
         * Cierra el modal de detalles de adquisición.
         */
        const closeAcquisitionDetailsModal = () => {
            if (acquisitionDetailsModal) {
                const modalContent = document.getElementById('acquisition-details-modal-content');
                if (modalContent) {
                    modalContent.classList.remove('scale-100', 'opacity-100');
                    modalContent.classList.add('scale-95', 'opacity-0');
                    setTimeout(() => {
                        acquisitionDetailsModal.classList.add('hidden');
                        acquisitionDetailsModal.classList.remove('flex');
                    }, 300);
                }
            }
        };

        /**
         * Maneja la eliminación de una adquisición.
         */
        const handleDeleteAcquisition = async (acquisitionId) => {
            if (!confirm('¿Estás seguro de que deseas eliminar esta adquisición? Esta acción es irreversible.')) {
                return;
            }

            try {
                const response = await fetch(`/api/adquisiciones.php?action=delete&id=${acquisitionId}`, {
                    method: 'DELETE',
                });
                const data = await response.json();

                if (response.ok && data.success) { // El backend debería enviar 'success: true'
                    window.showToast(data.message || 'Adquisición eliminada exitosamente.');
                    closeAcquisitionDetailsModal();
                    await loadAcquisitionsInternal(); // Recargar la tabla
                } else {
                    window.showToast(data.error || 'Error al eliminar adquisición.', true);
                }
            } catch (error) {
                console.error('Error de red al eliminar adquisición:', error);
                window.showToast('Error de conexión al eliminar adquisición.', true);
            }
        };

        /**
         * Renderiza la tabla de proveedores en el modal de gestión.
         */
        window.renderSuppliersTable = () => { // Se define en window para ser global
            if (!supplierTableBody || !noSuppliersMessage) {
                console.error('Elementos DOM para la tabla de proveedores no encontrados en renderSuppliersTable.');
                return;
            }

            supplierTableBody.innerHTML = '';
            if (window.suppliers.length === 0) {
                noSuppliersMessage.classList.remove('hidden');
            } else {
                noSuppliersMessage.classList.add('hidden');
                window.suppliers.forEach(supplier => {
                    const row = document.createElement('tr');
                    row.className = 'hover:bg-slate-50 transition-colors duration-150';
                    row.innerHTML = `
                        <td class="py-2 px-3 text-sm font-medium text-slate-800">${supplier.razon_social}</td>
                        <td class="py-2 px-3 text-sm text-slate-700">${supplier.rut}</td>
                        <td class="py-2 px-3 text-sm text-slate-700">${supplier.telefono || 'N/A'}</td>
                        <td class="py-2 px-3 text-sm text-slate-700">${supplier.email || 'N/A'}</td>
                        <td class="py-2 px-3 text-center">
                            <button class="edit-supplier-btn text-blue-600 hover:text-blue-800 mr-2" data-id="${supplier.id}" title="Editar Proveedor">
                                <svg class="w-5 h-5 inline-block" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-7-6l2-2m0 0l5 5m-5-5H11a2 2 0 00-2 2v2"></path></svg>
                            </button>
                            <button class="delete-supplier-btn text-red-600 hover:text-red-800" data-id="${supplier.id}" title="Eliminar Proveedor">
                                <svg class="w-5 h-5 inline-block" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path></svg>
                            </button>
                        </td>
                    `;
                    supplierTableBody.appendChild(row);
                });
            }
            if (window.lucide) { window.lucide.createIcons(); }
        };

        /**
         * Abre el modal para añadir/editar un proveedor.
         */
        window.openSupplierModal = (supplier = null) => {
            currentEditingSupplierId = null;
            supplierForm.reset();
            supplierFormErrorMessage.classList.add('hidden');

            if (supplier) {
                supplierModalTitle.textContent = 'Editar Proveedor';
                currentEditingSupplierId = supplier.id;
                supplierRazonSocialInput.value = supplier.razon_social;
                supplierRutInput.value = supplier.rut;
                supplierDireccionInput.value = supplier.direccion || '';
                supplierTelefonoInput.value = supplier.telefono || '';
                supplierEmailInput.value = supplier.email || '';
                supplierContactoNombreInput.value = supplier.contacto_nombre || '';
                supplierContactoTelefonoInput.value = supplier.contacto_telefono || '';
            } else {
                supplierModalTitle.textContent = 'Añadir Proveedor';
            }
            supplierModal.classList.remove('hidden');
            supplierModal.classList.add('flex');
            const modalContent = document.getElementById('supplier-modal-content');
            if (modalContent) {
                modalContent.classList.remove('scale-95', 'opacity-0');
                modalContent.classList.add('scale-100', 'opacity-100');
            }
        };

        /**
         * Cierra el modal de proveedor.
         */
        window.closeSupplierModal = () => {
            if (supplierModal) {
                const modalContent = document.getElementById('supplier-modal-content');
                if (modalContent) {
                    modalContent.classList.remove('scale-100', 'opacity-100');
                    modalContent.classList.add('scale-95', 'opacity-0');
                    setTimeout(() => {
                        supplierModal.classList.add('hidden');
                        supplierModal.classList.remove('flex');
                    }, 300);
                }
            }
        };

        /**
         * Maneja el envío del formulario de proveedor (añadir/editar).
         */
        const handleSupplierFormSubmit = async (event) => {
            event.preventDefault();
            supplierFormErrorMessage.classList.add('hidden');

            const formData = new FormData(supplierForm);
            const supplierData = Object.fromEntries(formData.entries());

            if (!supplierData.razon_social || !supplierData.rut) {
                supplierFormErrorMessage.textContent = 'Razón Social y RUT son campos obligatorios.';
                supplierFormErrorMessage.classList.remove('hidden');
                return;
            }

            let url = '/api/proveedores.php?action=register';
            let method = 'POST';

            if (currentEditingSupplierId) {
                url = `/api/proveedores.php?action=update&id=${currentEditingSupplierId}`;
                method = 'POST'; // Usar POST para PHP y simular PUT
                formData.append('_method', 'PUT'); // Para el backend si lo procesa
            }

            try {
                const fetchOptions = {
                    method: method,
                    headers: {
                        'Content-Type': 'application/json' // Enviar como JSON
                    },
                    body: JSON.stringify(supplierData)
                };

                const response = await fetch(url, fetchOptions);
                const data = await response.json();

                if (response.ok && data.success) {
                    window.showToast(data.message || 'Proveedor guardado exitosamente.');
                    window.closeSupplierModal();
                    await window.loadSuppliersInternal(); // Recargar la tabla de proveedores
                    populateSupplierSelects(); // Recargar selectores
                } else {
                    supplierFormErrorMessage.textContent = data.error || 'Error al guardar proveedor. Inténtelo de nuevo.';
                    supplierFormErrorMessage.classList.remove('hidden');
                    window.showToast(data.error || 'Error al guardar proveedor.', true);
                }
            } catch (err) {
                console.error("Error de red al guardar proveedor:", err);
                supplierFormErrorMessage.textContent = "Error de conexión al guardar proveedor.";
                supplierFormErrorMessage.classList.remove('hidden');
                window.showToast("Error de conexión al guardar proveedor.", true);
            }
        };

        /**
         * Cancela la edición o adición de un proveedor.
         */
        window.cancelSupplierEdit = () => { // Se define en window para ser global si es necesario
            window.closeSupplierModal();
        };

        /**
         * Maneja la eliminación de un proveedor.
         */
        const handleDeleteSupplier = async (supplierId) => {
            if (!confirm('¿Estás seguro de que deseas eliminar este proveedor? Esta acción es irreversible.')) {
                return;
            }

            try {
                const response = await fetch(`/api/proveedores.php?action=delete&id=${supplierId}`, {
                    method: 'DELETE',
                });
                const data = await response.json();

                if (response.ok && data.message) {
                    window.showToast(data.message || 'Proveedor eliminado exitosamente.');
                    await window.loadSuppliersInternal(); // Recargar la tabla de proveedores
                    populateSupplierSelects(); // Recargar selectores
                } else {
                    window.showToast(data.error || 'Error al eliminar proveedor.', true);
                }
            } catch (error) {
                console.error('Error de red al eliminar proveedor:', error);
                window.showToast('Error de conexión al eliminar proveedor.', true);
            }
        };

        /**
         * Abre el modal de gestión de proveedores.
         */
        window.openSupplierManagementModal = () => {
            if (supplierManagementModal) {
                window.renderSuppliersTable(); // Asegurar que la tabla esté actualizada
                supplierManagementModal.classList.remove('hidden');
                supplierManagementModal.classList.add('flex');
                const modalContent = document.getElementById('supplier-management-modal-content');
                if (modalContent) {
                    modalContent.classList.remove('scale-95', 'opacity-0');
                    modalContent.classList.add('scale-100', 'opacity-100');
                }
            }
        };

        // --- Event Listeners principales ---
        if (addAcquisitionBtn) addAcquisitionBtn.addEventListener('click', () => window.openAcquisitionModal());
        if (closeAcquisitionModalBtn) closeAcquisitionModalBtn.addEventListener('click', closeAcquisitionModal);
        if (cancelAcquisitionBtn) cancelAcquisitionBtn.addEventListener('click', closeAcquisitionModal);
        if (acquisitionForm) acquisitionForm.addEventListener('submit', handleAcquisitionFormSubmit);

        if (acquisitionItemsList) {
            acquisitionItemsList.addEventListener('click', (e) => {
                const removeBtn = e.target.closest('.remove-acquisition-item-btn');
                if (removeBtn) {
                    const productId = parseInt(removeBtn.dataset.productId);
                    removeAcquisitionItem(productId);
                }
            });
        }
        if (addProductToAcquisitionBtn) addProductToAcquisitionBtn.addEventListener('click', addProductToAcquisition);

        // Delegación de eventos para los botones de ver detalles en la tabla de adquisiciones
        if (acquisitionTableBody) {
            acquisitionTableBody.addEventListener('click', (e) => {
                const viewBtn = e.target.closest('.view-acquisition-btn');
                if (viewBtn) {
                    const acquisitionId = parseInt(viewBtn.dataset.id);
                    openAcquisitionDetailsModal(acquisitionId);
                }
            });
        }

        if (closeAcquisitionDetailsModalBtn) closeAcquisitionDetailsModalBtn.addEventListener('click', closeAcquisitionDetailsModal);

        // Event listeners para la gestión de proveedores
        if (manageSuppliersBtn) manageSuppliersBtn.addEventListener('click', window.openSupplierManagementModal);
        if (closeSupplierManagementModalBtn) closeSupplierManagementModalBtn.addEventListener('click', () => {
            supplierManagementModal.classList.add('hidden');
            supplierManagementModal.classList.remove('flex');
        });
        if (addSupplierBtn) addSupplierBtn.addEventListener('click', () => window.openSupplierModal());
        if (closeSupplierModalBtn) closeSupplierModalBtn.addEventListener('click', window.closeSupplierModal);
        if (cancelSupplierEditBtn) cancelSupplierEditBtn.addEventListener('click', window.cancelSupplierEdit);
        if (supplierForm) supplierForm.addEventListener('submit', handleSupplierFormSubmit);

        if (supplierTableBody) {
            supplierTableBody.addEventListener('click', (e) => {
                const editBtn = e.target.closest('.edit-supplier-btn');
                const deleteBtn = e.target.closest('.delete-supplier-btn');
                if (editBtn) {
                    const supplierId = parseInt(editBtn.dataset.id);
                    const supplier = window.suppliers.find(s => s.id === supplierId);
                    if (supplier) window.openSupplierModal(supplier);
                } else if (deleteBtn) {
                    const supplierId = parseInt(deleteBtn.dataset.id);
                    handleDeleteSupplier(supplierId);
                }
            });
        }

        if (acquisitionSearchInput) {
            acquisitionSearchInput.addEventListener('input', window.renderAcquisitionsTable);
        }

        // --- Carga inicial de datos al iniciar el módulo ---
        await window.loadSuppliersInternal(); // Cargar proveedores y renderizar su tabla
        await loadAcquisitionsInternal(); // Cargar adquisiciones y renderizar su tabla
        await loadCategoriesForNewProduct(); // Cargar productos para el formulario de nueva adquisición
    });

};
