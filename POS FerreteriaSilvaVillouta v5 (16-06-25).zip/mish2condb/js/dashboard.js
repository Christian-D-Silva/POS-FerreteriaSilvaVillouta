// js/dashboard.js

// Función de inicialización para el módulo de Dashboard
window.initDashboard = () => {
    console.log('Inicializando Dashboard...');

    // Usamos requestAnimationFrame para asegurar que el DOM esté completamente renderizado
    // antes de intentar obtener los elementos.
    requestAnimationFrame(() => {
        // Obtener todas las referencias a los elementos DOM localmente dentro de initDashboard
        const totalSalesTodayElement = document.getElementById('total-sales-today'); // ID de la tarjeta "Ventas de Hoy"
        const totalProductsInStockElement = document.getElementById('total-products-in-stock'); // ID de la tarjeta "Productos en Stock"
        const totalClientsElement = document.getElementById('total-clients'); // ID de la tarjeta "Clientes Registrados"
        const pendingAcquisitionsElement = document.getElementById('pending-acquisitions'); // ID de la tarjeta "Adquisiciones Pendientes"
        const lowStockProductsList = document.getElementById('low-stock-products-list');
        const noLowStockMessage = document.getElementById('no-low-stock-message');

        // Validar que los elementos esenciales existan
        if (!totalSalesTodayElement || !totalProductsInStockElement || !totalClientsElement || !pendingAcquisitionsElement || !lowStockProductsList || !noLowStockMessage) {
            console.error('Elementos del dashboard no encontrados. Asegúrate de que dashboard.html esté cargado correctamente.');
            window.showToast('Error: No se pudo cargar el dashboard correctamente. Ver consola.', true);
            return;
        }

        // --- FUNCIONES INTERNAS DEL DASHBOARD ---

        /**
         * Actualiza las tarjetas de estadísticas con los datos globales.
         */
        const updateStatsCards = () => {
            // Calcular Ventas de Hoy
            const today = new Date();
            today.setHours(0, 0, 0, 0); // Establecer la hora a medianoche para comparar solo la fecha
            const totalSalesToday = window.salesHistory.filter(sale => {
                const saleDate = new Date(sale.sale_date);
                saleDate.setHours(0, 0, 0, 0);
                return saleDate.getTime() === today.getTime();
            }).reduce((sum, sale) => sum + parseFloat(sale.total_amount), 0);

            // Suma total de stock de todos los productos
            const totalStockCount = window.products.reduce((sum, product) => sum + product.stock, 0);

            // Clientes registrados
            const clientsCount = window.clients.length;

            // Adquisiciones pendientes
            const pendingAcquisitionsCount = window.adquisitions.filter(acq => acq.estado_pago !== 'Pagada').length;


            // Actualizar el DOM
            // Usamos window.formatCurrency aquí
            totalSalesTodayElement.textContent = window.formatCurrency(totalSalesToday);
            totalProductsInStockElement.textContent = totalStockCount.toLocaleString('es-CL');
            totalClientsElement.textContent = clientsCount.toLocaleString('es-CL');
            pendingAcquisitionsElement.textContent = pendingAcquisitionsCount.toLocaleString('es-CL');

            // console.log("Estadísticas actualizadas:", {
            //     totalSalesToday, totalStockCount, clientsCount, pendingAcquisitionsCount
            // });
        };

        /**
         * Renderiza la lista de productos con bajo stock.
         */
        const renderLowStockProducts = () => {
            lowStockProductsList.innerHTML = ''; // Limpiar lista
            const lowStockThreshold = 10; // Umbral de stock bajo

            // Asegurarse de que window.products esté cargado y sea un array
            const lowStockProducts = window.products && Array.isArray(window.products)
                ? window.products.filter(product => product.stock <= lowStockThreshold)
                : [];

            if (lowStockProducts.length > 0) {
                noLowStockMessage.style.display = 'none'; // Ocultar mensaje de no stock bajo
                lowStockProducts.forEach(product => {
                    const listItem = document.createElement('li');
                    listItem.className = 'flex items-center justify-between p-3 bg-slate-50 rounded-lg border border-slate-200';
                    listItem.innerHTML = `
                        <div class="flex items-center space-x-3">
                            <span class="inline-flex items-center justify-center h-8 w-8 rounded-full bg-red-100 text-red-600">
                                <span class="lucide" data-lucide="alert-triangle"></span>
                            </span>
                            <div>
                                <p class="font-semibold text-slate-700">${product.name}</p>
                                <p class="text-xs text-slate-500">SKU: ${product.sku}</p>
                            </div>
                        </div>
                        <span class="text-red-500 font-bold text-lg">${product.stock} unid.</span>
                    `;
                    lowStockProductsList.appendChild(listItem);
                });
            } else {
                noLowStockMessage.style.display = 'block'; // Mostrar mensaje de no stock bajo
            }

            // Asegurarse de que los iconos Lucide se creen para esta sección
            if (window.lucide) {
                window.lucide.createIcons();
            }
        };

        // --- Carga y Renderizado Inicial ---
        // Llamar a las funciones para cargar los datos en el dashboard
        updateStatsCards();
        renderLowStockProducts();

        // Puedes añadir aquí event listeners si el dashboard tuviera elementos interactivos
        // Por ejemplo, si los botones "Ver todos" fueran funcionales.
    });
};
