// js/clients.js

// Función de inicialización para el módulo de Clientes
window.initClientes = async () => {
    console.log('--- Iniciando initClientes ---');

    // Usamos requestAnimationFrame para asegurar que el DOM esté completamente renderizado
    // antes de intentar obtener los elementos.
    requestAnimationFrame(async () => {
        // 1. Obtener todas las referencias a los elementos DOM localmente dentro de initClientes
        let clientsTableBody = document.getElementById('clients-table-body');
        let clientSearchInput = document.getElementById('client-search-input');
        let noClientsMessage = document.getElementById('no-clients-message');
        let addClientBtn = document.getElementById('add-client-btn');
        let clientModal = document.getElementById('client-modal');
        let clientModalTitle = document.getElementById('client-modal-title');
        let clientForm = document.getElementById('client-form');
        let saveClientBtn = document.getElementById('save-client-btn');
        let cancelClientBtn = document.getElementById('cancel-client-btn');

        // Referencias a los campos del formulario de cliente
        let clientIdInput = document.getElementById('client-id');
        let clientRutInput = document.getElementById('client-rut');
        let clientRazonSocialInput = document.getElementById('client-razon-social');
        let clientGiroInput = document.getElementById('client-giro');
        let clientDireccionInput = document.getElementById('client-direccion');
        let clientComunaInput = document.getElementById('client-comuna');
        let clientCiudadInput = document.getElementById('client-ciudad');
        let clientTelefonoInput = document.getElementById('client-telefono');
        let clientEmailInput = document.getElementById('client-email');

        // Esta variable es auxiliar para el estado de edición, puede ser local a initClientes
        let currentEditingClientId = null;

        // Validar que los elementos esenciales existan
        if (!clientsTableBody || !clientSearchInput || !addClientBtn || !clientModal || !clientForm || !clientIdInput || !clientRutInput || !clientRazonSocialInput || !clientGiroInput || !clientDireccionInput || !clientComunaInput || !clientCiudadInput || !clientTelefonoInput || !clientEmailInput) {
            console.error('Error: Algunos elementos principales del DOM de clientes no se encontraron. Asegúrate de que los IDs sean correctos.');
            window.showToast('Error: No se pudo cargar la interfaz de clientes correctamente.', true);
            return;
        }

        // --- FUNCIONES INTERNAS (CLOSURES) ---

        /**
         * Carga la lista de clientes desde la API y la almacena globalmente.
         * Luego, renderiza la tabla.
         */
        async function loadClients() {
            try {
                if (noClientsMessage) noClientsMessage.textContent = 'Cargando clientes...';
                clientsTableBody.innerHTML = ''; // Limpiar la tabla antes de cargar

                const response = await fetch('api/clients.php?action=list');
                if (!response.ok) throw new Error('Error al cargar listado de clientes.');
                
                window.clients = await response.json(); // Almacenar clientes globalmente

                renderClientsTable(); // Renderizar la tabla con los datos cargados

            } catch (error) {
                console.error('Error cargando clientes:', error);
                if (noClientsMessage) noClientsMessage.textContent = 'Error al cargar clientes.';
                window.showToast(`Error al cargar clientes: ${error.message}`, true);
            }
        }

        /**
         * Renderiza la tabla de clientes en el DOM.
         * Aplica filtrado basado en el input de búsqueda.
         * Adjunta listeners de eventos a los botones de acción.
         */
        function renderClientsTable() {
            clientsTableBody.innerHTML = '';
            const searchTerm = clientSearchInput.value.toLowerCase().trim();
            
            const filteredClients = window.clients.filter(client => {
                const matchesSearch = searchTerm === '' ||
                                      (client.rut && client.rut.toLowerCase().includes(searchTerm)) ||
                                      (client.razon_social && client.razon_social.toLowerCase().includes(searchTerm)) ||
                                      (client.giro && client.giro.toLowerCase().includes(searchTerm)) ||
                                      (client.direccion && client.direccion.toLowerCase().includes(searchTerm)) ||
                                      (client.comuna && client.comuna.toLowerCase().includes(searchTerm)) ||
                                      (client.ciudad && client.ciudad.toLowerCase().includes(searchTerm)) ||
                                      (client.telefono && client.telefono.toLowerCase().includes(searchTerm)) ||
                                      (client.email && client.email.toLowerCase().includes(searchTerm));
                return matchesSearch;
            });

            if (filteredClients.length === 0) {
                clientsTableBody.innerHTML = `<tr><td colspan="10" class="p-4 text-center text-gray-500">${window.clients && window.clients.length > 0 ? 'No se encontraron resultados para la búsqueda.' : 'No hay clientes registrados aún.'}</td></tr>`;
                if (noClientsMessage) noClientsMessage.classList.remove('hidden');
            } else {
                if (noClientsMessage) noClientsMessage.classList.add('hidden');
                filteredClients.forEach(client => {
                    const row = document.createElement('tr');
                    row.className = 'hover:bg-gray-50';

                    row.innerHTML = `
                        <td class="p-3">${client.rut || 'N/A'}</td>
                        <td class="p-3">${client.razon_social || 'N/A'}</td>
                        <td class="p-3">${client.giro || 'N/A'}</td>
                        <td class="p-3">${client.direccion || 'N/A'}</td>
                        <td class="p-3">${client.comuna || 'N/A'}</td>
                        <td class="p-3">${client.ciudad || 'N/A'}</td>
                        <td class="p-3">${client.telefono || 'N/A'}</td>
                        <td class="p-3">${client.email || 'N/A'}</td>
                        <td class="p-3">${client.fecha_creacion ? new Date(client.fecha_creacion).toLocaleDateString('es-CL') : 'N/A'}</td> <!-- AQUI SE INSERTA LA FECHA -->
                        <td class="p-3">
                            <div class="flex items-center space-x-2">
                                <button class="edit-client-btn text-yellow-600 hover:text-yellow-800 p-1 rounded-md hover:bg-yellow-100 transition-colors" data-client-id="${client.id}" title="Editar Cliente">
                                    <span class="lucide" data-lucide="edit"></span>
                                </button>
                                <button class="delete-client-btn text-red-600 hover:text-red-800 p-1 rounded-md hover:bg-red-100 transition-colors" data-client-id="${client.id}" title="Eliminar Cliente">
                                    <span class="lucide" data-lucide="trash-2"></span>
                                </button>
                            </div>
                        </td>
                    `;
                    clientsTableBody.appendChild(row);
                });

                // Adjuntar Event Listeners a los botones DESPUÉS de que se hayan agregado al DOM
                clientsTableBody.querySelectorAll('.edit-client-btn').forEach(button => {
                    button.addEventListener('click', (event) => {
                        const id = event.currentTarget.dataset.clientId;
                        window.editClient(id); // Llamada a la función globalmente accesible
                    });
                });
                clientsTableBody.querySelectorAll('.delete-client-btn').forEach(button => {
                    button.addEventListener('click', (event) => {
                        const id = event.currentTarget.dataset.clientId;
                        window.deleteClient(id); // Llamada a la función globalmente accesible
                    });
                });
            }
            if (window.lucide) window.lucide.createIcons(); // Re-renderizar iconos Lucide
        }

        /**
         * Abre el modal para añadir o editar un cliente.
         * @param {Object} [client=null] - Objeto cliente si es para edición, null para añadir.
         */
        function openClientModal(client = null) {
            clientForm.reset();
            clientModal.classList.remove('hidden');
            clientModal.classList.add('flex'); // Asegurarse de que el modal se muestre con flexbox

            if (client) {
                currentEditingClientId = client.id;
                clientModalTitle.textContent = 'Editar Cliente';
                clientIdInput.value = client.id; // Asignar el ID al campo oculto
                clientRutInput.value = client.rut || '';
                clientRazonSocialInput.value = client.razon_social || '';
                clientGiroInput.value = client.giro || '';
                clientDireccionInput.value = client.direccion || '';
                clientComunaInput.value = client.comuna || '';
                clientCiudadInput.value = client.ciudad || '';
                clientTelefonoInput.value = client.telefono || '';
                clientEmailInput.value = client.email || '';
            } else {
                currentEditingClientId = null;
                clientModalTitle.textContent = 'Añadir Nuevo Cliente';
                clientIdInput.value = ''; // Limpiar el ID si es un nuevo cliente
            }
            if (window.lucide) window.lucide.createIcons(); // Asegurar que los iconos en el modal se rendericen
        }

        /**
         * Maneja el envío del formulario de cliente (añadir o actualizar).
         */
        async function handleClientFormSubmit(event) {
            event.preventDefault();

            const isEditing = currentEditingClientId !== null;
            const method = 'POST'; // Siempre POST, la acción se define en la URL
            const action = isEditing ? 'update' : 'add';
            const url = `api/clients.php?action=${action}` + (isEditing ? `&id=${currentEditingClientId}` : '');

            const payload = {
                rut: clientRutInput.value.trim(),
                razon_social: clientRazonSocialInput.value.trim(),
                giro: clientGiroInput.value.trim(),
                direccion: clientDireccionInput.value.trim(),
                comuna: clientComunaInput.value.trim(),
                ciudad: clientCiudadInput.value.trim(),
                telefono: clientTelefonoInput.value.trim(),
                email: clientEmailInput.value.trim()
            };

            // Validaciones básicas de campos
            if (!payload.rut || !payload.razon_social) {
                window.showToast('RUT y Razón Social son campos obligatorios.', true);
                return;
            }

            try {
                const response = await fetch(url, {
                    method: method,
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(payload)
                });

                const data = await response.json();

                if (response.ok) {
                    window.showToast(data.message || (isEditing ? 'Cliente actualizado exitosamente!' : 'Cliente añadido exitosamente!'));
                    clientModal.classList.add('hidden'); // Ocultar modal
                    clientForm.reset(); // Resetear formulario
                    await loadClients(); // Recargar la lista de clientes para actualizar la tabla
                } else {
                    window.showToast(data.error || 'Error al guardar cliente.', true);
                }
            } catch (error) {
                console.error('Error de red al guardar cliente:', error);
                window.showToast('Error de conexión al guardar cliente.', true);
            }
        }

        /**
         * Elimina un cliente de la base de datos.
         * @param {number} id - ID del cliente a eliminar.
         */
        async function deleteClient(id) {
            // Reemplazar confirm() con un modal personalizado para mejor UX
            if (!confirm('¿Está seguro de que desea eliminar este cliente? Esta acción es irreversible y podría afectar ventas asociadas.')) {
                return;
            }

            try {
                const response = await fetch(`api/clients.php?action=delete&id=${id}`, {
                    method: 'DELETE'
                });
                const data = await response.json();

                if (response.ok) {
                    window.showToast(data.message || 'Cliente eliminado exitosamente!');
                    await loadClients(); // Recargar la lista de clientes
                } else {
                    window.showToast(data.error || 'Error al eliminar cliente.', true);
                }
            } catch (error) {
                console.error('Error de red al eliminar cliente:', error);
                window.showToast('Error de conexión al eliminar cliente.', true);
            }
        }


        // --- ASIGNACIONES DE FUNCIONES AL OBJETO WINDOW ---
        // Se hace para que puedan ser llamadas desde el HTML (si se usaran onclick) o desde main.js
        window.renderClientsTable = renderClientsTable;
        window.openClientModal = openClientModal;
        window.handleClientFormSubmit = handleClientFormSubmit;
        window.editClient = (id) => {
            const client = window.clients.find(c => c.id == id);
            if (client) {
                window.openClientModal(client);
            } else {
                console.error('Cliente no encontrado para editar:', id);
                window.showToast('Cliente no encontrado para editar.', true);
            }
        };
        window.deleteClient = deleteClient;
        window.filterClients = renderClientsTable; // filterClients ahora simplemente llama a renderClientsTable para aplicar el filtro

        // --- CONFIGURACIÓN DE EVENT LISTENERS ---
        addClientBtn.addEventListener('click', () => window.openClientModal());
        clientForm.addEventListener('submit', (e) => window.handleClientFormSubmit(e));
        cancelClientBtn.addEventListener('click', () => clientModal.classList.add('hidden'));

        // Event listener para búsqueda/filtrado de clientes
        clientSearchInput.addEventListener('input', () => window.filterClients());

        // Cargar y renderizar clientes al iniciar el módulo
        await loadClients();

        // Actualizar iconos Lucide para esta sección
        if (window.lucide) {
            window.lucide.createIcons();
        }
    });
};
