<?php
// api/sales.php
require_once __DIR__ . '/../db_connection.php';

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

header('Content-Type: application/json');

try {
    // Obtener la conexión PDO desde db_connection.php
    $pdo = get_db_connection();

    // Si la conexión falló (get_db_connection devolvió null y ya envió un error JSON),
    // simplemente salimos para evitar intentar operaciones de DB con un PDO nulo.
    if ($pdo === null) {
        error_log("DEBUG: PDO connection is null in sales.php. Exiting.");
        exit();
    }

} catch (PDOException $e) {
    // Capturar cualquier error de conexión y devolverlo como JSON
    http_response_code(500);
    echo json_encode(['error' => 'Error crítico de conexión a la base de datos: ' . $e->getMessage()]);
    error_log('ERROR CRÍTICO PDO en sales.php (conexión): ' . $e->getMessage()); // Para logs del servidor
    exit();
}


if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['error' => 'Acceso no autorizado.']);
    exit();
}

$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? '';

try {
    switch ($method) {
        case 'GET':
            if ($action === 'list') {
                error_log("DEBUG: sales.php - Action 'list' received.");
                // Obtener historial de ventas con detalles de usuario y cliente
                // AJUSTADO: Usando 'sale_date', 'subtotal_amount', 'document_type' de tu esquema SQL
                // ELIMINADO: 'payment_method' ya que no existe en tu tabla 'sales'
                $stmt = $pdo->prepare("
                    SELECT
                        s.id,
                        s.sale_date, -- Nombre de columna correcto
                        s.subtotal_amount, -- Nuevo campo de tu DB
                        s.discount_amount,
                        s.tax_amount,
                        s.total_amount,
                        s.document_type, -- Nombre de columna correcto (ENUM)
                        c.razon_social AS client_name,
                        u.full_name AS user_name
                    FROM sales s
                    LEFT JOIN clientes c ON s.client_id = c.id
                    LEFT JOIN users u ON s.user_id = u.id
                    ORDER BY s.sale_date DESC
                ");
                $stmt->execute();
                $sales = $stmt->fetchAll(PDO::FETCH_ASSOC);
                error_log("DEBUG: sales.php - " . count($sales) . " sales fetched from DB.");

                // Para cada venta, obtener los ítems de venta
                foreach ($sales as &$sale) { // Usar & para pasar por referencia
                    $itemsStmt = $pdo->prepare("
                        SELECT
                            si.product_id,
                            si.quantity,
                            si.price_at_sale,
                            si.item_total,
                            p.name AS product_name,
                            p.sku AS product_sku
                        FROM sale_items si
                        JOIN products p ON si.product_id = p.id
                        WHERE si.sale_id = ?
                    ");
                    $itemsStmt->execute([$sale['id']]);
                    $sale['items'] = $itemsStmt->fetchAll(PDO::FETCH_ASSOC);
                }

                echo json_encode($sales);
                error_log("DEBUG: sales.php - Sales data encoded and sent.");

            } elseif ($action === 'details' && isset($_GET['id'])) {
                error_log("DEBUG: sales.php - Action 'details' received for ID: " . $_GET['id']);
                $sale_id = $_GET['id'];
                // AJUSTADO: Usando 'sale_date', 'subtotal_amount', 'document_type'
                // ELIMINADO: 'payment_method'
                $stmt = $pdo->prepare("
                    SELECT
                        s.id,
                        s.sale_date,
                        s.subtotal_amount,
                        s.discount_amount,
                        s.tax_amount,
                        s.total_amount,
                        s.document_type,
                        c.razon_social AS client_name,
                        u.full_name AS user_name
                    FROM sales s
                    LEFT JOIN clientes c ON s.client_id = c.id
                    LEFT JOIN users u ON s.user_id = u.id
                    WHERE s.id = ?
                ");
                $stmt->execute([$sale_id]);
                $sale = $stmt->fetch(PDO::FETCH_ASSOC);

                if ($sale) {
                    error_log("DEBUG: sales.php - Sale details found for ID: " . $sale_id);
                    $itemsStmt = $pdo->prepare("
                        SELECT
                            si.product_id,
                            si.quantity,
                            si.price_at_sale,
                            si.item_total,
                            p.name AS product_name,
                            p.sku AS product_sku
                        FROM sale_items si
                        JOIN products p ON si.product_id = p.id
                        WHERE si.sale_id = ?
                    ");
                    $itemsStmt->execute([$sale_id]);
                    $sale['items'] = $itemsStmt->fetchAll(PDO::FETCH_ASSOC);
                    echo json_encode($sale);
                } else {
                    error_log("DEBUG: sales.php - Sale not found for ID: " . $sale_id);
                    http_response_code(404);
                    echo json_encode(['error' => 'Venta no encontrada.']);
                }
            } else {
                http_response_code(400);
                echo json_encode(['error' => 'Acción GET no válida.']);
                error_log("ERROR: sales.php - Invalid GET action: " . $action);
            }
            break;

        case 'POST':
            if ($action === 'register') {
                try {
                    error_log("DEBUG: sales.php - Action 'register' received.");
                    $input = json_decode(file_get_contents('php://input'), true);

                    $client_id = $input['client_id'] ?? null;
                    $subtotal_amount = $input['subtotal_amount'] ?? 0; // Nuevo campo de tu DB
                    $total_amount = $input['total_amount'] ?? 0;
                    $discount_amount = $input['discount_amount'] ?? 0;
                    $tax_amount = $input['tax_amount'] ?? 0;
                    $document_type = $input['document_type'] ?? 'Boleta'; // Nombre de columna de tu DB
                    // ELIMINADO: $document_number = $input['document_number'] ?? null; // No existe en tu tabla 'sales'
                    // ELIMINADO: $payment_method = $input['payment_method'] ?? 'Efectivo'; // No existe en tu tabla 'sales'
                    $cart_items = $input['cart_items'] ?? [];
                    $user_id = $_SESSION['user_id']; // Obtener el ID del usuario de la sesión

                    if (empty($cart_items)) {
                        http_response_code(400);
                        echo json_encode(['error' => 'El carrito está vacío.']);
                        error_log("ERROR: sales.php - Cart items are empty for registration.");
                        exit();
                    }

                    $pdo->beginTransaction();
                    error_log("DEBUG: sales.php - Transaction started.");

                    // 1. Insertar la venta principal
                    // AJUSTADO: Usando 'subtotal_amount', 'document_type'. ELIMINADO 'payment_method' y 'document_number'
                    $stmt = $pdo->prepare("
                        INSERT INTO sales (
                            client_id, user_id, subtotal_amount, total_amount, discount_amount, tax_amount,
                            document_type
                        ) VALUES (?, ?, ?, ?, ?, ?, ?)
                    ");
                    $stmt->execute([
                        $client_id,
                        $user_id,
                        $subtotal_amount, // Nuevo campo
                        $total_amount,
                        $discount_amount,
                        $tax_amount,
                        $document_type // Correcto según tu DB
                    ]);
                    $sale_id = $pdo->lastInsertId();
                    error_log("DEBUG: sales.php - Sale registered with ID: " . $sale_id);

                    // 2. Insertar los ítems de la venta y actualizar el stock
                    $itemStmt = $pdo->prepare("
                        INSERT INTO sale_items (sale_id, product_id, quantity, price_at_sale, item_total)
                        VALUES (?, ?, ?, ?, ?)
                    ");
                    $stockStmt = $pdo->prepare("
                        UPDATE products SET stock = stock - ? WHERE id = ? AND stock >= ?
                    ");

                    foreach ($cart_items as $item) {
                        // Verificar el stock disponible antes de restar
                        $checkStockStmt = $pdo->prepare("SELECT stock FROM products WHERE id = ?");
                        $checkStockStmt->execute([$item['product_id']]);
                        $currentStock = $checkStockStmt->fetchColumn();

                        if ($currentStock === false || $currentStock < $item['quantity']) {
                            error_log("ERROR: sales.php - Insufficient stock for product ID: " . $item['product_id'] . ". Current stock: " . ($currentStock !== false ? $currentStock : '0') . ", requested: " . $item['quantity']);
                            throw new Exception("Stock insuficiente para el producto ID: " . $item['product_id'] . " (Solo quedan " . ($currentStock !== false ? $currentStock : '0') . ")");
                        }

                        // Calcula item_total aquí
                        $item_total = $item['price_at_sale'] * $item['quantity'];

                        $itemStmt->execute([
                            $sale_id,
                            $item['product_id'],
                            $item['quantity'],
                            $item['price_at_sale'],
                            $item_total
                        ]);
                        error_log("DEBUG: sales.php - Inserted sale item for product ID: " . $item['product_id']);

                        // Restar del stock
                        $stockUpdateResult = $stockStmt->execute([$item['quantity'], $item['product_id'], $item['quantity']]);

                        if (!$stockUpdateResult || $stockStmt->rowCount() === 0) {
                            error_log("ERROR: sales.php - Failed to update stock for product ID: " . $item['product_id'] . ". Row count: " . $stockStmt->rowCount());
                            throw new Exception("No se pudo actualizar el stock para el producto ID: " . $item['product_id'] . ". Posiblemente stock insuficiente o producto no encontrado.");
                        }
                    }

                    $pdo->commit();
                    error_log("DEBUG: sales.php - Transaction committed successfully.");

                    http_response_code(200);
                    echo json_encode([
                        'success' => true,
                        'message' => 'Venta registrada exitosamente.',
                        'sale_id' => $sale_id
                    ]);
                } catch (Exception $e) {
                    if ($pdo->inTransaction()) {
                        $pdo->rollBack();
                        error_log("DEBUG: sales.php - Transaction rolled back due to error.");
                    }
                    error_log("ERROR al registrar venta: " . $e->getMessage());
                    http_response_code(500);
                    echo json_encode(['error' => 'Error al crear la venta: ' . $e->getMessage()]);
                }
            } else {
                http_response_code(400);
                echo json_encode(['error' => 'Acción POST no válida.']);
                error_log("ERROR: sales.php - Invalid POST action: " . $action);
            }
            break;

        default:
            http_response_code(405); // Method Not Allowed
            echo json_encode(['error' => 'Método no permitido.']);
            error_log("ERROR: sales.php - Method not allowed: " . $method);
            break;
        }
    } catch (PDOException $e) {
        http_response_code(500);
        echo json_encode(['error' => 'Error de base de datos en sales.php: ' . $e->getMessage()]);
        error_log('ERROR PDO CRÍTICO en sales.php (fuera de switch): ' . $e->getMessage());
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode(['error' => 'Error inesperado en sales.php: ' . $e->getMessage()]);
        error_log('ERROR GENERAL CRÍTICO en sales.php (fuera de switch): ' . $e->getMessage());
    }
