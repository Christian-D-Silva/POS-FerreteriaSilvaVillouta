<?php
// api/categories.php
require_once __DIR__ . '/../db_connection.php';
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    http_response_code(401); // Unauthorized
    echo json_encode(['error' => 'Acceso no autorizado.']);
    exit();
}

$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? '';

try {
    $pdo = get_db_connection();

    switch ($method) {
        case 'GET':
            if ($action === 'list') {
                $stmt = $pdo->query("SELECT id, name FROM product_categories ORDER BY name ASC");
                echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
            } else {
                http_response_code(400);
                echo json_encode(['error' => 'Acción GET no válida.']);
            }
            break;

        case 'POST':
            $input = json_decode(file_get_contents('php://input'), true);
            $category_name = $input['name'] ?? '';

            if (empty($category_name)) {
                http_response_code(400);
                echo json_encode(['error' => 'El nombre de la categoría no puede estar vacío.']);
                exit();
            }

            if ($action === 'add') {
                // Verificar si la categoría ya existe
                $stmt_check = $pdo->prepare("SELECT COUNT(*) FROM product_categories WHERE name = ?");
                $stmt_check->execute([$category_name]);
                if ($stmt_check->fetchColumn() > 0) {
                    http_response_code(409); // Conflict
                    echo json_encode(['error' => 'La categoría ya existe.']);
                    exit();
                }

                // Usar GETDATE() para la fecha de creación en SQL Server
                $stmt = $pdo->prepare("INSERT INTO product_categories (name, created_at) VALUES (?, GETDATE())");
                $stmt->execute([$category_name]);
                http_response_code(201); // Created
                echo json_encode(['message' => 'Categoría creada exitosamente.', 'id' => $pdo->lastInsertId(), 'name' => $category_name]);
            } elseif ($action === 'update' && isset($_GET['id'])) {
                $id = $_GET['id'];
                $stmt = $pdo->prepare("UPDATE product_categories SET name = ? WHERE id = ?");
                $stmt->execute([$category_name, $id]);
                if ($stmt->rowCount() > 0) {
                    http_response_code(200);
                    echo json_encode(['message' => 'Categoría actualizada exitosamente.']);
                } else {
                    http_response_code(404);
                    echo json_encode(['error' => 'Categoría no encontrada o no hubo cambios.']);
                }
            } else {
                http_response_code(400);
                echo json_encode(['error' => 'Acción POST no válida.']);
            }
            break;

        case 'DELETE':
            if ($action === 'delete' && isset($_GET['id'])) {
                $id = $_GET['id'];
                
                // Verificar si hay productos asociados a esta categoría antes de eliminar
                $stmt_check_products = $pdo->prepare("SELECT COUNT(*) FROM products WHERE category_id = ?");
                $stmt_check_products->execute([$id]);
                if ($stmt_check_products->fetchColumn() > 0) {
                    http_response_code(409); // Conflict
                    echo json_encode(['error' => 'No se puede eliminar la categoría porque tiene productos asociados.']);
                    exit();
                }

                $stmt = $pdo->prepare("DELETE FROM product_categories WHERE id = ?");
                $stmt->execute([$id]);
                if ($stmt->rowCount() > 0) {
                    http_response_code(200);
                    echo json_encode(['message' => 'Categoría eliminada exitosamente.']);
                } else {
                    http_response_code(404);
                    echo json_encode(['error' => 'Categoría no encontrada.']);
                }
            } else {
                http_response_code(400);
                echo json_encode(['error' => 'Acción DELETE no válida.']);
            }
            break;

        default:
            http_response_code(405); // Method Not Allowed
            echo json_encode(['error' => 'Método no permitido.']);
            break;
    }
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Error de base de datos: ' . $e->getMessage()]);
    error_log('Error PDO en categories.php: ' . $e->getMessage());
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Error inesperado: ' . $e->getMessage()]);
    error_log('Error general en categories.php: ' . $e->getMessage());
}
?>
