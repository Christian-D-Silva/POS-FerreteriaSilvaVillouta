<?php
// api/auth.php

// Asegurarse de que la sesión se inicie al principio de todo el script.
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Incluir el archivo de conexión a la base de datos
// ¡IMPORTANTE: Asegúrate de que esta ruta es correcta!
// Si db_connection.php está en el mismo nivel que api/, entonces sería solo 'db_connection.php'
// Si api/ está dentro de la raíz y db_connection.php está en la raíz, entonces es '../db_connection.php'
require_once __DIR__ . '/../db_connection.php'; 

header('Content-Type: application/json');

// --- Configuración temporal para depuración (¡QUITAR EN PRODUCCIÓN!) ---
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
// ---------------------------------------------------------------------

// --- LÍNEA DE DEPURACIÓN INICIAL ---
error_log("DEBUG: auth.php ha sido accedido. Método: " . $_SERVER['REQUEST_METHOD'] . ", Acción: " . ($_GET['action'] ?? 'N/A'));
// ------------------------------------------

$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? '';

try {
    $pdo = get_db_connection(); // Obtener la conexión PDO una sola vez al inicio del try-catch

    // Si la conexión falló (get_db_connection devolvió null y ya envió un error JSON),
    // simplemente salimos para evitar intentar operaciones de DB con un PDO nulo.
    if ($pdo === null) {
        exit();
    }

    switch ($method) {
        case 'POST':
            $input = json_decode(file_get_contents('php://input'), true);

            if ($action === 'login') {
                $username = $input['username'] ?? '';
                $password = $input['password'] ?? '';

                if (empty($username) || empty($password)) {
                    http_response_code(400); // Bad Request
                    echo json_encode(['error' => 'Usuario y contraseña son obligatorios.']);
                    exit();
                }

                // Obtener usuario y su rol
                $stmt = $pdo->prepare("
                    SELECT u.id, u.username, u.password_hash, u.full_name, u.role_id, ur.name as role_name
                    FROM users u
                    JOIN users_roles ur ON u.role_id = ur.id
                    WHERE u.username = ? AND u.is_active = 1
                ");
                $stmt->execute([$username]);
                $user = $stmt->fetch(PDO::FETCH_ASSOC);

                if ($user && password_verify($password, $user['password_hash'])) {
                    // Autenticación exitosa, guardar en sesión
                    $_SESSION['user_id'] = $user['id'];
                    $_SESSION['username'] = $user['username'];
                    $_SESSION['full_name'] = $user['full_name'];
                    $_SESSION['user_role_id'] = $user['role_id'];
                    $_SESSION['user_role_name'] = $user['role_name'];

                    error_log("DEBUG: Usuario " . $username . " ha iniciado sesión exitosamente. Rol: " . $user['role_name']);

                    http_response_code(200);
                    echo json_encode([
                        'logged_in' => true,
                        'message' => 'Inicio de sesión exitoso',
                        'user' => [
                            'id' => $user['id'],
                            'username' => $user['username'],
                            'full_name' => $user['full_name'],
                            'role_id' => $user['role_id'],
                            'role_name' => $user['role_name']
                        ]
                    ]);
                } else {
                    error_log("DEBUG: Intento de login fallido para usuario: " . $username);
                    http_response_code(401); // Unauthorized
                    echo json_encode(['error' => 'Usuario o contraseña incorrectos.']);
                }
                exit();

            } elseif ($action === 'logout') {
                // Destruir todas las variables de sesión
                $_SESSION = array();

                // Si se desea destruir la sesión completamente, borre también la cookie de sesión.
                // Nota: Esto destruirá la sesión, y no solo los datos de sesión.
                if (ini_get("session.use_cookies")) {
                    $params = session_get_cookie_params();
                    setcookie(session_name(), '', time() - 42000,
                        $params["path"], $params["domain"],
                        $params["secure"], $params["httponly"]
                    );
                }

                // Finalmente, destruir la sesión.
                session_destroy();
                error_log("DEBUG: Sesión cerrada.");
                http_response_code(200);
                echo json_encode(['message' => 'Sesión cerrada exitosamente.']);
                exit();

            } else {
                error_log("DEBUG: Acción POST no válida: '" . $action . "'");
                http_response_code(400); // Bad Request
                echo json_encode(['error' => 'Acción POST no válida.']);
                exit();
            }
            break;

        case 'GET':
            if ($action === 'status') {
                if (isset($_SESSION['user_id'])) {
                    error_log("DEBUG: Sesión activa para user_id: " . $_SESSION['user_id']);
                    // Aquí puedes añadir más datos del usuario si son necesarios en el frontend
                    $response_data = [
                        'logged_in' => true,
                        'user_id' => $_SESSION['user_id'],
                        'username' => $_SESSION['username'] ?? null,
                        'full_name' => $_SESSION['full_name'] ?? null,
                        'role_id' => $_SESSION['user_role_id'] ?? null,
                        'role_name' => $_SESSION['user_role_name'] ?? null
                    ];
                    http_response_code(200);
                    echo json_encode($response_data);
                } else {
                    error_log("DEBUG: No hay sesión activa.");
                    http_response_code(401);
                    echo json_encode(['logged_in' => false]);
                }
                exit();
            } else {
                error_log("DEBUG: Acción GET no válida: '" . $action . "'");
                http_response_code(400);
                echo json_encode(['error' => 'Acción GET no válida.']);
                exit();
            }
            break;

        default:
            error_log("DEBUG: Método HTTP no permitido: '" . $method . "'");
            http_response_code(405); // Method Not Allowed
            echo json_encode(['error' => 'Método no permitido.']);
            exit();
    }
} catch (PDOException $e) {
    error_log("ERROR CRÍTICO (PDO) en auth.php: " . $e->getMessage());
    http_response_code(500); // Internal Server Error
    echo json_encode(['error' => 'Error de base de datos. Por favor, inténtelo de nuevo más tarde.']);
    exit();
} catch (Exception $e) {
    error_log("ERROR CRÍTICO (GENERAL) en auth.php: " . $e->getMessage());
    http_response_code(500); // Internal Server Error
    echo json_encode(['error' => 'Ocurrió un error inesperado en el servidor.']);
    exit();
}
// ---------------------------------------------------------------------
// ¡IMPORTANTE! En producción, QUITAR las líneas de ini_set y error_log,
// o configurarlas para que los errores se logueen en un archivo y no se muestren.
// ---------------------------------------------------------------------
?>
