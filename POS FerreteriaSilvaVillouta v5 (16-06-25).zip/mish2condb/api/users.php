<?php
// api/users.php

require_once __DIR__ . '/../db_connection.php'; // Asegúrate de que esta ruta sea correcta
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

header('Content-Type: application/json');

// Verificar autenticación y permisos (solo administradores pueden gestionar usuarios)
// Asumiendo que el role_id de 'Administrador' es 1. Ajusta según tu DB.
$isAdmin = isset($_SESSION['user_role_id']) && $_SESSION['user_role_id'] == 1; // ID del rol de Administrador

if (!$isAdmin) {
    http_response_code(403); // Forbidden
    echo json_encode(['error' => 'Acceso denegado. Se requiere rol de Administrador.']);
    exit();
}

$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? '';

try {
    $pdo = get_db_connection();

    switch ($method) {
        case 'GET':
            if ($action === 'list') {
                // Listar todos los usuarios con su rol
                $stmt = $pdo->query("
                    SELECT u.id, u.username, u.full_name, u.email, u.role_id, ur.name as role_name, u.is_active
                    FROM users u
                    JOIN users_roles ur ON u.role_id = ur.id
                    ORDER BY u.username ASC
                ");
                echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
            } elseif ($action === 'list_roles') {
                // Listar roles disponibles (para dropdowns, etc.)
                $stmt = $pdo->query("SELECT id, name FROM users_roles ORDER BY name ASC");
                echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
            } elseif ($action === 'details' && isset($_GET['id'])) {
                $id = $_GET['id'];
                $stmt = $pdo->prepare("
                    SELECT u.id, u.username, u.full_name, u.email, u.role_id, ur.name as role_name, u.is_active
                    FROM users u
                    JOIN users_roles ur ON u.role_id = ur.id
                    WHERE u.id = ?
                ");
                $stmt->execute([$id]);
                $user = $stmt->fetch(PDO::FETCH_ASSOC);
                if ($user) {
                    echo json_encode($user);
                } else {
                    http_response_code(404);
                    echo json_encode(['error' => 'Usuario no encontrado.']);
                }
            } else {
                http_response_code(400);
                echo json_encode(['error' => 'Acción GET no válida para usuarios.']);
            }
            break;

        case 'POST':
            $input = json_decode(file_get_contents('php://input'), true);

            $id = $input['id'] ?? null; // Para actualizaciones
            $username = $input['username'] ?? '';
            $password = $input['password'] ?? '';
            $full_name = $input['full_name'] ?? '';
            $email = $input['email'] ?? '';
            $role_id = $input['role_id'] ?? null;
            $is_active = isset($input['is_active']) ? (int)$input['is_active'] : 1; // Por defecto activo

            // Validaciones básicas
            if (empty($username) || empty($full_name) || empty($email) || empty($role_id)) {
                http_response_code(400);
                echo json_encode(['error' => 'Todos los campos obligatorios (usuario, nombre completo, email, rol) deben estar llenos.']);
                exit();
            }

            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                http_response_code(400);
                echo json_encode(['error' => 'El formato del email es inválido.']);
                exit();
            }

            if ($id) { // Actualizar usuario
                // Verificar si el username o email ya existen para otro usuario
                $stmt_check = $pdo->prepare("SELECT COUNT(*) FROM users WHERE (username = ? OR email = ?) AND id != ?");
                $stmt_check->execute([$username, $email, $id]);
                if ($stmt_check->fetchColumn() > 0) {
                    http_response_code(409); // Conflict
                    echo json_encode(['error' => 'El nombre de usuario o email ya están registrados por otro usuario.']);
                    exit();
                }

                $sql = "UPDATE users SET username = ?, full_name = ?, email = ?, role_id = ?, is_active = ?";
                $params = [$username, $full_name, $email, $role_id, $is_active];

                if (!empty($password)) {
                    $password_hash = password_hash($password, PASSWORD_BCRYPT);
                    $sql .= ", password_hash = ?";
                    $params[] = $password_hash;
                }
                $sql .= " WHERE id = ?";
                $params[] = $id;

                $stmt = $pdo->prepare($sql);
                $stmt->execute($params);

                if ($stmt->rowCount() > 0) {
                    http_response_code(200);
                    echo json_encode(['message' => 'Usuario actualizado exitosamente!']);
                } else {
                    http_response_code(404);
                    echo json_encode(['error' => 'Usuario no encontrado o no hubo cambios.']);
                }

            } else { // Añadir nuevo usuario
                if (empty($password)) {
                    http_response_code(400);
                    echo json_encode(['error' => 'La contraseña es obligatoria para un nuevo usuario.']);
                    exit();
                }
                // Verificar si el username o email ya existen
                $stmt_check = $pdo->prepare("SELECT COUNT(*) FROM users WHERE username = ? OR email = ?");
                $stmt_check->execute([$username, $email]);
                if ($stmt_check->fetchColumn() > 0) {
                    http_response_code(409); // Conflict
                    echo json_encode(['error' => 'El nombre de usuario o email ya están registrados.']);
                    exit();
                }

                $password_hash = password_hash($password, PASSWORD_BCRYPT);

                $stmt = $pdo->prepare("
                    INSERT INTO users (username, password_hash, full_name, email, role_id, is_active, created_at)
                    VALUES (?, ?, ?, ?, ?, ?, GETDATE())
                ");
                $stmt->execute([$username, $password_hash, $full_name, $email, $role_id, $is_active]);
                http_response_code(201); // Created
                echo json_encode(['message' => 'Usuario añadido exitosamente!', 'id' => $pdo->lastInsertId()]);
            }
            break;

        case 'DELETE':
            if ($action === 'delete' && isset($_GET['id'])) {
                $id = $_GET['id'];
                
                // No permitir que un usuario se elimine a sí mismo
                if (isset($_SESSION['user_id']) && $_SESSION['user_id'] == $id) {
                    http_response_code(403);
                    echo json_encode(['error' => 'No puedes eliminar tu propia cuenta de usuario.']);
                    exit();
                }

                $stmt = $pdo->prepare("DELETE FROM users WHERE id = ?");
                $stmt->execute([$id]);

                if ($stmt->rowCount() > 0) {
                    http_response_code(200);
                    echo json_encode(['message' => 'Usuario eliminado exitosamente!']);
                } else {
                    http_response_code(404);
                    echo json_encode(['error' => 'Usuario no encontrado.']);
                }
            } else {
                http_response_code(400);
                echo json_encode(['error' => 'Acción DELETE no válida para usuarios.']);
            }
            break;

        default:
            http_response_code(405); // Method Not Allowed
            echo json_encode(['error' => 'Método no permitido.']);
            break;
    }

} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Error de base de datos: ' . $e->getMessage()]);
    error_log('Error PDO en users.php: ' . $e->getMessage());
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Error inesperado: ' . $e->getMessage()]);
    error_log('Error general en users.php: ' . $e->getMessage());
}
?>
