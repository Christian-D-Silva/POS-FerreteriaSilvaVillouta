<?php
// api/adquisiciones.php

// Incluir el archivo de conexión a la base de datos
require_once __DIR__ . '/../db_connection.php';

// Iniciar sesión si no está activa
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Establecer cabecera de respuesta JSON
header('Content-Type: application/json');

// Verificar si el usuario está autenticado
if (!isset($_SESSION['user_id'])) {
    http_response_code(401); // Unauthorized
    echo json_encode(['error' => 'Acceso no autorizado. Debe iniciar sesión.']);
    exit();
}

$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? '';

try {
    $pdo = get_db_connection(); // Obtener la conexión PDO

    switch ($method) {
        case 'GET':
            if ($action === 'list') {
                // Listar todas las adquisiciones con detalles de proveedor y usuario
                $stmt = $pdo->query("
                    SELECT a.id, a.numero_factura, a.fecha_compra, a.total, a.estado_pago,
                           p.razon_social AS proveedor_nombre, u.full_name AS usuario_nombre, a.fecha_vencimiento
                    FROM adquisiciones a
                    JOIN proveedores p ON a.proveedor_id = p.id
                    JOIN users u ON a.user_id = u.id
                    ORDER BY a.fecha_compra DESC
                ");
                echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));

            } elseif ($action === 'details' && isset($_GET['id'])) {
                // Obtener detalles de una adquisición específica y sus ítems
                $id = $_GET['id'];

                // Detalle principal de la adquisición
                $stmt_adquisicion = $pdo->prepare("
                    SELECT a.*, p.razon_social AS proveedor_nombre, u.full_name AS usuario_nombre
                    FROM adquisiciones a
                    JOIN proveedores p ON a.proveedor_id = p.id
                    JOIN users u ON a.user_id = u.id
                    WHERE a.id = ?
                ");
                $stmt_adquisicion->execute([$id]);
                $adquisicion = $stmt_adquisicion->fetch(PDO::FETCH_ASSOC);

                if (!$adquisicion) {
                    http_response_code(404);
                    echo json_encode(['error' => 'Adquisición no encontrada.']);
                    exit();
                }

                // Ítems de la adquisición
                $stmt_items = $pdo->prepare("
                    SELECT ai.id, ai.product_id, prod.nombre_producto, ai.cantidad, ai.precio_unitario, ai.total_item
                    FROM adquisicion_items ai
                    JOIN productos prod ON ai.product_id = prod.id
                    WHERE ai.adquisicion_id = ?
                ");
                $stmt_items->execute([$id]);
                $items = $stmt_items->fetchAll(PDO::FETCH_ASSOC);

                $adquisicion['items'] = $items;
                echo json_encode($adquisicion);

            } elseif ($action === 'list_products_for_acquisition') {
                // Listar productos con SKU, nombre, stock y precio (para la selección en el frontend)
                $search = $_GET['search'] ?? '';
                $sql = "SELECT id, sku, nombre_producto, stock, precio FROM productos";
                $params = [];
                if (!empty($search)) {
                    $sql .= " WHERE sku LIKE ? OR nombre_producto LIKE ?";
                    $params = ["%{$search}%", "%{$search}%"];
                }
                $sql .= " ORDER BY nombre_producto ASC";

                $stmt = $pdo->prepare($sql);
                $stmt->execute($params);
                echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));

            } else {
                http_response_code(400); // Bad Request
                echo json_encode(['error' => 'Acción GET no válida.']);
            }
            break;

        case 'POST':
            $input = json_decode(file_get_contents('php://input'), true);

            if ($action === 'add') {
                // Validar campos requeridos para la adquisición
                $proveedor_id = $input['proveedor_id'] ?? null;
                $numero_factura = $input['numero_factura'] ?? null;
                $fecha_vencimiento = $input['fecha_vencimiento'] ?? null;
                $total_adquisicion = $input['total'] ?? null; // Total calculado en frontend
                $estado_pago = $input['estado_pago'] ?? 'Pendiente'; // 'Pagada' o 'Pendiente'
                $items = $input['items'] ?? []; // Array de productos adquiridos

                if (empty($proveedor_id) || empty($numero_factura) || empty($fecha_vencimiento) || $total_adquisicion === null || !is_array($items) || count($items) === 0) {
                    http_response_code(400);
                    echo json_encode(['error' => 'Datos de adquisición incompletos o inválidos.']);
                    exit();
                }

                // Asegurar que el user_id esté disponible en la sesión
                $user_id = $_SESSION['user_id'] ?? null;
                if (!$user_id) {
                    http_response_code(401);
                    echo json_encode(['error' => 'Usuario no autenticado para registrar adquisición.']);
                    exit();
                }

                // Iniciar una transacción para asegurar la integridad de los datos
                $pdo->beginTransaction();

                try {
                    // Insertar la adquisición principal
                    // Nota: 'fecha_compra' se establece con NOW() para MySQL/MariaDB
                    $stmt_adquisicion = $pdo->prepare("
                        INSERT INTO adquisiciones (proveedor_id, user_id, numero_factura, estado_pago, fecha_vencimiento, total, fecha_compra)
                        VALUES (?, ?, ?, ?, ?, ?, NOW()) -- Cambiado GETDATE() a NOW()
                    ");
                    $stmt_adquisicion->execute([
                        $proveedor_id,
                        $user_id,
                        $numero_factura,
                        $estado_pago,
                        $fecha_vencimiento,
                        $total_adquisicion
                    ]);
                    $adquisicion_id = $pdo->lastInsertId(); // Obtener el ID de la adquisición recién insertada

                    // Preparar statements para items y actualización de stock
                    $stmt_item = $pdo->prepare("
                        INSERT INTO adquisicion_items (adquisicion_id, product_id, cantidad, precio_unitario, total_item)
                        VALUES (?, ?, ?, ?, ?)
                    ");
                    $stmt_stock_update = $pdo->prepare("
                        UPDATE productos SET stock = stock + ? WHERE id = ?
                    ");

                    foreach ($items as $item) {
                        $product_id = $item['product_id'] ?? null;
                        $cantidad = $item['cantidad'] ?? null;
                        $precio_unitario = $item['precio_unitario'] ?? null;
                        $total_item = $item['total_item'] ?? ($cantidad * $precio_unitario); // Calcular si no viene del frontend

                        if (empty($product_id) || empty($cantidad) || empty($precio_unitario)) {
                            throw new Exception('Datos de un ítem de adquisición incompletos.');
                        }

                        // Insertar el ítem de adquisición
                        $stmt_item->execute([
                            $adquisicion_id,
                            $product_id,
                            $cantidad,
                            $precio_unitario,
                            $total_item
                        ]);

                        // Aumentar el stock del producto
                        $stmt_stock_update->execute([$cantidad, $product_id]);
                    }

                    $pdo->commit(); // Confirmar la transacción
                    http_response_code(200);
                    echo json_encode(['message' => 'Adquisición registrada exitosamente.', 'adquisicion_id' => $adquisicion_id]);

                } catch (Exception $e) {
                    // Si algo falla, hacer rollback de la transacción
                    if ($pdo->inTransaction()) {
                        $pdo->rollBack();
                    }
                    error_log("ERROR al registrar adquisición: " . $e->getMessage());
                    http_response_code(500);
                    echo json_encode(['error' => 'Error al registrar la adquisición: ' . $e->getMessage()]);
                }
            } else {
                http_response_code(400); // Bad Request
                echo json_encode(['error' => 'Acción POST no válida.']);
            }
            break;

        // Aquí se podrían añadir los casos 'PUT' (para actualizar) y 'DELETE' (para eliminar) adquisiciones
        // y también el CRUD completo para proveedores.

        default:
            http_response_code(405); // Method Not Allowed
            echo json_encode(['error' => 'Método no permitido.']);
            break;
    }
} catch (PDOException $e) {
    // Capturar errores de conexión o de base de datos generales
    http_response_code(500);
    echo json_encode(['error' => 'Error de base de datos: ' . $e->getMessage()]);
    error_log('Error PDO en adquisiciones.php: ' . $e->getMessage());
} catch (Exception $e) {
    // Capturar cualquier otra excepción
    http_response_code(500);
    echo json_encode(['error' => 'Error inesperado: ' . $e->getMessage()]);
    error_log('Error general en adquisiciones.php: ' . $e->getMessage());
}
?>
