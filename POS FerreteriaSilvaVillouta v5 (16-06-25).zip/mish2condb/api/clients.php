<?php
// api/clients.php
require_once __DIR__ . '/../db_connection.php';
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    http_response_code(401); // Unauthorized
    echo json_encode(['error' => 'Acceso no autorizado.']);
    exit();
}

$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? '';

switch ($method) {
    case 'GET':
        try {
            $pdo = get_db_connection();
            if ($action === 'list') {
                $search = $_GET['search'] ?? '';
                // Corregido: Usa 'id' directamente ya que es la PK en tu tabla 'clientes'
                $sql = "SELECT id, rut, razon_social, giro, direccion, comuna, ciudad, telefono, email, fecha_creacion FROM clientes";
                $params = [];

                if (!empty($search)) {
                    $sql .= " WHERE rut LIKE ? OR razon_social LIKE ? OR giro LIKE ?";
                    $search_param = '%' . $search . '%';
                    $params = [$search_param, $search_param, $search_param];
                }
                $sql .= " ORDER BY razon_social ASC";

                $stmt = $pdo->prepare($sql);
                $stmt->execute($params);
                $clients = $stmt->fetchAll(PDO::FETCH_ASSOC);
                echo json_encode($clients);
            } elseif ($action === 'details' && isset($_GET['id'])) {
                // Corregido: Usa 'id' para la búsqueda
                $stmt = $pdo->prepare("SELECT id, rut, razon_social, giro, direccion, comuna, ciudad, telefono, email, fecha_creacion FROM clientes WHERE id = ?");
                $stmt->execute([$_GET['id']]);
                $client = $stmt->fetch(PDO::FETCH_ASSOC);
                if ($client) {
                    echo json_encode($client);
                } else {
                    http_response_code(404);
                    echo json_encode(['error' => 'Cliente no encontrado.']);
                }
            } else {
                http_response_code(400);
                echo json_encode(['error' => 'Acción GET no válida para clientes.']);
            }
        } catch (PDOException $e) {
            http_response_code(500);
            error_log('Error PDO en clients.php (GET): ' . $e->getMessage());
            echo json_encode(['error' => 'Error de base de datos al listar clientes: ' . $e->getMessage()]);
        }
        break;

    case 'POST': // Añadir o actualizar cliente
        try {
            $pdo = get_db_connection();
            $input = json_decode(file_get_contents('php://input'), true);

            $id = $input['id'] ?? null; // Si viene un ID, es una actualización
            $rut = $input['rut'] ?? '';
            $razon_social = $input['razon_social'] ?? '';
            $giro = $input['giro'] ?? null;
            $direccion = $input['direccion'] ?? null;
            $comuna = $input['comuna'] ?? null;
            $ciudad = $input['ciudad'] ?? null;
            $telefono = $input['telefono'] ?? null;
            $email = $input['email'] ?? null;

            if (empty($rut) || empty($razon_social)) {
                http_response_code(400);
                echo json_encode(['error' => 'RUT y Razón Social son obligatorios.']);
                exit();
            }

            if ($id) { // Actualizar
                // Verificar si el RUT ya existe para otro cliente
                $stmt_check_rut = $pdo->prepare("SELECT COUNT(*) FROM clientes WHERE rut = ? AND id != ?"); // Corregido: usa 'id'
                $stmt_check_rut->execute([$rut, $id]);
                if ($stmt_check_rut->fetchColumn() > 0) {
                    http_response_code(409); // Conflict
                    echo json_encode(['error' => 'El RUT ya está registrado para otro cliente.']);
                    exit();
                }

                $stmt = $pdo->prepare("
                    UPDATE clientes SET
                        rut = ?, razon_social = ?, giro = ?, direccion = ?, comuna = ?, ciudad = ?, telefono = ?, email = ?
                    WHERE id = ?
                "); // Corregido: usa 'id'
                $stmt->execute([$rut, $razon_social, $giro, $direccion, $comuna, $ciudad, $telefono, $email, $id]);

                if ($stmt->rowCount() > 0) {
                    http_response_code(200);
                    echo json_encode(['message' => 'Cliente actualizado exitosamente!']);
                } else {
                    http_response_code(404); // Not Found o sin cambios
                    echo json_encode(['error' => 'Cliente no encontrado o no se realizaron cambios.']);
                }
            } else { // Añadir nuevo cliente
                // Verificar si el RUT ya existe
                $stmt_check_rut = $pdo->prepare("SELECT COUNT(*) FROM clientes WHERE rut = ?");
                $stmt_check_rut->execute([$rut]);
                if ($stmt_check_rut->fetchColumn() > 0) {
                    http_response_code(409); // Conflict
                    echo json_encode(['error' => 'Ya existe un cliente con este RUT.']);
                    exit();
                }

                $stmt = $pdo->prepare("
                    INSERT INTO clientes (rut, razon_social, giro, direccion, comuna, ciudad, telefono, email, fecha_creacion)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, GETDATE())
                ");
                $stmt->execute([$rut, $razon_social, $giro, $direccion, $comuna, $ciudad, $telefono, $email]);
                
                http_response_code(201); // Created
                echo json_encode(['message' => 'Cliente añadido exitosamente!', 'id' => $pdo->lastInsertId()]);
            }
        } catch (PDOException $e) {
            http_response_code(500);
            error_log('Error PDO en clients.php (POST/PUT): ' . $e->getMessage());
            echo json_encode(['error' => 'Error de base de datos al ' . ($id ? 'actualizar' : 'añadir') . ' cliente: ' . $e->getMessage()]);
        }
        break;

    case 'DELETE': // Eliminar cliente
        try {
            $pdo = get_db_connection();
            $id = $_GET['id'] ?? null;
            if (!$id) {
                http_response_code(400);
                echo json_encode(['error' => 'ID de cliente no proporcionado.']);
                exit();
            }

            // La FK en 'sales' con ON DELETE SET NULL manejará la referencia.
            // Corregido: usa 'id' para la eliminación
            $stmt = $pdo->prepare("DELETE FROM clientes WHERE id = ?");
            $stmt->execute([$id]);

            if ($stmt->rowCount() > 0) {
                http_response_code(200);
                echo json_encode(['message' => 'Cliente eliminado exitosamente!']);
            } else {
                http_response_code(404); // Not Found
                echo json_encode(['error' => 'Cliente no encontrado.']);
            }
        } catch (PDOException $e) {
            http_response_code(500);
            error_log('Error PDO en clients.php (DELETE): ' . $e->getMessage());
            echo json_encode(['error' => 'Error de base de datos al eliminar cliente: ' . $e->getMessage()]);
        }
        break;

    default:
        http_response_code(405); // Method Not Allowed
        echo json_encode(['error' => 'Método no permitido.']);
        break;
}
?>
