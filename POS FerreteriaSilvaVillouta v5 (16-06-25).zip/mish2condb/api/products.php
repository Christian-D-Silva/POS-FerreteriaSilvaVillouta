<?php
// api/products.php
require_once __DIR__ . '/../db_connection.php';
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    http_response_code(401); // Unauthorized
    echo json_encode(['error' => 'Acceso no autorizado.']);
    exit();
}

$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? '';

try {
    $pdo = get_db_connection(); // Obtener la conexión PDO

    switch ($method) {
        case 'GET':
            if ($action === 'list') {
                // Listar todos los productos con el nombre de su categoría
                $stmt = $pdo->query("SELECT p.*, pc.name as category_name FROM products p LEFT JOIN product_categories pc ON p.category_id = pc.id ORDER BY p.name ASC");
                echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
            } elseif ($action === 'list_categories') {
                // Listar solo las categorías de productos
                $stmt = $pdo->query("SELECT id, name FROM product_categories ORDER BY name ASC");
                echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
            } elseif ($action === 'details' && isset($_GET['id'])) {
                // Obtener detalles de un producto específico
                $stmt = $pdo->prepare("SELECT p.*, pc.name as category_name FROM products p LEFT JOIN product_categories pc ON p.category_id = pc.id WHERE p.id = ?");
                $stmt->execute([$_GET['id']]);
                $product = $stmt->fetch(PDO::FETCH_ASSOC);
                if ($product) {
                    echo json_encode($product);
                } else {
                    http_response_code(404);
                    echo json_encode(['error' => 'Producto no encontrado.']);
                }
            } else {
                http_response_code(400);
                echo json_encode(['error' => 'Acción GET no válida.']);
            }
            break;

        case 'POST':
            $input = json_decode(file_get_contents('php://input'), true);

            // Campos comunes para añadir y actualizar
            $name = $input['name'] ?? '';
            $sku = $input['sku'] ?? '';
            $price = $input['price'] ?? 0;
            $stock = $input['stock'] ?? 0;
            $category_id = $input['category_id'] ?? null;
            $description = $input['description'] ?? null;

            if (empty($name) || empty($sku) || !is_numeric($price) || $price < 0 || !is_numeric($stock) || $stock < 0 || empty($category_id)) {
                http_response_code(400);
                echo json_encode(['error' => 'Todos los campos obligatorios (nombre, SKU, precio, stock, categoría) deben estar llenos y ser válidos.']);
                exit();
            }

            if ($action === 'add') {
                // Verificar si el SKU ya existe
                $stmt_check_sku = $pdo->prepare("SELECT COUNT(*) FROM products WHERE sku = ?");
                $stmt_check_sku->execute([$sku]);
                if ($stmt_check_sku->fetchColumn() > 0) {
                    http_response_code(409); // Conflict
                    echo json_encode(['error' => 'Ya existe un producto con este SKU.']);
                    exit();
                }

                $stmt = $pdo->prepare("INSERT INTO products (name, sku, price, stock, category_id, description, created_at) VALUES (?, ?, ?, ?, ?, ?, GETDATE())");
                $stmt->execute([$name, $sku, $price, $stock, $category_id, $description]);
                http_response_code(201); // Created
                echo json_encode(['message' => 'Producto añadido exitosamente.', 'id' => $pdo->lastInsertId()]);

            } elseif ($action === 'update' && isset($_GET['id'])) {
                $id = $_GET['id'];
                // Verificar si el SKU ya existe para otro producto (excluyendo el actual)
                $stmt_check_sku = $pdo->prepare("SELECT COUNT(*) FROM products WHERE sku = ? AND id != ?");
                $stmt_check_sku->execute([$sku, $id]);
                if ($stmt_check_sku->fetchColumn() > 0) {
                    http_response_code(409); // Conflict
                    echo json_encode(['error' => 'El SKU ya está registrado para otro producto.']);
                    exit();
                }

                $stmt = $pdo->prepare("UPDATE products SET name = ?, sku = ?, price = ?, stock = ?, category_id = ?, description = ? WHERE id = ?");
                $stmt->execute([$name, $sku, $price, $stock, $category_id, $description, $id]);
                if ($stmt->rowCount() > 0) {
                    http_response_code(200);
                    echo json_encode(['message' => 'Producto actualizado exitosamente.']);
                } else {
                    http_response_code(404);
                    echo json_encode(['error' => 'Producto no encontrado o no hubo cambios.']);
                }
            } elseif ($action === 'add_category') {
                // Acción para añadir una categoría (desde el modal de productos)
                $category_name = $input['name'] ?? '';
                if (empty($category_name)) {
                    http_response_code(400);
                    echo json_encode(['error' => 'El nombre de la categoría no puede estar vacío.']);
                    exit();
                }

                $stmt_check = $pdo->prepare("SELECT COUNT(*) FROM product_categories WHERE name = ?");
                $stmt_check->execute([$category_name]);
                if ($stmt_check->fetchColumn() > 0) {
                    http_response_code(409); // Conflict
                    echo json_encode(['error' => 'La categoría ya existe.']);
                    exit();
                }

                $stmt = $pdo->prepare("INSERT INTO product_categories (name, created_at) VALUES (?, GETDATE())");
                $stmt->execute([$category_name]);
                http_response_code(201);
                echo json_encode(['message' => 'Categoría creada exitosamente.', 'id' => $pdo->lastInsertId(), 'name' => $category_name]);
            } else {
                http_response_code(400);
                echo json_encode(['error' => 'Acción POST no válida.']);
            }
            break;

        case 'DELETE':
            if ($action === 'delete' && isset($_GET['id'])) {
                $id = $_GET['id'];
                
                // Verificar si el producto está en alguna venta o adquisición antes de eliminar (opcional, dependiendo de FKs)
                // Esto es importante para evitar errores de integridad referencial
                // Por ejemplo, si tienes una tabla `sale_items` que referencia `products.id`
                $stmt_check_sales = $pdo->prepare("SELECT COUNT(*) FROM sale_items WHERE product_id = ?");
                $stmt_check_sales->execute([$id]);
                if ($stmt_check_sales->fetchColumn() > 0) {
                    http_response_code(409);
                    echo json_encode(['error' => 'No se puede eliminar el producto porque está asociado a ventas existentes.']);
                    exit();
                }

                // Si tienes una tabla `acquisition_items` que referencia `products.id`
                $stmt_check_acquisitions = $pdo->prepare("SELECT COUNT(*) FROM acquisition_items WHERE product_id = ?");
                $stmt_check_acquisitions->execute([$id]);
                if ($stmt_check_acquisitions->fetchColumn() > 0) {
                    http_response_code(409);
                    echo json_encode(['error' => 'No se puede eliminar el producto porque está asociado a adquisiciones existentes.']);
                    exit();
                }

                $stmt = $pdo->prepare("DELETE FROM products WHERE id = ?");
                $stmt->execute([$id]);
                if ($stmt->rowCount() > 0) {
                    http_response_code(200);
                    echo json_encode(['message' => 'Producto eliminado exitosamente.']);
                } else {
                    http_response_code(404);
                    echo json_encode(['error' => 'Producto no encontrado.']);
                }
            } elseif ($action === 'delete_category' && isset($_GET['id'])) {
                $id = $_GET['id'];
                // La lógica para eliminar categorías con comprobación de productos asociados
                // ya está en api/categories.php, pero si se llama desde products.php, duplicar o redirigir
                $stmt_check = $pdo->prepare("SELECT COUNT(*) FROM products WHERE category_id = ?");
                $stmt_check->execute([$id]);
                $count = $stmt_check->fetchColumn();

                if ($count > 0) {
                    http_response_code(409); // Conflict
                    echo json_encode(['error' => 'No se puede eliminar la categoría porque tiene productos asociados.']);
                    exit();
                }

                // Eliminar categoría
                $stmt = $pdo->prepare("DELETE FROM product_categories WHERE id = ?");
                $stmt->execute([$id]);
                if ($stmt->rowCount() > 0) {
                    http_response_code(200);
                    echo json_encode(['message' => 'Categoría eliminada exitosamente.']);
                } else {
                    http_response_code(404);
                    echo json_encode(['error' => 'Categoría no encontrada.']);
                }

            } else {
                http_response_code(400);
                echo json_encode(['error' => 'Acción DELETE no válida.']);
            }
            break;

        default:
            http_response_code(405); // Method Not Allowed
            echo json_encode(['error' => 'Método no permitido.']);
            break;
    }
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Error de base de datos: ' . $e->getMessage()]);
    error_log('Error PDO en products.php: ' . $e->getMessage());
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Error inesperado: ' . $e->getMessage()]);
    error_log('Error general en products.php: ' . $e->getMessage());
}
?>
